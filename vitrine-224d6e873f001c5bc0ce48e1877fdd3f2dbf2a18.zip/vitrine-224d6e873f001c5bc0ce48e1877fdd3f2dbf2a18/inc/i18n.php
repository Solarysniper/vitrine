<?php
/**
 * Artaun Hosting — i18n, routage et helpers de rendu.
 */

$GLOBALS['ARTAUN'] = ['lang' => LANG_DEFAULT, 'strings' => [], 'slugs' => [], 'page' => 'home'];

/**
 * Charge tous les textes courants depuis lang/content/*.json (un fichier
 * par page/section, les 4 langues ensemble dans chaque clé) — pour changer
 * un texte, on édite UN SEUL fichier JSON, jamais quatre fichiers PHP.
 * Les slugs d'URL et les pages juridiques restent en PHP (routage / structure
 * imbriquée), ce sont les seules exceptions.
 */
function load_content_json(): array
{
    static $catalog = null;
    if ($catalog !== null) return $catalog;

    $dir   = __DIR__ . '/../lang/content/';
    $cache = __DIR__ . '/../var/cache/content.php';

    // CACHE COMPILÉ.
    // Sans lui, chaque page ouvrait et décodait les dix-sept fichiers JSON de
    // traduction — un travail identique répété à chaque requête. Le cache est
    // un simple fichier PHP : OPcache le garde compilé en mémoire, donc le
    // relire ne coûte pratiquement rien.
    //
    // Il se régénère tout seul dès qu'un fichier source est plus récent que
    // lui : on édite un JSON, la page suivante reconstruit le cache. Aucune
    // commande à lancer après une modification de texte.
    $newest = 0;
    $files  = glob($dir . '*.json') ?: [];
    foreach ($files as $file) {
        $mtime = (int) filemtime($file);
        if ($mtime > $newest) $newest = $mtime;
    }

    // On compare la date source ENREGISTRÉE DANS le cache, pas la date du
    // fichier de cache. Les mtime ont une granularité d'une seconde : si une
    // édition tombe dans la même seconde qu'une écriture de cache, comparer
    // les dates de fichiers fait conclure à tort que le cache est à jour, et
    // l'ancien texte reste servi. Stocker l'empreinte à l'intérieur supprime
    // complètement cette fenêtre de course.
    if (is_readable($cache)) {
        $loaded = include $cache;
        if (is_array($loaded) && ($loaded['src'] ?? null) === $newest && isset($loaded['data'])) {
            return $catalog = $loaded['data'];
        }
    }

    $catalog = [];
    foreach ($files as $file) {
        $data = json_decode((string) file_get_contents($file), true) ?? [];
        foreach ($data as $key => $perLang) {
            $catalog[$key] = $perLang;
        }
    }

    // Écriture atomique : un autre processus ne doit jamais lire un cache
    // à moitié écrit.
    $cacheDir = dirname($cache);
    if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);
    $tmp = $cache . '.' . getmypid() . '.tmp';
    $payload = ['src' => $newest, 'data' => $catalog];
    if (@file_put_contents($tmp, '<?php return ' . var_export($payload, true) . ';') !== false) {
        @rename($tmp, $cache);
        if (function_exists('opcache_invalidate')) @opcache_invalidate($cache, true);
    }

    return $catalog;
}

/** Charge un jeu de traductions (chaînes + slugs) pour la langue donnée. */
function load_lang(string $lang): void
{
    $lang = array_key_exists($lang, LANGS) ? $lang : LANG_DEFAULT;
    $base = __DIR__ . '/../lang/';

    $catalog = load_content_json();
    $strings = [];
    foreach ($catalog as $key => $perLang) {
        // Le français sert de repli : une clé oubliée dans une langue
        // affiche le FR, jamais une clé nue.
        $strings[$key] = $perLang[$lang] ?? $perLang[LANG_DEFAULT] ?? $key;
    }

    // Slugs d'URL (routage) et pages juridiques : structure imbriquée,
    // conservées telles quelles en PHP.
    $slugs = require $base . $lang . '.php';
    $legal = require $base . 'legal/' . $lang . '.php';
    if ($lang !== LANG_DEFAULT) {
        $legal = array_merge(require $base . 'legal/' . LANG_DEFAULT . '.php', $legal);
    }
    $strings = array_merge($strings, $legal);

    $GLOBALS['ARTAUN']['lang']    = $lang;
    $GLOBALS['ARTAUN']['strings'] = $strings;
    $GLOBALS['ARTAUN']['slugs']   = $slugs['_slugs'] + extra_slugs($lang);
}

/** Slugs des nouveaux jeux pour une langue (vide si l'option est coupée). */
function extra_slugs(string $lang): array
{
    $out = [];
    foreach (games_extra() as $key => $prod) {
        if (isset($prod['slugs'][$lang])) $out[$key] = $prod['slugs'][$lang];
    }
    return $out;
}

function lang(): string { return $GLOBALS['ARTAUN']['lang']; }
function current_page(): string { return $GLOBALS['ARTAUN']['page']; }

/** Traduit une clé. Les arguments supplémentaires alimentent un sprintf. */
function t(string $key, ...$args): string
{
    $s = $GLOBALS['ARTAUN']['strings'][$key] ?? $key;
    return $args ? vsprintf($s, $args) : $s;
}

/** Traduit et échappe — à utiliser dans le HTML. */
function e(string $key, ...$args): string
{
    return htmlspecialchars(t($key, ...$args), ENT_QUOTES, 'UTF-8');
}

/** Échappe une valeur brute. */
function h(?string $v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

/** Existence d'une clé de traduction. */
function has(string $key): bool
{
    return isset($GLOBALS['ARTAUN']['strings'][$key]);
}

/** URL interne d'une page, dans la langue voulue. */
function url(string $page = 'home', ?string $lang = null): string
{
    // La page Statut est désormais status.artaun.fr (Artaun Network)
    if ($page === "status") return "https://status.artaun.fr";
    $lang  = $lang ?: lang();
    $slugs = ($lang === lang())
        ? $GLOBALS['ARTAUN']['slugs']
        : (require __DIR__ . '/../lang/' . $lang . '.php')['_slugs'] + extra_slugs($lang);

    // L'accueil de la langue par défaut vit à la RACINE du domaine, pas dans
    // /fr/. Google ne reconnaît un « nom de site » (le « Artaun Hosting »
    // affiché à côté du favicon dans les résultats) que s'il trouve le
    // balisage WebSite sur la page d'accueil du domaine : il ne le gère pas
    // au niveau d'un sous-répertoire. Tant que l'accueil n'existait qu'en
    // /fr/, Google se rabattait sur le nom de domaine.
    // /fr/ continue de répondre et pointe son canonique ici.
    if ($page === 'home') return $lang === LANG_DEFAULT ? '/' : '/' . $lang . '/';
    $slug = $slugs[$page] ?? $page;
    return '/' . $lang . '/' . $slug . '/';
}

/** Résout un slug entrant vers une clé de page. */
function resolve_page(string $slug, string $lang): ?string
{
    if ($slug === '') return 'home';
    $slugs = $GLOBALS['ARTAUN']['slugs'];
    $key   = array_search($slug, $slugs, true);
    return $key !== false ? $key : null;
}

/** Prix formaté selon la langue (2,00 € en FR/DE/ES, €2.00 en EN). */
function price(float $amount, ?string $lang = null): string
{
    $lang = $lang ?: lang();
    if ($lang === 'en') return '€' . number_format($amount, 2, '.', ',');
    return number_format($amount, 2, ',', ' ') . ' €';
}

/** Prix mensualisé pour une période de facturation donnée (remise BILLING_PERIODS). */
function price_period(float $amount, string $period): string
{
    $discount = BILLING_PERIODS[$period]['discount'] ?? 0.0;
    return price(round($amount * (1 - $discount), 2));
}

/** Pourcentage de remise affiché pour une période (entier, ex. 5, 10, 15). */
function billing_discount_pct(string $period): int
{
    return (int) round((BILLING_PERIODS[$period]['discount'] ?? 0.0) * 100);
}

/**
 * Rend une spécification structurée en texte traduit.
 * Ex. ['cpu', 6, '3.9', 'Intel Xeon Gold 6230'] → « 6 vCores Intel Xeon Gold 6230 (3.9 GHz) »
 */
function spec(array $s): string
{
    $type = array_shift($s);
    switch ($type) {
        case 'cpu':
            [$cores, $ghz] = [$s[0], $s[1]];
            $model = $s[2] ?? null;
            // Singulier : jusqu'à 1 en anglais, en dessous de 2 en français (« 1,5 vCore »).
            $one = (float) $cores < (in_array(lang(), ['fr'], true) ? 2 : 1.0001);
            if (is_float($cores) && floor($cores) != $cores) {
                $cores = number_format($cores, 1, lang() === 'en' ? '.' : ',', '');
            }
            $out = $model
                ? t('spec.cpu_model', $cores, $model, $ghz)
                : t('spec.cpu', $cores, $ghz);
            return $one ? str_replace('vCores', 'vCore', $out) : $out;
        case 'ram':   return t('spec.ram', $s[0]);
        case 'ssd':   return t('spec.ssd', $s[0]);
        case 'nvme':  return t('spec.nvme', $s[0]);
        case 'ip':    return t('spec.ip', $s[0]);
        case 'net':   return t('spec.net', $s[0]);
        case 'panel': return t('spec.panel', $s[0]);
        case 'db':    return t('spec.db', $s[0]);
        case 'mail':  return t('spec.mail', $s[0], $s[1]);
        case 'mailu': return t('spec.mailu', $s[0]);
        case 'mailbox': return t('spec.mailbox', $s[0]);
        case 'accounts': return t('spec.accounts', $s[0]);
        case 'mailstorage': return t('spec.mailstorage', $s[0]);
        case 'maildomains': return t('spec.maildomains', $s[0]);
        case 'mailalias': return t('spec.mailalias', $s[0]);
        case 'mailvault': return t('spec.mailvault', $s[0]);
        default:      return t('spec.' . $type);
    }
}

/** Version courte d'une caractéristique (lignes d'offres) : le processeur sans son modèle. */
function spec_short(array $s): string
{
    if (($s[0] ?? '') === 'cpu') return t('spec.cpu', $s[1], $s[2]);
    return spec($s);
}

/**
 * Essai gratuit de 3 jours : offert sur la toute première offre de chaque
 * produit, sauf en catégorie VPS. Centralisé ici pour s'appliquer partout
 * (accueil, page produit) sans configuration supplémentaire par produit.
 */
function has_free_trial(string $productKey, int $planIndex): bool
{
    $plan = CATALOG[$productKey]['plans'][$planIndex] ?? null;
    // Catalogue synchronisé : l'essai existe seulement s'il est configuré dans l'espace client.
    if (is_array($plan) && array_key_exists('trial', $plan)) return (int) $plan['trial'] > 0;
    $category = CATALOG[$productKey]['category'] ?? null;
    return $planIndex === 0 && $category !== 'vps';
}

/** Toutes les offres d'un produit, avec le lien de commande. */
/** Lien d'essai gratuit d'une offre (extension free_trial de l'espace client). */
function trial_url(int $sku): string
{
    return LINKS['clients'] . '/free_trial/' . $sku;
}

function plan_url(int $sku): string
{
    return LINKS['store'] . '/basket/config/' . $sku;
}

/** Produits d'une catégorie. */
function products_in(string $category): array
{
    return array_filter(CATALOG, fn($p) => $p['category'] === $category);
}

/**
 * Texte d'un produit (name, tagline, title, lead).
 *
 * Ordre de recherche :
 *   1. CATALOG[<produit>]['text'][<langue>][<champ>]  — traduction dédiée
 *   2. CATALOG[<produit>]['text']['*'][<champ>]       — même texte partout
 *   3. lang/content/product.json, clé product.<produit>.<champ>
 *
 * Une nouvelle offre peut donc vivre entièrement dans inc/config.php.
 */
function product_text(string $key, string $field): string
{
    $text = CATALOG[$key]['text'] ?? null;
    if ($text) {
        if (isset($text[lang()][$field])) return $text[lang()][$field];
        if (isset($text['*'][$field]))    return $text['*'][$field];
    }
    return t('product.' . $key . '.' . $field);
}

/** Prix d'appel d'un produit. */
function product_from(string $key): float
{
    return CATALOG[$key]['from'] ?? 0.0;
}

/**
 * Logos de marque (multi-couleurs, pas le style "trait" du reste du site).
 * Utilisés uniquement pour identifier un OS/panel/produit tiers dans le
 * mega-menu (ex. Linux, Windows, Pterodactyl, Plesk) — représentations
 * simplifiées, pas un tracé officiel pixel pour pixel.
 */
function brandIcon(string $name, string $class = ''): string
{
    static $brands = [
        // Tux — silhouette simplifiée du pingouin Linux.
        'brand-linux' => '
            <path d="M12 2.2c-1.7 0-2.7 1.4-2.7 3.4 0 .7.1 1.3.3 1.9-1 .5-1.6 1.6-2 2.9-.5 1.7-.6 3.8-.6 5.6 0 1 .5 1.7 1.2 2.2-.3.4-.5.8-.5 1.3 0 1.2 1.6 2 3.6 2h1.4c2 0 3.6-.8 3.6-2 0-.5-.2-.9-.5-1.3.7-.5 1.2-1.2 1.2-2.2 0-1.8-.1-3.9-.6-5.6-.4-1.3-1-2.4-2-2.9.2-.6.3-1.2.3-1.9 0-2-1-3.4-2.7-3.4z" fill="#0b0b0d"/>
            <ellipse cx="9.9" cy="6.1" rx=".9" ry="1.1" fill="#fff"/>
            <ellipse cx="14.1" cy="6.1" rx=".9" ry="1.1" fill="#fff"/>
            <circle cx="9.9" cy="6.3" r=".4" fill="#0b0b0d"/>
            <circle cx="14.1" cy="6.3" r=".4" fill="#0b0b0d"/>
            <path d="M11.1 6.8h1.8c.2 0 .3.2.2.4l-.7.9c-.2.3-.6.3-.8 0l-.7-.9c-.1-.2 0-.4.2-.4z" fill="#f5a623"/>
            <path d="M7.3 20.4c.6-1 1.4-1.7 1.4-2.9 0-.5-.2-.8-.5-1.1-.4.7-1 1.3-1.5 1.9-.4.5-.6 1.1-.2 1.7.2.3.5.4.8.4z" fill="#f5a623"/>
            <path d="M16.7 20.4c-.6-1-1.4-1.7-1.4-2.9 0-.5.2-.8.5-1.1.4.7 1 1.3 1.5 1.9.4.5.6 1.1.2 1.7-.2.3-.5.4-.8.4z" fill="#f5a623"/>
            <path d="M8.8 6.9c-.3 0-.6.3-.6.9 0 .5.3.9.6.9M15.2 6.9c.3 0 .6.3.6.9 0 .5-.3.9-.6.9" fill="#0b0b0d"/>',
        // Fenêtre Windows — 4 volets classiques.
        'brand-windows' => '
            <rect x="3" y="3.5" width="8" height="8" fill="#00A4EF"/>
            <rect x="12" y="3.5" width="9" height="8" fill="#7FBA00"/>
            <rect x="3" y="12.5" width="8" height="8" fill="#FFB900"/>
            <rect x="12" y="12.5" width="9" height="8" fill="#F25022"/>',
        // Pterodactyl — silhouette de reptile stylisée, ton "panel" teal.
        'brand-pterodactyl' => '
            <path d="M4 14c1-3 3.6-5.4 6.6-6.6-.4-1-.3-2 .4-2.8.9-1 2.3-1.2 3.4-.5-.2.8-.7 1.4-1.4 1.7 1 .2 2 .7 2.8 1.5 1.8 1.8 2.4 4.4 1.7 6.7-.4 1.3-1.2 2.4-2.3 3.1.3.7.2 1.5-.3 2.1-.7.8-1.9.9-2.7.2l-1-1c-1 .3-2.1.4-3.1.2l-1.3 1.6c-.6.8-1.8.9-2.5.2-.6-.5-.7-1.4-.3-2.1C3 17.6 2.7 15.7 4 14z" fill="#14919b"/>
            <circle cx="13.4" cy="9.2" r=".7" fill="#fff"/>',
        // Plesk — monogramme "P" simplifié dans la couleur de marque.
        'brand-plesk' => '
            <circle cx="12" cy="12" r="10" fill="#52BBC7"/>
            <path d="M9.3 7.2h3.9c2.1 0 3.6 1.4 3.6 3.4s-1.5 3.4-3.6 3.4H10.9v3.8H9.3V7.2zm1.6 1.5v3.8h2.2c1.2 0 1.9-.7 1.9-1.9s-.7-1.9-1.9-1.9h-2.2z" fill="#fff"/>',
        // KVM — puce de virtualisation empilée, ton bleu "infra".
        'brand-kvm' => '
            <rect x="3" y="3" width="18" height="6" rx="1.5" fill="#2563EB"/>
            <rect x="3" y="10.5" width="18" height="6" rx="1.5" fill="#3B82F6"/>
            <rect x="3" y="18" width="18" height="3" rx="1.2" fill="#93C5FD"/>
            <circle cx="7" cy="6" r="1" fill="#fff"/><circle cx="7" cy="13.5" r="1" fill="#fff"/>',
        // Proxmox — losange orange caractéristique de la marque.
        'brand-proxmox' => '
            <circle cx="12" cy="12" r="10" fill="#E57000"/>
            <path d="M12 5l4.5 4.5-2 2-2.5-2.5-2.5 2.5-2-2L12 5z" fill="#fff"/>
            <path d="M12 19l-4.5-4.5 2-2 2.5 2.5 2.5-2.5 2 2L12 19z" fill="#fff" opacity=".85"/>',
        // Sous-catégories de jeux (icônes thématiques, pas des marques).
        'brand-roleplay' => '
            <path d="M5 9a5 5 0 0110-.4A5 5 0 0119 9c0 4-3.2 7-7 11-3.8-4-7-7-7-11z" fill="#C084FC"/>
            <circle cx="9.5" cy="9.5" r="1.1" fill="#fff"/><circle cx="14.5" cy="9.5" r="1.1" fill="#fff"/>',
        'brand-survival' => '
            <path d="M12 2s5 6 5 10.5A5 5 0 0112 18a5 5 0 01-5-5.5C7 8 12 2 12 2z" fill="#F97316"/>
            <path d="M12 9c1 1.5 2 3 2 4.3A2 2 0 0112 15a2 2 0 01-2-1.7c0-1.3 1-2.8 2-4.3z" fill="#FED7AA"/>',
        'brand-sandbox' => '
            <rect x="3" y="10" width="7" height="7" rx=".8" fill="#22C55E"/>
            <rect x="11" y="6" width="7" height="7" rx=".8" fill="#84CC16"/>
            <rect x="11" y="14" width="7" height="7" rx=".8" fill="#65A30D"/>',
        'brand-simulation' => '
            <circle cx="12" cy="12" r="9" fill="#0EA5E9"/>
            <circle cx="12" cy="12" r="5.2" fill="#0C4A6E"/>
            <circle cx="12" cy="8" r="1" fill="#fff"/><circle cx="15.5" cy="13.8" r="1" fill="#fff"/><circle cx="8.5" cy="13.8" r="1" fill="#fff"/>',
        'brand-fps' => '
            <circle cx="12" cy="12" r="9" fill="none" stroke="#EF4444" stroke-width="2"/>
            <path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="#EF4444" stroke-width="2"/>
            <circle cx="12" cy="12" r="2.2" fill="#EF4444"/>',
        'brand-strategy' => '
            <path d="M8 20h8l-1-3H9l-1 3z" fill="#A78BFA"/>
            <path d="M9.5 17l.8-6h3.4l.8 6h-5z" fill="#8B5CF6"/>
            <circle cx="12" cy="7.5" r="3" fill="#7C3AED"/>
            <path d="M10.5 4.6L12 2.5l1.5 2.1" fill="none" stroke="#7C3AED" stroke-width="1.4"/>',
        // Jeux — logos simplifiés (pas un tracé officiel pixel pour pixel),
        // en attendant que /assets/img/logos/<jeu>.png soit fourni.
        'brand-minecraft' => '
            <rect x="3" y="3" width="18" height="18" rx="1" fill="#6B4A2E"/>
            <rect x="3" y="3" width="18" height="6" fill="#5B9C42"/>
            <rect x="6" y="6" width="3" height="3" fill="#3F7A2E"/>
            <rect x="14" y="4" width="3" height="3" fill="#3F7A2E"/>',
        'brand-fivem' => '
            <circle cx="12" cy="12" r="10" fill="#F26D30"/>
            <path d="M7 15l3-8h2.2l-2.3 6.3H14L9.6 19 11 15H7z" fill="#fff"/>',
        'brand-redm' => '
            <circle cx="12" cy="12" r="10" fill="#8B1E1E"/>
            <path d="M6 15c1-4 3-8 6-8s5 4 6 8c-1.6-1-3.6-1.6-6-1.6s-4.4.6-6 1.6z" fill="#F3D9A4"/>
            <path d="M6 15c1.6 1.4 3.6 2.2 6 2.2s4.4-.8 6-2.2" fill="none" stroke="#F3D9A4" stroke-width="1"/>',
        'brand-novalife' => '
            <rect x="3" y="10" width="4" height="11" fill="#334155"/>
            <rect x="8.5" y="5" width="4" height="16" fill="#475569"/>
            <rect x="14" y="12" width="4" height="9" fill="#334155"/>
            <rect x="19" y="8" width="2" height="13" fill="#64748B"/>',
        'brand-gmod' => '
            <circle cx="12" cy="12" r="10" fill="#F97316"/>
            <path d="M9 6.5a4 4 0 105 4.9l4-.4-.3 2.4-3.9.6A4 4 0 118.4 8l.6-1.5z" fill="#fff"/>',
        'brand-hytale' => '
            <path d="M6 3l3.5 3.5L6 10l3.5 3.5L6 17l3.5 3.5L11 19l-2.7-2.7L11 13.5 8.3 10.8 11 8.2 8.3 5.5 11 2.8 9.5 1.3 6 3z" fill="#3DA5D9"/>
            <path d="M14 3l3.5 3.5L14 10l3.5 3.5L14 17l3.5 3.5L19 19l-2.7-2.7 2.7-2.8-2.7-2.7 2.7-2.6-2.7-2.7 2.7-2.7L17.5 1.3 14 3z" fill="#F2B807"/>',
        'brand-beammp' => '
            <circle cx="12" cy="12" r="10" fill="#111827"/>
            <path d="M4 15a8 8 0 0116 0" fill="none" stroke="#F59E0B" stroke-width="2"/>
            <path d="M12 15l3.5-5" stroke="#EF4444" stroke-width="2" stroke-linecap="round"/>
            <circle cx="12" cy="15" r="1.4" fill="#F59E0B"/>',
        'brand-ets2' => '
            <rect x="2" y="12" width="13" height="6" rx="1" fill="#DC2626"/>
            <rect x="14" y="9" width="6" height="9" rx="1" fill="#F3F4F6"/>
            <rect x="15" y="11" width="3.5" height="3" fill="#93C5FD"/>
            <circle cx="7" cy="19" r="1.8" fill="#111827"/><circle cx="17" cy="19" r="1.8" fill="#111827"/>',
        'brand-cs2' => '
            <rect x="3" y="3" width="18" height="18" rx="3" fill="#F59E0B"/>
            <path d="M7 12h10M12 7v10" stroke="#111827" stroke-width="2"/>
            <circle cx="12" cy="12" r="3" fill="none" stroke="#111827" stroke-width="1.6"/>',
        'brand-rust' => '
            <circle cx="12" cy="12" r="10" fill="#A33B20"/>
            <path d="M12 5l1.6 3.2 3.5.5-2.5 2.5.6 3.5L12 13l-3.2 1.7.6-3.5-2.5-2.5 3.5-.5L12 5z" fill="#E0863F"/>',
        'brand-ark' => '
            <path d="M2 17c4-8 8-11 10-13 2 2 6 5 10 13-3-2-6.5-3-10-3s-7 1-10 3z" fill="#2F6D3B"/>
            <path d="M12 4c1.5 3 2 6.5 1.6 10.2h-3.2C10 10.5 10.5 7 12 4z" fill="#8BC34A"/>',
        'brand-palworld' => '
            <circle cx="12" cy="12" r="10" fill="#fff" stroke="#1F2937" stroke-width="1.4"/>
            <path d="M2.3 12a9.7 9.7 0 0119.4 0z" fill="#EF4444"/>
            <circle cx="12" cy="12" r="3.4" fill="#1F2937"/>
            <circle cx="12" cy="12" r="1.6" fill="#fff"/>',
        'brand-7dtd' => '
            <circle cx="12" cy="12" r="10" fill="#4B5320"/>
            <path d="M8 6.5c-1.5 2-1.8 4.7-.6 6.7.4-1 1.2-1.8 1.2-1.8-.2 1.3.2 2.7 1.2 3.6-.1-1 .2-1.9.8-2.6.2 1.1 1 2 2 2.3-.5-1.2-.3-2.6.6-3.6.5 1 1.6 1.6 1.6 1.6.2-1.8-.5-3.6-1.9-4.8-1.7-1.4-4-1.7-4.9-1.4z" fill="#D1D5B0"/>',
    ];
    $c = $class ? ' class="' . h($class) . '"' : '';
    if (isset($brands[$name])) {
        return '<svg' . $c . ' viewBox="0 0 24 24" aria-hidden="true">' . $brands[$name] . '</svg>';
    }
    return icon('check', $class);
}

/**
 * Logo de marque/produit — cherche un PNG déposé par l'utilisateur dans
 * /assets/img/logos/, et ne retombe sur l'icône SVG maison que si le
 * fichier n'existe pas encore. Voir README pour la liste des noms de
 * fichiers attendus.
 *
 * Ordre de recherche :
 *   1. /assets/img/logos/<productKey>.png   (logo spécifique à l'offre)
 *   2. /assets/img/logos/<brandSlug>.png    (logo de marque partagé,
 *      déduit de l'icône de repli 'brand-xxx' → 'xxx')
 *   3. icône SVG maison (fallback garanti, jamais d'image cassée)
 */
function brand(string $productKey, string $fallbackIcon, string $class = '', bool $eager = false): string
{
    static $dir = null;
    if ($dir === null) $dir = __DIR__ . '/../assets/img/logos/';

    $candidates = [$productKey];
    if (str_starts_with($fallbackIcon, 'brand-')) {
        $candidates[] = substr($fallbackIcon, 6);
    }

    foreach ($candidates as $name) {
        if (is_readable($dir . $name . '.png')) {
            $c = $class ? ' class="' . h($class) . '"' : '';
            // $eager : pour un logo déjà visible au chargement (en-tête de
            // page), le différer ne fait que retarder l'affichage.
            $load = $eager ? ' fetchpriority="high"' : ' loading="lazy"';
            return '<img' . $c . ' src="/assets/img/logos/' . rawurlencode($name) . '.png?v=' . ASSET_VERSION . '" alt="" width="28" height="28"' . $load . ' decoding="async">';
        }
    }
    return icon($fallbackIcon, $class);
}

/** Icône SVG inline (jeu d'icônes maison, trait 1.7). */
function icon(string $name, string $class = ''): string
{
    if (str_starts_with($name, 'brand-')) {
        return brandIcon($name, $class);
    }
    static $paths = [
        'globe'    => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/>',
        'layers'   => '<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
        'terminal' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M13 15h4"/>',
        'window'   => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/>',
        'feather'  => '<path d="M20 4c0 8-6 13-13 13H4l3-3c0-7 5-10 13-10z"/><path d="M4 20l7-7"/>',
        'cube'     => '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path d="M4 7.5l8 4.5 8-4.5M12 12v9"/>',
        'car'      => '<path d="M5 16h14M6 16l1.5-5A2 2 0 019.4 9.6h5.2a2 2 0 011.9 1.4L18 16"/><rect x="3" y="16" width="18" height="4" rx="1"/><path d="M7 20v1M17 20v1"/>',
        'city'     => '<path d="M3 21V9l6-3v15M9 21V3l6 3v15M15 21v-9l6 3v6"/>',
        'wrench'   => '<path d="M15 5a4 4 0 105 5l-9 9-4 1 1-4 7-11z"/>',
        'sword'    => '<path d="M14 3h7v7L11 20l-3 1 1-3L14 3z"/><path d="M5 19l3 3"/>',
        'gauge'    => '<path d="M4 18a9 9 0 1116 0"/><path d="M12 14l4-4"/>',
        'bot'      => '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 14h.01M15 14h.01"/>',
        'gamepad'  => '<rect x="2" y="7" width="20" height="11" rx="4"/><path d="M7 11v3M5.5 12.5h3M16 12h.01M18 14h.01"/>',
        'server'   => '<rect x="3" y="4" width="18" height="7" rx="1"/><rect x="3" y="14" width="18" height="6" rx="1"/><path d="M7 7.5h.01M7 17h.01"/>',
        'shield'   => '<path d="M12 3l8 3v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V6l8-3z"/>',
        'building' => '<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M9 7h.01M15 7h.01M9 11h.01M15 11h.01M9 15h.01M15 15h.01"/>',
        'lock'     => '<rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/>',
        'link'     => '<path d="M10 13a4 4 0 006 .5l2-2a4 4 0 10-5.7-5.7l-1 1"/><path d="M14 11a4 4 0 00-6-.5l-2 2A4 4 0 009.7 18l1-1"/>',
        'mail'     => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
        'database' => '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
        'route'    => '<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h6a4 4 0 000-8H10a4 4 0 010-8"/>',
        'archive'  => '<rect x="3" y="4" width="18" height="4" rx="1"/><path d="M5 8v11h14V8M10 12h4"/>',
        'rack'     => '<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M4 9h16M4 15h16M8 6h.01M8 12h.01M8 18h.01"/>',
        'flame'    => '<path d="M12 3s5 4 5 9a5 5 0 01-10 0c0-2 1-3 1-3s1 2 2 2 2-4 2-8z"/>',
        'paw'      => '<circle cx="7" cy="9" r="2"/><circle cx="12" cy="7" r="2"/><circle cx="17" cy="9" r="2"/><path d="M12 12c-3 0-5 2-5 4.5S9 21 12 21s5-2 5-4.5S15 12 12 12z"/>',
        'leaf'     => '<path d="M20 4C10 4 4 9 4 16v4h4c7 0 12-6 12-16z"/><path d="M9 15l6-6"/>',
        'user'     => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>',
        'lifebuoy' => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M5.6 5.6l3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9"/>',
        'activity' => '<path d="M3 12h4l3 8 4-16 3 8h4"/>',
        'discord'  => '<path d="M8.5 7.5a14 14 0 017 0M7 17a14 14 0 0010 0"/><path d="M8.5 7.5C6 8 4.5 10 4 13c-.4 2.4 0 4 1 4.7 1 .7 2 0 2-1.7M15.5 7.5c2.5.5 4 2.5 4.5 5.5.4 2.4 0 4-1 4.7-1 .7-2 0-2-1.7"/><path d="M9.5 13h.01M14.5 13h.01"/>',
        'book'     => '<path d="M4 5a2 2 0 012-2h13v18H6a2 2 0 01-2-2V5z"/><path d="M8 3v18"/>',
        'bolt'     => '<path d="M13 3L5 14h6l-1 7 8-11h-6l1-7z"/>',
        'chat'     => '<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>',
        'chart'    => '<path d="M3 3v18h18"/><path d="M7 14l4-4 3 3 5-6"/>',
        'arrow'    => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'check'    => '<path d="M20 6L9 17l-5-5"/>',
        'chevron'  => '<path d="M6 9l6 6 6-6"/>',
        'close'    => '<path d="M18 6L6 18M6 6l12 12"/>',
        'menu'     => '<path d="M3 6h18M3 12h18M3 18h18"/>',
        'sun'      => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
        'moon'     => '<path d="M20 14a8 8 0 01-10-10 8 8 0 1010 10z"/>',
        'external' => '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V7a1 1 0 011-1h5"/>',
        'clock'    => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'flag'     => '<path d="M5 21V4h14l-3 4 3 4H5"/>',
        'euro'     => '<path d="M17 6a7 7 0 100 12M4 10h8M4 14h8"/>',
        'cookie'   => '<path d="M12 3a9 9 0 109 9 4 4 0 01-5-5 3 3 0 01-4-4z"/><path d="M9 10h.01M14 14h.01M10 16h.01"/>',
        'search'   => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
        'swap'     => '<path d="M7 4v13M7 4L3 8M7 4l4 4M17 20V7M17 20l4-4M17 20l-4-4"/>',
        'cpu'      => '<rect x="6" y="6" width="12" height="12" rx="1.5"/><rect x="9.5" y="9.5" width="5" height="5" rx=".5"/><path d="M9 3v3M12 3v3M15 3v3M9 18v3M12 18v3M15 18v3M3 9h3M3 12h3M3 15h3M18 9h3M18 12h3M18 15h3"/>',
        'memory'   => '<rect x="3" y="7" width="18" height="10" rx="1.5"/><path d="M7 10.5v3M10.5 10.5v3M14 10.5v3M17.5 10.5v3M6 17v2M10 17v2M14 17v2M18 17v2"/>',
        'disk'     => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 14h18"/><circle cx="17" cy="16.5" r=".6" fill="currentColor"/><path d="M7 16.5h5"/>',
        'pin'      => '<path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0113 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.4"/>',
        'shieldok' => '<path d="M12 3l7.5 3v5.5c0 4.8-3.2 8.2-7.5 9.5-4.3-1.3-7.5-4.7-7.5-9.5V6L12 3z"/><path d="M8.8 12.2l2.2 2.2 4.4-4.6"/>',
        'users'    => '<circle cx="9" cy="8" r="3.2"/><path d="M3 19.5c.6-3.3 3-5.2 6-5.2s5.4 1.9 6 5.2"/><path d="M15.5 4.9a3.2 3.2 0 010 6.2M21 19.5c-.4-2.4-1.8-4-3.8-4.7"/>',
        'migrate'  => '<path d="M4 7h11M11 3l4 4-4 4M20 17H9M13 13l-4 4 4 4"/>',
        'gift'     => '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M19 12v7a2 2 0 01-2 2H7a2 2 0 01-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 010-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 010 5"/>',
        'coin'     => '<circle cx="12" cy="12" r="8.5"/><path d="M14.8 9.2c-.5-.9-1.6-1.5-2.8-1.5-1.7 0-2.9.9-2.9 2.1 0 2.9 5.9 1.5 5.9 4.4 0 1.2-1.3 2.1-3 2.1-1.3 0-2.4-.6-2.9-1.5M12 6v1.7M12 16.3V18"/>',
    ];
    $p = $paths[$name] ?? $paths['check'];
    $c = $class ? ' class="' . h($class) . '"' : '';
    return '<svg' . $c . ' viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

/** Drapeau simplifié pour le sélecteur de langue. */
function flag(string $lang): string
{
    static $flags = [
        'fr' => '<rect width="8" height="16" fill="#0B3D91"/><rect x="8" width="8" height="16" fill="#fff"/><rect x="16" width="8" height="16" fill="#C8102E"/>',
        'en' => '<rect width="24" height="16" fill="#012169"/><path d="M0 0l24 16M24 0L0 16" stroke="#fff" stroke-width="3"/><path d="M12 0v16M0 8h24" stroke="#fff" stroke-width="5"/><path d="M12 0v16M0 8h24" stroke="#C8102E" stroke-width="3"/>',
        'de' => '<rect width="24" height="5.33" fill="#000"/><rect y="5.33" width="24" height="5.33" fill="#DD0000"/><rect y="10.66" width="24" height="5.34" fill="#FFCE00"/>',
        'es' => '<rect width="24" height="16" fill="#AA151B"/><rect y="4" width="24" height="8" fill="#F1BF00"/>',
    ];
    return '<svg class="flag" viewBox="0 0 24 16" aria-hidden="true">' . ($flags[$lang] ?? '') . '</svg>';
}
