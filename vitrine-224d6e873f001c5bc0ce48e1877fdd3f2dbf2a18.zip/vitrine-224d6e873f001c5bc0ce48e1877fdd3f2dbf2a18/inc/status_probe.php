<?php
/**
 * Mesure la disponibilité des services publics (STATUS_SERVICES) en
 * parallèle. Partagée par api/status.php et l'assistant.
 */

declare(strict_types=1);

function status_probe(): array
{
    $multi   = curl_multi_init();
    $handles = [];

    foreach (STATUS_SERVICES as $svc) {
        $ch = curl_init($svc['url']);
        curl_setopt_array($ch, [
            CURLOPT_NOBODY         => true,
            CURLOPT_CUSTOMREQUEST  => 'HEAD',
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'ArtaunStatusPage/2.0',
        ]);
        curl_multi_add_handle($multi, $ch);
        $handles[$svc['id']] = $ch;
    }

    $running = null;
    do {
        curl_multi_exec($multi, $running);
        if ($running > 0) curl_multi_select($multi, 0.1);
    } while ($running > 0);

    $services = [];
    foreach (STATUS_SERVICES as $svc) {
        $ch      = $handles[$svc['id']];
        $latency = (int) round((float) curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000);
        $code    = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errno   = curl_errno($ch);

        if ($errno !== 0 || $code === 0 || $code >= 500) {
            $state = 'down';
        } elseif ($latency > 800 /* ms : au-delà, service « lent » */) {
            $state = 'warn';
        } else {
            $state = 'up';
        }

        $services[] = [
            'id'      => $svc['id'],
            'group'   => $svc['group'],
            'state'   => $state,
            'latency' => $latency,
            'code'    => $code,
        ];

        curl_multi_remove_handle($multi, $ch);
        curl_close($ch);
    }
    curl_multi_close($multi);

    return $services;
}
