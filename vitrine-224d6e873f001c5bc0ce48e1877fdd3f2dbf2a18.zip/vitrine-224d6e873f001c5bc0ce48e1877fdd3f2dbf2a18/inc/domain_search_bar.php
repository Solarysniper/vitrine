<?php
/**
 * Barre de recherche de domaine — un seul champ, qui gère à la fois
 * l'achat (domaine libre) et le transfert (domaine déjà pris), sans
 * bascule séparée : voir assets/js/domain-search.js.
 *
 * Variables attendues avant l'include :
 *   $showAllLink (bool, défaut true) — affiche "Voir toutes les extensions"
 *     sous les extensions populaires (à masquer sur la page /domaines/,
 *     puisqu'on y est déjà).
 */
$showAllLink = $showAllLink ?? true;
$popularExts = ['fr', 'com', 'eu', 'xyz'];
require_once __DIR__ . '/domain_prices.php';
$allPrices = load_domain_prices();
?>
<div class="domain-box">
  <?php if (!empty($domainTitle)): ?><p class="domain-box-title"><?= icon('globe') ?><?= e('v2.domains.title') ?></p><?php endif; ?>
  <form id="domain-search-form" class="domain-search-form">
    <div class="domain-search-row">
      <span class="domain-search-icon"><?= icon('search') ?></span>
      <input type="text" data-domain-field placeholder="<?= e('domain.placeholder') ?>" autocomplete="off" spellcheck="false" required>
      <button type="submit" class="btn btn-primary"><?= e('domain.search_btn') ?></button>
    </div>
  </form>

  <div id="domain-search-result" class="domain-result" hidden></div>

  <div class="domain-popular">
    <?php foreach ($popularExts as $ext): if (!isset($allPrices[$ext])) continue; ?>
      <button type="button" class="domain-pill" data-domain-quick="<?= h($ext) ?>">
        .<?= h($ext) ?> <span><?= money((float) $allPrices[$ext]['register']) ?>/<?= e('domain.per_year_short') ?></span>
      </button>
    <?php endforeach; ?>
    <?php if ($showAllLink): ?>
      <a class="domain-see-all" href="<?= h(url('domains')) ?>"><?= e('domain.see_all', count($allPrices)) ?><?= icon('arrow') ?></a>
    <?php endif; ?>
  </div>
</div>
