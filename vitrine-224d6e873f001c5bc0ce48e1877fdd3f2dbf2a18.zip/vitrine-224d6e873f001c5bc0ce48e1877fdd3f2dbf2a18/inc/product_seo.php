<?php
/**
 * Bloc éditorial d'une fiche de jeu (référencement) : présentation selon le genre, matériel, types de serveur,
 * et tableau « Quelle offre choisir ? ». Uniquement pour les serveurs de jeu ($product, $data, $plans, $name, $cpu).
 */
if (($data['category'] ?? '') !== 'game') return;
$seoGenre = $data['subcategory'] ?? 'sandbox';
$seoVariants = array_values(array_unique(array_filter((array) ($data['variants'] ?? []))));
$seoMods = (bool) preg_grep('/bepinex|oxide|umod|mod|plus|exiled|torch|loader|forge|fabric|tshock|smapi/i', $seoVariants);
$seoAud = fn(int $i) => t('v4.aud.' . (int) round(1 + $i * 4 / max(1, count($plans) - 1)));
?>
<section class="sec about">
  <div class="wrap about-grid">
    <div class="about-text">
      <h2><?= e('v4.about.title', $name) ?></h2>
      <?php if (has('v4.about.genre.' . $seoGenre)): ?><p><?= e('v4.about.genre.' . $seoGenre, $name) ?></p><?php endif; ?>
      <p><?= e('v4.about.infra', $name, $cpu['model'], infra_ghz($cpu['ghz'])) ?></p>
      <?php if (count($seoVariants) > 1): ?><p><?= e('v4.about.variants', implode(', ', $seoVariants)) ?></p><?php endif; ?>
      <?php if ($seoMods): ?><p><?= e('v4.about.mods') ?></p><?php endif; ?>
    </div>
    <div class="about-table">
      <h3><?= e('v4.about.choose', $name) ?></h3>
      <div class="table-wrap">
        <table class="plan-table">
          <thead><tr><th><?= e('v4.about.th.plan') ?></th><th><?= e('v4.about.th.res') ?></th><th><?= e('v4.about.th.for') ?></th><th><?= e('v4.about.th.price') ?></th></tr></thead>
          <tbody>
            <?php foreach ($plans as $i => $plan):
              $res = [];
              foreach ($plan['specs'] as $sp) if (in_array($sp[0], ['cpu', 'ram', 'ssd', 'nvme'], true)) $res[] = spec($sp); ?>
            <tr>
              <td><b><?= h($plan['name']) ?></b></td>
              <td><?= h(implode(' · ', array_map(fn($s) => preg_replace('/\s*\(.*\)$|\s*Intel Xeon Gold \S+/u', '', $s), $res))) ?></td>
              <td><?= h(count($plans) >= 3 && count($plans) <= 5 ? $seoAud($i) : '') ?></td>
              <td><b><?= money((float) $plan['price']) ?></b><small><?= e('price.per') ?></small></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p class="about-note"><?= e('v4.about.choose_note') ?></p>
    </div>
  </div>
</section>
