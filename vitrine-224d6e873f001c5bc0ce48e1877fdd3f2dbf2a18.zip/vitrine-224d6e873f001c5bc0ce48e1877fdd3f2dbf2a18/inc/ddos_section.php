<?php
/**
 * Protection Anti-DDoS Netrix (pages d'offres et accueil) : quelques faits, un schéma du parcours du trafic
 * (vertical sur téléphone) et les trois étapes. Pas d'animation ni de simulation.
 */
?>
<section class="sec prot" id="anti-ddos">
  <div class="wrap">
    <div class="prot-grid">
      <div class="prot-copy">
        <p class="eyebrow"><?= e('v4.prot.eyebrow') ?></p>
        <h2><?= e('v4.prot.title') ?></h2>
        <p class="sec-lead"><?= e('v4.prot.lead') ?></p>
        <ul class="prot-facts">
          <li><b><?= h(INFRA['ddos']['capacity']) ?></b><span><?= e('v4.prot.f1') ?></span></li>
          <li><b><?= h(INFRA['ddos']['layers']) ?></b><span><?= e('v4.prot.f2') ?></span></li>
          <li><b><?= e('v4.prot.f3v') ?></b><span><?= e('v4.prot.f3') ?></span></li>
        </ul>
      </div>
      <figure class="prot-flow" aria-label="<?= e('v4.prot.flow') ?>">
        <div class="prot-node prot-in">
          <span><?= icon('users') ?><?= e('v4.prot.n1') ?></span>
          <span class="prot-bad"><?= icon('bolt') ?><?= e('v4.prot.n1b') ?></span>
        </div>
        <span class="prot-arrow" aria-hidden="true"></span>
        <div class="prot-node prot-netrix"><?= icon('shieldok') ?><b>Netrix</b><small><?= e('v4.prot.n2') ?></small></div>
        <span class="prot-arrow prot-arrow-ok" aria-hidden="true"></span>
        <div class="prot-node"><?= icon('pin') ?><b>Artaun · <?= e('v4.stat.paris_v') ?></b><small><?= e('v4.prot.n3') ?></small></div>
        <span class="prot-arrow prot-arrow-ok" aria-hidden="true"></span>
        <div class="prot-node prot-srv"><?= icon('server') ?><b><?= e('v4.ddos.server') ?></b><small class="prot-ok"><i></i><?= e('v4.hero.online') ?></small></div>
      </figure>
    </div>
    <ol class="prot-steps">
      <?php for ($n = 1; $n <= 3; $n++): ?>
      <li><b><?= e('v4.prot.s' . $n) ?></b><span><?= e('v4.prot.s' . $n . 'd') ?></span></li>
      <?php endfor; ?>
    </ol>
    <p class="prot-note"><?= e('v4.prot.note') ?></p>
  </div>
</section>
