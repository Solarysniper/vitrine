<?php
/**
 * Prix de vente des extensions de domaines.
 *
 * La vraie source est `inc/domain-prices.txt` — un fichier texte simple,
 * pensé pour être modifié directement (nouveau prix, nouvelle extension)
 * sans toucher à du code PHP. Ce fichier-ci ne fait que le lire et le
 * transformer en tableau ['ext' => ['register'=>.., 'renew'=>.., 'transfer'=>..]].
 *
 * Ce n'est toujours qu'une PHOTO à un instant T : ce site vitrine n'a pas
 * accès à la base ClientXCMS en direct. Pour un prix modifié dans l'admin,
 * modifiez la même valeur dans domain-prices.txt.
 *
 * Usage : `require_once __DIR__ . '/domain_prices.php'; $prices = load_domain_prices();`
 * — jamais `$prices = require ...` directement : ce fichier ne fait que
 * déclarer la fonction (avec son propre cache interne), il ne s'exécute
 * plus tout seul au chargement. Ça permet de l'inclure depuis plusieurs
 * endroits dans la même page (ex: une page qui inclut elle-même le
 * composant de recherche, qui a lui aussi besoin des prix) sans jamais
 * déclencher d'erreur "impossible de redéclarer la fonction".
 */

if (!function_exists('load_domain_prices')) {

function load_domain_prices(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    // Copie synchronisée depuis ClientXCMS (var/) si présente, sinon le fichier livré.
    $path = is_readable(__DIR__ . '/../var/domain-prices.txt') ? __DIR__ . '/../var/domain-prices.txt' : __DIR__ . '/domain-prices.txt';
    if (!is_readable($path)) {
        return $cache = [];
    }

    $prices = [];
    $current = null;
    $values = [];

    $flush = function () use (&$prices, &$current, &$values) {
        if ($current === null || $values === []) {
            return;
        }
        $register = $values['achat'] ?? $values['renouvellement'] ?? 0.0;
        $renew = $values['renouvellement'] ?? $register;
        $transfer = $values['transfert'] ?? $renew;
        $prices[$current] = ['register' => $register, 'renew' => $renew, 'transfer' => $transfer];
    };

    foreach (file($path, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '') {
            $flush();
            $current = null;
            $values = [];
            continue;
        }
        if (str_starts_with($line, '#')) {
            continue;
        }

        if (str_contains($line, '=')) {
            [$key, $val] = array_map('trim', explode('=', $line, 2));
            $key = mb_strtolower($key);
            // Virgule française ou point : les deux acceptés.
            $val = (float) str_replace(',', '.', preg_replace('/[^0-9,.\-]/', '', $val));
            $values[$key] = $val;
        } else {
            // Nouvelle extension : on clôt la précédente d'abord.
            $flush();
            $current = mb_strtolower(ltrim($line, '.'));
            $values = [];
        }
    }
    $flush(); // dernier bloc du fichier, jamais suivi d'une ligne vide

    return $cache = $prices;
}

}
