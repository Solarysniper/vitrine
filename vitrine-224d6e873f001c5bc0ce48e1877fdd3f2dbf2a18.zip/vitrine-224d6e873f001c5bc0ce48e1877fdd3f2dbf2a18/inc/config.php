<?php
/**
 * Artaun Hosting — Configuration centrale
 * Tout le catalogue, les liens externes et la navigation vivent ici.
 * Un prix modifié ici se répercute sur les 4 langues.
 */

// --------------------------------------------------------------------------
// Identité & liens externes
// --------------------------------------------------------------------------
// Numéro de version des fichiers CSS/JS : on l'incrémente à chaque
// modification d'un asset pour que les navigateurs cessent de servir
// l'ancienne version depuis leur cache (les assets sont mis en cache un an).
const ASSET_VERSION = '76';

const SITE_NAME   = 'Artaun Hosting';
const SITE_URL    = 'https://artaun.fr';
const SITE_EMAIL  = 'support@artaun.fr';
const SITE_ABUSE  = 'abuse@artaun.fr';

const LINKS = [
    'clients'   => 'https://clients.artaun.fr',
    'login'     => 'https://clients.artaun.fr/login',
    'register'  => 'https://clients.artaun.fr/register',
    'store'     => 'https://clients.artaun.fr/store',
    'panel'     => 'https://panel.artaun.fr',
    'plesk'     => 'https://plesk.artaun.fr',
    'support'   => 'https://clients.artaun.fr/client/support',
    'docs'      => 'https://docs.artaun.fr',
    'discord'   => 'https://discord.artaun.fr',
];

// ID du produit "Noms de domaines" côté ClientXCMS (Admin > Boutique >
// Produits) — sert à construire les liens directs et pré-remplis vers la
// page de configuration du panier (achat ou transfert). Si ce produit
// change d'ID côté ClientXCMS, mettre à jour cette valeur ici suffit.
const DOMAIN_PRODUCT_ID = 72;

/**
 * Lien pré-rempli vers la page "Configurez votre offre" du panier
 * ClientXCMS, pour un domaine et une extension donnés. $transfer=true
 * ajoute le paramètre attendu par l'addon de domaines pour traiter la
 * commande comme un transfert plutôt qu'un enregistrement classique.
 */
function domain_buy_url(string $domain, string $tld, bool $transfer = false): string
{
    $params = [
        'domain' => $domain,
        'tld' => '.' . ltrim($tld, '.'),
        'billing' => 'annually',
    ];
    if ($transfer) {
        $params['operation'] = 'transfer';
    }

    return LINKS['store'] . '/basket/config/' . DOMAIN_PRODUCT_ID . '?' . http_build_query($params);
}

// Langues — l'ordre pilote l'affichage du sélecteur
const LANGS = [
    'fr' => ['label' => 'Français', 'locale' => 'fr_FR', 'hreflang' => 'fr'],
    'en' => ['label' => 'English',  'locale' => 'en_GB', 'hreflang' => 'en'],
    'de' => ['label' => 'Deutsch',  'locale' => 'de_DE', 'hreflang' => 'de'],
    'es' => ['label' => 'Español',  'locale' => 'es_ES', 'hreflang' => 'es'],
];
const LANG_DEFAULT = 'fr';

/**
 * Options modifiables sans toucher au code : config/options.ini (lu à chaque requête,
 * pas de cache PHP ; le cache des pages prend la date du fichier dans son empreinte).
 */
function site_option(string $key): bool
{
    static $opts = null;
    if ($opts === null) {
        $opts = @parse_ini_file(__DIR__ . '/../config/options.ini', false, INI_SCANNER_TYPED) ?: [];
        // Aperçu en ligne de commande seulement (rendu de test) : VITRINE_OPTIONS=nouveaux_jeux php ...
        if (PHP_SAPI === 'cli' && is_string($force = getenv('VITRINE_OPTIONS'))) {
            foreach (array_filter(array_map('trim', explode(',', $force))) as $k) $opts[$k] = true;
        }
    }
    return ($opts[$key] ?? false) === true;
}

/** Fiches des nouveaux jeux (inc/games-extra.php), vides tant que l'option « nouveaux_jeux » est à false. */
function games_extra(): array
{
    static $extra = null;
    if ($extra === null) {
        $extra = site_option('nouveaux_jeux') ? (array) require __DIR__ . '/games-extra.php' : [];
    }
    return $extra;
}

// --------------------------------------------------------------------------
// Catégories de jeux (mega-menu "Jeux" replié par thème, avec compteur)
// --------------------------------------------------------------------------
// Chaque jeu (CATALOG, category = 'game' ou 'bot') porte une clé
// 'subcategory' qui le range dans un de ces groupes. L'ordre ci-dessous
// pilote l'ordre d'affichage des groupes dans le mega-menu et le tiroir
// mobile. Un groupe sans aucun jeu ne s'affiche pas.
const GAME_SUBCATS = [
    'roleplay'   => ['icon' => 'brand-roleplay'],
    'survival'   => ['icon' => 'brand-survival'],
    'sandbox'    => ['icon' => 'brand-sandbox'],
    'simulation' => ['icon' => 'brand-simulation'],
    'fps'        => ['icon' => 'brand-fps'],
    'strategy'   => ['icon' => 'brand-strategy'],
    'utility'    => ['icon' => 'bot'],
];

// --------------------------------------------------------------------------
// Catalogue
// --------------------------------------------------------------------------
// Chaque offre : nom (non traduit, c'est un nom commercial), prix mensuel,
// identifiant panier, spécifications structurées.
// Les specs sont des tokens rendus par spec() dans i18n.php → pas de texte
// à traduire douze fois.
//
// Tokens disponibles : cpu(cores, ghz[, modèle]) · ram(go) · ssd(go) ·
// nvme(go) · ip(n) · net(débit) · ddos · panel(nom) · geo · domains ·
// db(n) · dbu · ssl · ftp · mail(n, go) · mailu(go) · accounts(n) ·
// accountsu · bw · ddosssl · mods · slots · restart · ipded

// AJOUTER UNE OFFRE SANS TRADUIRE QUATRE FOIS
// ------------------------------------------
// La clé facultative 'text' porte les textes du produit directement ici.
// '*' sert à toutes les langues ; une langue nommée écrase '*' si vous voulez
// affiner plus tard. Sans 'text', les textes sont cherchés dans lang/content/product.json.
//
// ⚠️ SKU À VÉRIFIER : chaque nouvelle offre ajoutée lors de cette refonte
// (jeux, Mail Pro, VPS KVM, IP supplémentaire, Revendeur VPS...) porte un
// 'sku' provisoire (souvent 0) tant que le produit correspondant n'existe
// pas encore côté ClientXCMS (Admin > Boutique > Produits). Créez le
// produit là-bas puis reportez son ID ici — c'est la SEULE étape requise,
// le bouton "Acheter" pointera alors automatiquement vers la bonne fiche.
//
// Il apparaît automatiquement dans le mega-menu, le tiroir mobile et les
// 4 langues — aucune autre étape n'est nécessaire.

const CATALOG_BASE = [

    // ---------------------------------------------------------------- WEB
    'web-hosting' => [
        'category' => 'web',
        'icon'     => 'brand-plesk',
        'from'     => 2.00,
        'plans'    => [
            ['name' => 'Pack Starter', 'price' => 2.00, 'sku' => 10, 'specs' => [
                ['nvme', 20], ['domains'], ['db', 10], ['ssl'], ['ftp'], ['mail', 10, 1], ['ddos'],
            ]],
            ['name' => 'Pack Premium', 'price' => 4.00, 'sku' => 11, 'popular' => true, 'specs' => [
                ['nvme', 35], ['domains'], ['db', 15], ['ssl'], ['ftp'], ['mailu', 2], ['ddos'],
            ]],
            ['name' => 'Pack Pro', 'price' => 6.00, 'sku' => 12, 'specs' => [
                ['nvme', 60], ['domains'], ['dbu'], ['ssl'], ['ftp'], ['mailu', 2], ['ddos'],
            ]],
        ],
    ],

    'mail-pro' => [
        'category' => 'web',
        'icon'     => 'mail',
        'from'     => 0.99,
        'text'     => [
            '*' => [
                'name'    => 'Mail Pro',
                'tagline' => 'Boîtes e-mail professionnelles',
                'title'   => 'Hébergement Mail Pro',
                'lead'    => 'Des boîtes e-mail professionnelles sur votre propre domaine, avec webmail, anti-spam et synchronisation IMAP/ActiveSync sur mobile.',
            ],
            'en' => [
                'name' => 'Mail Pro', 'tagline' => 'Professional mailboxes',
                'title' => 'Mail Pro hosting',
                'lead' => 'Professional mailboxes on your own domain, with webmail, anti-spam and IMAP/ActiveSync sync on mobile.',
            ],
            'de' => [
                'name' => 'Mail Pro', 'tagline' => 'Professionelle Postfächer',
                'title' => 'Mail-Pro-Hosting',
                'lead' => 'Professionelle Postfächer auf Ihrer eigenen Domain, mit Webmail, Spamschutz und IMAP/ActiveSync-Synchronisierung auf dem Handy.',
            ],
            'es' => [
                'name' => 'Mail Pro', 'tagline' => 'Buzones profesionales',
                'title' => 'Alojamiento Mail Pro',
                'lead' => 'Buzones profesionales en su propio dominio, con webmail, antispam y sincronización IMAP/ActiveSync en el móvil.',
            ],
        ],
        'plans'    => [
            ['name' => 'Solo', 'price' => 0.99, 'sku' => 71, 'specs' => [
                ['mailbox', 5], ['nvme', 10], ['webmail'], ['mailsec'],
            ]],
            ['name' => 'Start', 'price' => 1.49, 'sku' => 105, 'popular' => true, 'specs' => [
                ['mailbox', 15], ['nvme', 25], ['webmail'], ['mailsec'],
            ]],
            ['name' => 'Pro', 'price' => 2.99, 'sku' => 106, 'specs' => [
                ['mailbox', 40], ['nvme', 75], ['webmail'], ['mailsec'],
            ]],
            ['name' => 'Illimité', 'price' => 4.99, 'sku' => 107, 'specs' => [
                ['mailboxu'], ['nvme', 200], ['webmail'], ['mailsec'],
            ]],
        ],
    ],

    'web-reseller' => [
        'category' => 'reseller',
        'icon'     => 'brand-plesk',
        'from'     => 5.99,
        'text'     => [
            '*' => ['name' => 'Revendeur Web', 'tagline' => 'Panel Plesk en marque blanche'],
            'en' => ['name' => 'Web Reseller', 'tagline' => 'White-label Plesk panel'],
            'de' => ['name' => 'Web-Reseller', 'tagline' => 'Plesk-Panel im White-Label'],
            'es' => ['name' => 'Revendedor Web', 'tagline' => 'Panel Plesk de marca blanca'],
        ],
        'plans'    => [
            ['name' => 'Revendeur Avancé', 'price' => 5.99, 'sku' => 36, 'specs' => [
                ['accounts', 35], ['domains'], ['nvme', 50], ['dbu'], ['mail', 20, 1], ['bw'], ['ddosssl'],
            ]],
            ['name' => 'Revendeur Pro', 'price' => 12.99, 'sku' => 37, 'popular' => true, 'specs' => [
                ['accounts', 75], ['domains'], ['nvme', 150], ['dbu'], ['mail', 50, 1], ['bw'], ['ddosssl'],
            ]],
            ['name' => 'Revendeur Elite', 'price' => 18.99, 'sku' => 38, 'specs' => [
                ['accountsu'], ['domains'], ['nvme', 200], ['dbu'], ['mailu', 2], ['bw'], ['ddosssl'],
            ]],
        ],
    ],

    // ---------------------------------------------------------------- VPS
    'vps-linux' => [
        'category' => 'vps',
        'icon'     => 'brand-linux',
        'from'     => 5.00,
        'plans'    => [
            ['name' => 'Offre Développeur', 'price' => 5.00, 'sku' => 31, 'specs' => [
                ['cpu', 2, '3.9', 'Intel Xeon Gold 6230'], ['ram', 4], ['nvme', 25], ['ip', 1], ['net', '200 Mb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'Offre Standard', 'price' => 10.00, 'sku' => 32, 'popular' => true, 'specs' => [
                ['cpu', 3, '3.9', 'Intel Xeon Gold 6230'], ['ram', 8], ['nvme', 50], ['ip', 1], ['net', '250 Mb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'Offre Avancée', 'price' => 15.00, 'sku' => 33, 'specs' => [
                ['cpu', 4, '3.9', 'Intel Xeon Gold 6230'], ['ram', 16], ['nvme', 100], ['ip', 1], ['net', '500 Mb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'Offre Pro', 'price' => 25.00, 'sku' => 34, 'specs' => [
                ['cpu', 6, '3.9', 'Intel Xeon Gold 6230'], ['ram', 32], ['nvme', 150], ['ip', 1], ['net', '1 Gb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'Offre Elite', 'price' => 40.00, 'sku' => 35, 'specs' => [
                ['cpu', 8, '3.9', 'Intel Xeon Gold 6230'], ['ram', 64], ['nvme', 200], ['ip', 1], ['net', '1 Gb/s'], ['ddos'], ['geo'],
            ]],
        ],
    ],

    'vps-kvm' => [
        'category' => 'vps',
        'icon'     => 'brand-kvm',
        'from'     => 5.00,
        'text'     => [
            '*' => [
                'name' => 'VPS KVM', 'tagline' => 'Virtualisation KVM, ressources garanties',
                'title' => 'VPS KVM — isolation totale',
                'lead'  => 'Virtualisation KVM avec cœurs dédiés et ressources garanties à 100 % : aucun voisin bruyant, des performances constantes pour vos charges les plus sensibles.',
            ],
            'en' => [
                'name' => 'KVM VPS', 'tagline' => 'KVM virtualization, guaranteed resources',
                'title' => 'KVM VPS — full isolation',
                'lead' => 'KVM virtualization with dedicated cores and 100% guaranteed resources: no noisy neighbours, consistent performance for your most sensitive workloads.',
            ],
            'de' => [
                'name' => 'KVM-VPS', 'tagline' => 'KVM-Virtualisierung, garantierte Ressourcen',
                'title' => 'KVM-VPS — vollständige Isolation',
                'lead' => 'KVM-Virtualisierung mit dedizierten Kernen und zu 100 % garantierten Ressourcen: keine störenden Nachbarn, konstante Leistung für Ihre sensibelsten Workloads.',
            ],
            'es' => [
                'name' => 'VPS KVM', 'tagline' => 'Virtualización KVM, recursos garantizados',
                'title' => 'VPS KVM — aislamiento total',
                'lead' => 'Virtualización KVM con núcleos dedicados y recursos garantizados al 100 %: sin vecinos ruidosos, rendimiento constante para sus cargas más sensibles.',
            ],
        ],
        'plans'    => [
            ['name' => 'KVM Start', 'price' => 5.00, 'sku' => 108, 'specs' => [
                ['cpu', 2, '3.9', 'Intel Xeon Gold 6230'], ['ram', 4], ['nvme', 40], ['ip', 1], ['net', '200 Mb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'KVM Standard', 'price' => 10.00, 'sku' => 109, 'popular' => true, 'specs' => [
                ['cpu', 3, '3.9', 'Intel Xeon Gold 6230'], ['ram', 8], ['nvme', 75], ['ip', 1], ['net', '500 Mb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'KVM Advanced', 'price' => 15.00, 'sku' => 110, 'specs' => [
                ['cpu', 4, '3.9', 'Intel Xeon Gold 6230'], ['ram', 16], ['nvme', 100], ['ip', 1], ['net', '1 Gb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'KVM Pro', 'price' => 25.00, 'sku' => 111, 'specs' => [
                ['cpu', 6, '3.9', 'Intel Xeon Gold 6230'], ['ram', 32], ['nvme', 160], ['ip', 1], ['net', '1 Gb/s'], ['ddos'], ['geo'],
            ]],
            ['name' => 'KVM Elite', 'price' => 40.00, 'sku' => 112, 'specs' => [
                ['cpu', 8, '3.9', 'Intel Xeon Gold 6230'], ['ram', 64], ['nvme', 250], ['ip', 1], ['net', '1 Gb/s'], ['ddos'], ['geo'],
            ]],
        ],
    ],

    'vps-windows' => [
        'category' => 'vps',
        'icon'     => 'brand-windows',
        'from'     => 8.99,
        'plans'    => [
            ['name' => 'Windows Starter', 'price' => 8.99, 'sku' => 51, 'specs' => [
                ['cpu', 2, '3.9', 'Intel Xeon Gold 6230'], ['ram', 4], ['nvme', 65], ['ip', 1], ['net', '1 Gb/s'], ['ddos'],
            ]],
            ['name' => 'Windows Medium', 'price' => 15.99, 'sku' => 52, 'popular' => true, 'specs' => [
                ['cpu', 4, '3.9', 'Intel Xeon Gold 6230'], ['ram', 8], ['nvme', 100], ['ip', 1], ['net', '1 Gb/s'], ['ddos'],
            ]],
            ['name' => 'Windows Ultimate', 'price' => 29.99, 'sku' => 53, 'specs' => [
                ['cpu', 8, '3.9', 'Intel Xeon Gold 6230'], ['ram', 16], ['nvme', 200], ['ip', 1], ['net', '1 Gb/s'], ['ddos'],
            ]],
        ],
    ],

    'vps-pterodactyl' => [
        'category' => 'reseller',
        'icon'     => 'brand-pterodactyl',
        'from'     => 5.00,
        'text'     => [
            '*' => ['name' => 'Revendeur Pterodactyl', 'tagline' => 'VPS avec panel revendeur pré-installé'],
            'en' => ['name' => 'Pterodactyl Reseller', 'tagline' => 'VPS with a preinstalled reseller panel'],
            'de' => ['name' => 'Pterodactyl-Reseller', 'tagline' => 'VPS mit vorinstalliertem Reseller-Panel'],
            'es' => ['name' => 'Revendedor Pterodactyl', 'tagline' => 'VPS con panel de revendedor preinstalado'],
        ],
        'plans'    => [
            ['name' => 'Ptero Développeur', 'price' => 5.00, 'sku' => 59, 'specs' => [
                ['cpu', 2, '3.9', 'Intel Xeon Gold 6230'], ['ram', 4], ['nvme', 25], ['ip', 1], ['net', '200 Mb/s'], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Ptero Standard', 'price' => 10.00, 'sku' => 60, 'popular' => true, 'specs' => [
                ['cpu', 3, '3.9', 'Intel Xeon Gold 6230'], ['ram', 8], ['nvme', 50], ['ip', 1], ['net', '250 Mb/s'], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Ptero Avancée', 'price' => 15.00, 'sku' => 61, 'specs' => [
                ['cpu', 4, '3.9', 'Intel Xeon Gold 6230'], ['ram', 16], ['nvme', 100], ['ip', 1], ['net', '500 Mb/s'], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Ptero Pro', 'price' => 25.00, 'sku' => 62, 'specs' => [
                ['cpu', 6, '3.9', 'Intel Xeon Gold 6230'], ['ram', 32], ['nvme', 150], ['ip', 1], ['net', '1 Gb/s'], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Ptero Elite', 'price' => 40.00, 'sku' => 63, 'specs' => [
                ['cpu', 8, '3.9', 'Intel Xeon Gold 6230'], ['ram', 64], ['nvme', 200], ['ip', 1], ['net', '1 Gb/s'], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
        ],
    ],

    'reseller-vps' => [
        'category' => 'reseller',
        'icon'     => 'brand-proxmox',
        'from'     => 18.99,
        // Techniquement des VM Proxmox à ressources dédiées, mais commercialisées
        // simplement sous le nom "Revendeur VPS" — jamais "VDS" côté client.
        'text'     => [
            '*' => [
                'name' => 'Revendeur VPS', 'tagline' => 'Votre propre offre VPS en marque blanche',
                'title' => 'Revendeur VPS — infrastructure Proxmox',
                'lead'  => 'Une tranche dédiée de notre cluster Proxmox, à revendre comme bon vous semble : créez vos propres offres VPS pour vos clients, avec une isolation et des ressources garanties.',
            ],
            'en' => [
                'name' => 'VPS Reseller', 'tagline' => 'Your own white-label VPS offer',  // tagline OK
                'title' => 'VPS Reseller — Proxmox infrastructure',
                'lead' => 'A dedicated slice of our Proxmox cluster, to resell as you see fit: build your own VPS offers for your clients, with guaranteed isolation and resources.',
            ],
            'de' => [
                'name' => 'VPS-Reseller', 'tagline' => 'Ihr eigenes White-Label-VPS-Angebot',
                'title' => 'VPS-Reseller — Proxmox-Infrastruktur',
                'lead' => 'Ein dedizierter Teil unseres Proxmox-Clusters, den Sie frei weiterverkaufen können: Erstellen Sie Ihre eigenen VPS-Angebote für Ihre Kunden, mit garantierter Isolation und garantierten Ressourcen.',
            ],
            'es' => [
                'name' => 'Revendedor VPS', 'tagline' => 'Su propia oferta VPS de marca blanca',
                'title' => 'Revendedor VPS — infraestructura Proxmox',
                'lead' => 'Una porción dedicada de nuestro clúster Proxmox, para revender como prefiera: cree sus propias ofertas VPS para sus clientes, con aislamiento y recursos garantizados.',
            ],
        ],
        'plans'    => [
            ['name' => 'Prox Starter', 'price' => 18.99, 'sku' => 100, 'popular' => true, 'specs' => [
                ['cpu', 6, '3.9', 'Intel Xeon Gold 6230'], ['ram', 24], ['nvme', 200], ['net', '10 Gb/s'], ['ddos'], ['instant'], ['ip_metered'],
            ]],
            ['name' => 'Prox Pro', 'price' => 28.99, 'sku' => 101, 'specs' => [
                ['cpu', 10, '3.9', 'Intel Xeon Gold 6230'], ['ram', 32], ['nvme', 300], ['net', '10 Gb/s'], ['ddos'], ['instant'], ['ip_metered'],
            ]],
            ['name' => 'Prox Elite', 'price' => 38.99, 'sku' => 102, 'specs' => [
                ['cpu', 14, '3.9', 'Intel Xeon Gold 6230'], ['ram', 48], ['nvme', 500], ['net', '10 Gb/s'], ['ddos'], ['instant'], ['ip_metered'],
            ]],
            ['name' => 'Prox Master', 'price' => 51.99, 'sku' => 103, 'specs' => [
                ['cpu', 18, '3.9', 'Intel Xeon Gold 6230'], ['ram', 64], ['nvme', 600], ['net', '10 Gb/s'], ['ddos'], ['instant'], ['ip_metered'],
            ]],
            ['name' => 'Prox Ultimate', 'price' => 74.99, 'sku' => 104, 'specs' => [
                ['cpu', 22, '3.9', 'Intel Xeon Gold 6230'], ['ram', 96], ['nvme', 750], ['net', '10 Gb/s'], ['ddos'], ['instant'], ['ip_metered'],
            ]],
        ],
    ],

    // --------------------------------------------------------------- JEUX
    'minecraft' => [
        'category' => 'game', 'subcategory' => 'sandbox',
        'icon'     => 'brand-minecraft',
        'from'     => 4.00,
        'plans'    => [
            ['name' => 'Pack Starter', 'price' => 4.00, 'sku' => 16, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 4], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'], ['mods'],
            ]],
            ['name' => 'Pack Amis', 'price' => 6.00, 'sku' => 17, 'popular' => true, 'specs' => [
                ['cpu', 3, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 75], ['panel', 'Pterodactyl'], ['ddos'], ['mods'],
            ]],
            ['name' => 'Pack Ultra', 'price' => 12.99, 'sku' => 18, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 100], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Pack Pro', 'price' => 25.99, 'sku' => 19, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 24], ['nvme', 150], ['panel', 'Pterodactyl'], ['ddos'], ['ipded'],
            ]],
        ],
    ],

    'fivem' => [
        'category' => 'game', 'subcategory' => 'roleplay',
        'icon'     => 'brand-fivem',
        'from'     => 10.00,
        'plans'    => [
            ['name' => 'Pack Démarrage', 'price' => 10.00, 'sku' => 21, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 60], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Pack Débutant', 'price' => 15.00, 'sku' => 22, 'popular' => true, 'specs' => [
                ['cpu', 5, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 100], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Pack Avancé', 'price' => 25.00, 'sku' => 23, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 200], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
        ],
    ],

    'redm' => [
        'category' => 'game', 'subcategory' => 'roleplay',
        'icon'     => 'brand-redm',
        'from'     => 3.49,
        'text'     => [
            '*' => [
                'name' => 'RedM', 'tagline' => 'Roleplay Red Dead Redemption 2',
                'title' => 'Hébergement de serveurs RedM',
                'lead'  => 'Lancez votre serveur RedM (roleplay façon Far West) sur un panel Pterodactyl prêt à l\'emploi, avec Anti-DDoS et redémarrage automatique.',
            ],
            'en' => ['title' => 'RedM server hosting', 'lead' => 'Launch your RedM server (Wild-West-style roleplay) on a ready-to-use Pterodactyl panel, with DDoS filtering and automatic restart.'],
            'de' => ['title' => 'RedM-Server-Hosting', 'lead' => 'Starten Sie Ihren RedM-Server (Roleplay im Wildwest-Stil) auf einem einsatzbereiten Pterodactyl-Panel, mit DDoS-Schutz und automatischem Neustart.'],
            'es' => ['title' => 'Alojamiento de servidores RedM', 'lead' => 'Lance su servidor RedM (rol al estilo del Salvaje Oeste) en un panel Pterodactyl listo para usar, con anti-DDoS y reinicio automático.'],
        ],
        'plans'    => [
            ['name' => 'Offre Découverte', 'price' => 3.49, 'sku' => 73, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 4], ['nvme', 30], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Standard', 'price' => 6.99, 'sku' => 74, 'popular' => true, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 60], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Pro', 'price' => 12.99, 'sku' => 75, 'specs' => [
                ['cpu', 8, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 120], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
        ],
    ],

    'nova-life' => [
        'category' => 'game', 'subcategory' => 'roleplay',
        'icon'     => 'brand-novalife',
        'from'     => 5.00,
        'plans'    => [
            ['name' => 'Pack Débutant', 'price' => 5.00, 'sku' => 25, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Pack Avancé', 'price' => 10.00, 'sku' => 26, 'popular' => true, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 12], ['nvme', 80], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Pack Pro', 'price' => 20.00, 'sku' => 27, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 24], ['nvme', 150], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
        ],
    ],

    'garrys-mod' => [
        'category' => 'game', 'subcategory' => 'sandbox',
        'icon'     => 'brand-gmod',
        'from'     => 5.00,
        'plans'    => [
            ['name' => 'Pack Starter', 'price' => 5.00, 'sku' => 56, 'specs' => [
                ['cpu', 3, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Pack Advanced', 'price' => 10.00, 'sku' => 57, 'popular' => true, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 12], ['nvme', 80], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Pack Ultimate', 'price' => 20.00, 'sku' => 58, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 24], ['nvme', 150], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
        ],
    ],

    'hytale' => [
        'category' => 'game', 'subcategory' => 'sandbox',
        'icon'     => 'brand-hytale',
        'from'     => 5.99,
        'plans'    => [
            ['name' => 'Starter', 'price' => 5.99, 'sku' => 64, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Community', 'price' => 12.99, 'sku' => 65, 'popular' => true, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 75], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Pro', 'price' => 20.99, 'sku' => 66, 'specs' => [
                ['cpu', 8, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 100], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
        ],
    ],

    'beammp' => [
        'category' => 'game', 'subcategory' => 'simulation',
        'icon'     => 'brand-beammp',
        'from'     => 5.99,
        'plans'    => [
            ['name' => 'Starter', 'price' => 5.99, 'sku' => 67, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 4], ['nvme', 25], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Drift', 'price' => 10.99, 'sku' => 68, 'popular' => true, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
            ['name' => 'Turbo', 'price' => 16.99, 'sku' => 69, 'specs' => [
                ['cpu', 8, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 75], ['panel', 'Pterodactyl'], ['ddos'],
            ]],
        ],
    ],

    'ets2' => [
        'category' => 'game', 'subcategory' => 'simulation',
        'icon'     => 'brand-ets2',
        'from'     => 1.99,
        'text'     => [
            '*' => [
                'name' => 'Euro Truck Simulator 2', 'tagline' => 'Convois multijoueur sans coupure',
                'title' => 'Hébergement de serveurs Euro Truck Simulator 2',
                'lead'  => 'Montez votre propre convoi ETS2 stable, avec sauvegardes automatiques et redémarrage après crash — panel Pterodactyl inclus.',
            ],
            'en' => ['tagline' => 'Uninterrupted multiplayer convoys', 'title' => 'Euro Truck Simulator 2 server hosting', 'lead' => 'Run your own stable ETS2 convoy, with automatic backups and crash restart — Pterodactyl panel included.'],
            'de' => ['tagline' => 'Ununterbrochene Multiplayer-Konvois', 'title' => 'Euro-Truck-Simulator-2-Server-Hosting', 'lead' => 'Betreiben Sie Ihren eigenen stabilen ETS2-Konvoi, mit automatischen Sicherungen und Neustart nach einem Absturz — Pterodactyl-Panel inklusive.'],
            'es' => ['tagline' => 'Convoyes multijugador sin cortes', 'title' => 'Alojamiento de servidores Euro Truck Simulator 2', 'lead' => 'Monte su propio convoy ETS2 estable, con copias de seguridad automáticas y reinicio tras un fallo — panel Pterodactyl incluido.'],
        ],
        'plans'    => [
            ['name' => 'Offre Chauffeur', 'price' => 1.99, 'sku' => 90, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 4], ['nvme', 30], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Routier', 'price' => 4.99, 'sku' => 91, 'popular' => true, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 60], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Transporteur', 'price' => 7.99, 'sku' => 92, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 120], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Magnat', 'price' => 18.99, 'sku' => 93, 'specs' => [
                ['cpu', 8, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 200], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
        ],
    ],

    'cs2' => [
        'category' => 'game', 'subcategory' => 'fps',
        'icon'     => 'brand-cs2',
        'from'     => 3.99,
        'text'     => [
            '*' => [
                'name' => 'Counter-Strike 2', 'tagline' => 'Tickrate élevé, faible latence',
                'title' => 'Hébergement de serveurs Counter-Strike 2',
                'lead'  => 'Serveurs compétitifs à tickrate élevé, avec gestion des plugins (SourceMod/MetaMod) et Anti-DDoS taillé pour le FPS.',
            ],
            'en' => ['tagline' => 'High tickrate, low latency', 'title' => 'Counter-Strike 2 server hosting', 'lead' => 'Competitive high-tickrate servers, with SourceMod/MetaMod plugin support and FPS-grade DDoS filtering.'],
            'de' => ['tagline' => 'Hohe Tickrate, geringe Latenz', 'title' => 'Counter-Strike-2-Server-Hosting', 'lead' => 'Kompetitive Server mit hoher Tickrate, SourceMod/MetaMod-Plugin-Unterstützung und auf FPS-Spiele zugeschnittenem DDoS-Schutz.'],
            'es' => ['tagline' => 'Tickrate alto, baja latencia', 'title' => 'Alojamiento de servidores Counter-Strike 2', 'lead' => 'Servidores competitivos de tickrate alto, con soporte de plugins SourceMod/MetaMod y anti-DDoS a la medida del FPS.'],
        ],
        'plans'    => [
            ['name' => 'Offre Pistolet', 'price' => 3.99, 'sku' => 94, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 4], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre AWP', 'price' => 7.99, 'sku' => 95, 'popular' => true, 'specs' => [
                ['cpu', 3, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 75], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Légende', 'price' => 14.99, 'sku' => 96, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 120], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Élite', 'price' => 22.99, 'sku' => 97, 'specs' => [
                ['cpu', 8, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 200], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
        ],
    ],

    'rust' => [
        'category' => 'game', 'subcategory' => 'survival',
        'icon'     => 'brand-rust',
        'from'     => 6.99,
        'text'     => [
            '*' => [
                'name' => 'Rust', 'tagline' => 'Wipe automatisé, plugins Oxide',
                'title' => 'Hébergement de serveurs Rust',
                'lead'  => 'Des machines taillées pour les gros wipes de début de mois, avec plugins Oxide/uMod et Anti-DDoS dédié.',
            ],
            'en' => ['tagline' => 'Automated wipes, Oxide plugins', 'title' => 'Rust server hosting', 'lead' => 'Machines sized for heavy start-of-month wipes, with Oxide/uMod plugin support and dedicated DDoS filtering.'],
            'de' => ['tagline' => 'Automatisierte Wipes, Oxide-Plugins', 'title' => 'Rust-Server-Hosting', 'lead' => 'Maschinen für die großen Wipes zu Monatsbeginn, mit Oxide/uMod-Plugin-Unterstützung und dediziertem DDoS-Schutz.'],
            'es' => ['tagline' => 'Wipes automatizados, plugins Oxide', 'title' => 'Alojamiento de servidores Rust', 'lead' => 'Máquinas pensadas para los grandes wipes de inicio de mes, con soporte de plugins Oxide/uMod y anti-DDoS dedicado.'],
        ],
        'plans' => [
            ['name' => 'Offre Recrue', 'price' => 6.99, 'sku' => 80, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Survivant', 'price' => 12.99, 'sku' => 81, 'popular' => true, 'specs' => [
                ['cpu', 3, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 100], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Baroudeur', 'price' => 21.99, 'sku' => 82, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 200], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Seigneur', 'price' => 29.99, 'sku' => 83, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 48], ['nvme', 300], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
        ],
    ],

    'ark' => [
        'category' => 'game', 'subcategory' => 'survival',
        'icon'     => 'brand-ark',
        'from'     => 5.99,
        'text'     => [
            '*' => [
                'name' => 'Ark: Survival Evolved', 'tagline' => 'Mods illimités, clusters supportés',
                'title' => 'Hébergement de serveurs Ark: Survival Evolved',
                'lead'  => 'Apprivoisez, construisez et survivez entre amis, avec mods Steam Workshop illimités et support des clusters multi-cartes.',
            ],
            'en' => ['tagline' => 'Unlimited mods, cluster support', 'title' => 'Ark: Survival Evolved server hosting', 'lead' => 'Tame, build and survive with friends, with unlimited Steam Workshop mods and multi-map cluster support.'],
            'de' => ['tagline' => 'Unbegrenzte Mods, Cluster-Unterstützung', 'title' => 'Ark: Survival Evolved Server-Hosting', 'lead' => 'Zähmen, bauen und überleben Sie mit Freunden, mit unbegrenzten Steam-Workshop-Mods und Unterstützung für Multi-Map-Cluster.'],
            'es' => ['tagline' => 'Mods ilimitados, soporte de clústeres', 'title' => 'Alojamiento de servidores Ark: Survival Evolved', 'lead' => 'Doma, construye y sobrevive con amigos, con mods ilimitados de Steam Workshop y soporte de clústeres multi-mapa.'],
        ],
        'plans' => [
            ['name' => 'Offre Découverte', 'price' => 5.99, 'sku' => 76, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 30], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Arkonautes', 'price' => 12.99, 'sku' => 77, 'popular' => true, 'specs' => [
                ['cpu', 3, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 100], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Combattant', 'price' => 18.99, 'sku' => 78, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 150], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Titan', 'price' => 21.99, 'sku' => 79, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 48], ['nvme', 200], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
        ],
    ],

    'palworld' => [
        'category' => 'game', 'subcategory' => 'survival',
        'icon'     => 'brand-palworld',
        'from'     => 5.99,
        'text'     => [
            '*' => [
                'name' => 'Palworld', 'tagline' => 'Mods, sauvegardes automatiques',
                'title' => 'Hébergement de serveurs Palworld',
                'lead'  => 'Un monde ouvert à explorer et défendre en groupe, avec sauvegardes automatiques régulières et support des mods.',
            ],
            'en' => ['tagline' => 'Mods, automatic backups', 'title' => 'Palworld server hosting', 'lead' => 'An open world to explore and defend as a group, with regular automatic backups and mod support.'],
            'de' => ['tagline' => 'Mods, automatische Sicherungen', 'title' => 'Palworld-Server-Hosting', 'lead' => 'Eine offene Welt, die Sie gemeinsam erkunden und verteidigen, mit regelmäßigen automatischen Sicherungen und Mod-Unterstützung.'],
            'es' => ['tagline' => 'Mods, copias automáticas', 'title' => 'Alojamiento de servidores Palworld', 'lead' => 'Un mundo abierto para explorar y defender en grupo, con copias de seguridad automáticas periódicas y soporte de mods.'],
        ],
        'plans' => [
            ['name' => 'Offre Apprenti', 'price' => 5.99, 'sku' => 84, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Dompteur', 'price' => 11.99, 'sku' => 85, 'popular' => true, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 100], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Maître', 'price' => 21.99, 'sku' => 86, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 200], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
        ],
    ],

    'seven-days' => [
        'category' => 'game', 'subcategory' => 'survival',
        'icon'     => 'brand-7dtd',
        'from'     => 5.99,
        'text'     => [
            '*' => [
                'name' => '7 Days to Die', 'tagline' => 'Horde nights sans lag',
                'title' => 'Hébergement de serveurs 7 Days to Die',
                'lead'  => 'Survivez aux hordes de zombies sans lag les soirs de « Blood Moon », avec mods EAC désactivable et sauvegardes automatiques.',
            ],
            'en' => ['tagline' => 'Lag-free horde nights', 'title' => '7 Days to Die server hosting', 'lead' => 'Survive the zombie hordes lag-free on Blood Moon nights, with toggleable EAC, mod support and automatic backups.'],
            'de' => ['tagline' => 'Ruckelfreie Horde-Nächte', 'title' => '7-Days-to-Die-Server-Hosting', 'lead' => 'Überstehen Sie die Zombie-Horden ruckelfrei an „Blood Moon“-Nächten, mit abschaltbarem EAC, Mod-Unterstützung und automatischen Sicherungen.'],
            'es' => ['tagline' => 'Noches de horda sin lag', 'title' => 'Alojamiento de servidores 7 Days to Die', 'lead' => 'Sobreviva a las hordas de zombis sin lag en las noches de Luna de Sangre, con EAC desactivable, soporte de mods y copias de seguridad automáticas.'],
        ],
        'plans' => [
            ['name' => 'Offre Survivant', 'price' => 5.99, 'sku' => 87, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Pilleur', 'price' => 11.99, 'sku' => 88, 'popular' => true, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 16], ['nvme', 100], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
            ['name' => 'Offre Vétéran', 'price' => 21.99, 'sku' => 89, 'specs' => [
                ['cpu', 6, '4', 'Intel Xeon Gold 6248R'], ['ram', 32], ['nvme', 200], ['panel', 'Pterodactyl'], ['ddos'], ['slots'],
            ]],
        ],
    ],

    'bots' => [
        'category' => 'bot', 'subcategory' => 'utility',
        'icon'     => 'bot',
        'from'     => 1.99,
        'plans'    => [
            ['name' => 'Pack Starter', 'price' => 1.99, 'sku' => 6, 'specs' => [
                ['cpu', 2, '4', 'Intel Xeon Gold 6248R'], ['ram', 2], ['nvme', 10], ['restart'], ['ddos'],
            ]],
            ['name' => 'Pack Pro', 'price' => 3.99, 'sku' => 7, 'popular' => true, 'specs' => [
                ['cpu', 3, '4', 'Intel Xeon Gold 6248R'], ['ram', 4], ['nvme', 25], ['restart'], ['ddos'],
            ]],
            ['name' => 'Pack Ultimate', 'price' => 6.99, 'sku' => 8, 'specs' => [
                ['cpu', 4, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 50], ['restart'], ['ddos'],
            ]],
        ],
    ],

    // ----------------------------------------------------- ADDONS RÉSEAU
    'ip-addon' => [
        'category' => 'ip',
        'icon'     => 'route',
        'from'     => 1.70,
        'text'     => [
            '*' => [
                'name' => 'IP Supplémentaire', 'tagline' => '1,70 € par adresse IPv4, par mois',
                'title' => 'Adresses IPv4 supplémentaires',
                'lead'  => 'Ajoutez une ou plusieurs adresses IPv4 dédiées à votre serveur (VPS, jeu ou hébergement web) — 1,70 € par IP et par mois, activation immédiate.',
            ],
            'en' => [
                'name' => 'Extra IP', 'tagline' => '€1.70 per IPv4 address, per month',
                'title' => 'Extra IPv4 addresses',
                'lead' => 'Add one or more dedicated IPv4 addresses to your server (VPS, game or web hosting) — €1.70 per IP per month, instant activation.',
            ],
            'de' => [
                'name' => 'Zusätzliche IP', 'tagline' => '1,70 € pro IPv4-Adresse und Monat',
                'title' => 'Zusätzliche IPv4-Adressen',
                'lead' => 'Fügen Sie Ihrem Server (VPS, Spiel oder Webhosting) eine oder mehrere dedizierte IPv4-Adressen hinzu — 1,70 € pro IP und Monat, sofortige Aktivierung.',
            ],
            'es' => [
                'name' => 'IP adicional', 'tagline' => '1,70 € por dirección IPv4 al mes',
                'title' => 'Direcciones IPv4 adicionales',
                'lead' => 'Añada una o varias direcciones IPv4 dedicadas a su servidor (VPS, juego o alojamiento web) — 1,70 € por IP al mes, activación inmediata.',
            ],
        ],
        'plans' => [
            ['name' => '1 IP', 'price' => 1.70, 'sku' => 0, 'specs' => [['ip', 1]]],
            ['name' => '5 IP', 'price' => 8.50, 'sku' => 0, 'popular' => true, 'specs' => [['ip', 5]]],
            ['name' => '10 IP', 'price' => 17.00, 'sku' => 0, 'specs' => [['ip', 10]]],
        ],
    ],
];

// Remises progressives selon l'engagement choisi (affichage seulement) —
// chaque palier ajoute 5 % : mensuel 0 %, trimestriel -5 %, semestriel -10 %,
// annuel -15 %.
const BILLING_PERIODS = [
    'monthly'    => ['discount' => 0.00],
    'quarterly'  => ['discount' => 0.05],
    'semiannual' => ['discount' => 0.10],
    'annual'     => ['discount' => 0.15],
];

// Catalogue final : CATALOG_BASE + noms, prix réels par durée, essais et limites
// des offres mail reçus de l'espace client (var/catalog.json, voir inc/catalog.php).
require_once __DIR__ . '/catalog.php';
require_once __DIR__ . '/infra.php';
// Les fiches de CATALOG_BASE gardent la priorité sur une clé identique des nouveaux jeux.
// Revendeur VPS (panel Revendeur, réservé à la refonte de l'espace client) : caché tant que l'option « revendeur_vps » est à false.
define('CATALOG', catalog_build(array_diff_key(CATALOG_BASE + games_extra(), site_option('revendeur_vps') ? [] : ['reseller-vps' => 1])));

// --------------------------------------------------------------------------
// Menu — dérivé automatiquement du catalogue
// --------------------------------------------------------------------------
// Ajouter une offre ne demande plus qu'une seule étape : la déclarer dans
// CATALOG ci-dessus, avec la bonne 'category'. Elle apparaît alors seule
// dans le mega-menu, le tiroir mobile ET les 4 langues, sans rien éditer
// ici. Seules les entrées « bientôt disponible » (pas encore de produit
// réel) se déclarent à la main dans MEGA_MENU_SOON.

// Une entrée de menu ('games', 'vps', 'web'…) peut regrouper plusieurs
// catégories de CATALOG (ex : 'games' affiche category=game ET category=bot).
const MEGA_MENU_META = [
    'games'      => ['icon' => 'gamepad',  'index' => 'games',      'categories' => ['game', 'bot']],
    'vps'        => ['icon' => 'server',   'index' => 'vps',        'categories' => ['vps', 'ip']],
    'web'        => ['icon' => 'globe',    'index' => 'web',        'categories' => ['web']],
    'revendeurs' => ['icon' => 'feather',  'index' => 'revendeurs', 'categories' => ['reseller']],
    // Rubriques « Datacenter » et « Réseau » retirées le 25/10/2026 (demande du propriétaire) : l'IP supplémentaire passe dans « VPS ».
];

// Offres annoncées mais pas encore commandables (pas de produit CATALOG).
const MEGA_MENU_SOON = [
    'vps' => [
        ['soon' => 'vps-storage', 'icon' => 'database'],
    ],
    'web' => [
        ['soon' => 'ssl',     'icon' => 'lock'],
        ['soon' => 'smtp',    'icon' => 'mail'],
    ],
];

// Liens réels (pas des produits CATALOG, pas des "bientôt") vers des pages
// internes du site — ex : la page /domaines/ (recherche + catalogue des
// extensions), qui n'est pas un produit tarifé comme les autres entrées.
// 'url_key' doit correspondre à une entrée de _slugs (lang/xx.php) pour que
// le lien soit correctement préfixé par la langue (/fr/domaines/, etc.).
const MEGA_MENU_LINKS = [
    'web' => [
        ['url_key' => 'domains', 'label' => 'nav.domains_link.title', 'desc' => 'nav.domains_link.desc', 'icon' => 'link'],
    ],
];

/**
 * Construit la structure de menu complète (identique à l'ancien MEGA_MENU),
 * en fusionnant automatiquement les produits publiés du catalogue avec les
 * entrées "bientôt". Appelée une fois par page, résultat mis en cache.
 */
function mega_menu(): array
{
    static $built = null;
    if ($built !== null) return $built;

    $built = [];
    foreach (MEGA_MENU_META as $key => $meta) {
        $items = [];
        foreach (CATALOG as $productKey => $product) {
            if (in_array($product['category'], $meta['categories'], true)) {
                $items[] = ['page' => $productKey, 'icon' => $product['icon']];
            }
        }
        $items = array_merge($items, MEGA_MENU_LINKS[$key] ?? [], MEGA_MENU_SOON[$key] ?? []);

        $built[$key] = ['icon' => $meta['icon'], 'items' => $items];
        if ($meta['index']) $built[$key]['index'] = $meta['index'];
    }
    return $built;
}

/**
 * Variante catégorisée du mega-menu "Jeux" : regroupe les jeux par thème
 * (GAME_SUBCATS) au lieu d'une longue liste plate — un déplié affiche les
 * catégories avec leur compteur, un second déplié affiche les jeux dedans.
 * Les groupes vides ne sont pas retournés.
 */
function games_grouped(): array
{
    static $out = null;
    if ($out !== null) return $out;

    $buckets = [];
    foreach (GAME_SUBCATS as $subKey => $meta) {
        $buckets[$subKey] = ['icon' => $meta['icon'], 'items' => []];
    }
    foreach (CATALOG as $productKey => $product) {
        if (!in_array($product['category'], ['game', 'bot'], true)) continue;
        $sub = $product['subcategory'] ?? 'sandbox';
        if (!isset($buckets[$sub])) $buckets[$sub] = ['icon' => 'gamepad', 'items' => []];
        $buckets[$sub]['items'][] = ['page' => $productKey, 'icon' => $product['icon']];
    }

    $out = array_filter($buckets, fn($b) => count($b['items']) > 0);
    return $out;
}

// --------------------------------------------------------------------------
// Offres Étudiants — page /offres-etudiants/
// --------------------------------------------------------------------------
// Remplir les 3 packs ci-dessous (nom, prix, spécifications). Les textes de
// tête de page (titre, intro) vivent dans lang/content/students.json sous 'students.*'.
//
// ⚠️ Tarifs confirmés depuis la boutique réelle (capture d'écran fournie) —
// toutes les offres étudiants sont à 0,00 € sous réserve de justificatif.
// Seul le 'sku' reste à renseigner (voir README pour comment le récupérer).
const STUDENT_PACKS = [
    [
        'name'  => 'Hébergement Web',
        'price' => 0.00,
        'sku'   => 0, // TODO : identifiant panier
        'url'   => 'https://clients.artaun.fr/offres-etudiants/pack-etud-KqVO',
        'specs' => [
            ['nvme', 35], ['mailbox', 2], ['webmail'], ['dbinc'], ['support'],
        ],
    ],
    [
        'name'  => 'VPS Linux Pro',
        'price' => 0.00,
        'sku'   => 0, // TODO
        'url'   => 'https://clients.artaun.fr/offres-etudiants/vps-linux-Orj0',
        'specs' => [
            ['ip', 1], ['ddos'], ['cpu', 2, '3.9', 'Intel Xeon Gold 6230'], ['nvme', 25], ['ram', 4], ['net', '200 Mb/s'],
        ],
    ],
    [
        'name'  => 'Hébergement Mail Pro',
        'price' => 0.00,
        'sku'   => 0, // TODO
        'url'   => 'https://clients.artaun.fr/offres-etudiants/hebergement-mail-pro-6BPb',
        'specs' => [
            ['mailsec'], ['mailbox', 15], ['nvme', 25], ['webmail'],
        ],
    ],
    [
        'name'  => 'Hébergement Minecraft',
        'price' => 0.00,
        'sku'   => 0, // TODO
        'url'   => 'https://clients.artaun.fr/offres-etudiants/hebergement-minecraft-dASB',
        'specs' => [
            ['ddos'], ['cpu', 3, '4', 'Intel Xeon Gold 6248R'], ['ram', 8], ['nvme', 75],
        ],
    ],
];
const QUICK_ACCESS = [
    ['key' => 'clients', 'url' => LINKS['clients'], 'icon' => 'user',     'primary' => true],
    ['key' => 'panel',   'url' => LINKS['panel'],   'icon' => 'gamepad'],
    ['key' => 'plesk',   'url' => LINKS['plesk'],   'icon' => 'globe'],
    ['key' => 'support', 'url' => LINKS['support'], 'icon' => 'lifebuoy'],
    ['key' => 'status',  'url' => null,             'icon' => 'activity'], // page interne
    ['key' => 'discord', 'url' => LINKS['discord'], 'icon' => 'discord'],
    ['key' => 'docs',    'url' => LINKS['docs'],    'icon' => 'book'],
];

// Services surveillés par la page de statut
const STATUS_SERVICES = [
    ['id' => 'vitrine',      'group' => 'platform', 'url' => 'https://artaun.fr'],
    ['id' => 'client',       'group' => 'platform', 'url' => 'https://clients.artaun.fr'],
    ['id' => 'api',          'group' => 'platform', 'url' => 'https://clients.artaun.fr'],
    ['id' => 'plesk',        'group' => 'web',      'url' => 'https://plesk.artaun.fr'],
    ['id' => 'phpmyadmin',   'group' => 'web',      'url' => 'https://panel.artaun.fr/phpmyadmin'],
    ['id' => 'pterodactyl',  'group' => 'games',    'url' => 'https://panel.artaun.fr'],
    ['id' => 'ptero-node',   'group' => 'games',    'url' => 'https://panel.artaun.fr'],
    ['id' => 'support-ia',   'group' => 'support',  'url' => 'https://artaun.fr'],
    ['id' => 'support-human','group' => 'support',  'url' => 'https://clients.artaun.fr'],
];

/**
 * Bannière officielle d'un jeu (assets/img/games/<clé>.webp, 720×405), ou
 * null si le produit n'en a pas. Sert à l'accueil, aux pages catégorie et
 * produit, et aux cartes de l'assistant.
 */
/** Visuel large haute définition du héros des pages d'offres (assets/img/games/hero/<clé>.webp + -m.webp pour mobile). */
function game_hero(string $key): ?array
{
    $dir = __DIR__ . '/../assets/img/games/hero/';
    if (!is_readable($dir . $key . '.webp')) return null;
    $base = '/assets/img/games/hero/' . rawurlencode($key);
    // Cadrage propre au visuel quand le sujet n'est pas au centre (ex. logo incrusté en haut de l'image Minecraft).
    $focus = ['minecraft' => 'center 78%'][$key] ?? null; // (la version mobile -m est déjà recadrée sous le logo)
    return ['src' => $base . '.webp?v=' . ASSET_VERSION, 'mobile' => is_readable($dir . $key . '-m.webp') ? $base . '-m.webp?v=' . ASSET_VERSION : null, 'focus' => $focus];
}

function game_art(string $key): ?string
{
    static $dir = null;
    if ($dir === null) $dir = __DIR__ . '/../assets/img/games/';
    return is_readable($dir . $key . '.webp') ? '/assets/img/games/' . rawurlencode($key) . '.webp?v=' . ASSET_VERSION : null;
}
