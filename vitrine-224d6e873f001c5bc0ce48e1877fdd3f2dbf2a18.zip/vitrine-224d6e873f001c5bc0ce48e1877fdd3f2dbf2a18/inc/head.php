<?php
/**
 * <head> commun : méta, hreflang, données structurées.
 * Le calcul des métadonnées vit dans inc/seo.php — ici on ne fait que le
 * rendre.
 */

require_once __DIR__ . '/seo.php';

$page    = current_page();
$isHome  = $page === 'home';
$meta    = seo_meta();
$crumbs  = seo_breadcrumb();
// Pages « bientôt disponible » : une cinquantaine de mots, rien à classer.
// On les garde accessibles aux visiteurs mais hors de l'index.
$noindex = $page === '404' || $page === 'soon' || !seo_translated(lang());

$canonical = SITE_URL . seo_path(lang());
// Page produit d'un jeu : son visuel (16:9) plutôt que le logo carré,
// bien plus parlant en partage Discord, X ou Facebook.
$ogArt     = isset(CATALOG[$page]) ? game_art($page) : null;
$ogImage   = SITE_URL . ($ogArt ?: '/assets/img/og-image.png');

// Date de publication / mise à jour, pour les pages éditoriales.
$article = $GLOBALS['blogPost'] ?? $GLOBALS['docArticle'] ?? null;
$published = $article['meta']['date'] ?? null;
$modified  = $article['meta']['updated'] ?? $published;
?>
<!DOCTYPE html>
<html lang="<?= h(t('html.lang')) ?>" data-page="<?= h($page) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= h($meta['title']) ?></title>
<meta name="description" content="<?= h($meta['desc']) ?>">
<?php if ($meta['keywords'] !== ''): ?>
<meta name="keywords" content="<?= h($meta['keywords']) ?>">
<?php endif; ?>
<meta name="robots" content="<?= $noindex ? 'noindex, follow' : 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1' ?>">
<meta name="googlebot" content="<?= $noindex ? 'noindex, follow' : 'index, follow, max-snippet:-1, max-image-preview:large' ?>">
<meta name="author" content="<?= SITE_NAME ?>">
<meta name="referrer" content="strict-origin-when-cross-origin">
<meta name="format-detection" content="telephone=no">
<link rel="canonical" href="<?= h($canonical) ?>">

<?php foreach (LANGS as $code => $langMeta): if (!seo_translated($code)) continue; ?>
<link rel="alternate" hreflang="<?= h($langMeta['hreflang']) ?>" href="<?= h(SITE_URL . seo_path($code)) ?>">
<?php endforeach; ?>
<link rel="alternate" hreflang="x-default" href="<?= h(SITE_URL . seo_path(LANG_DEFAULT)) ?>">

<meta property="og:type" content="<?= $meta['type'] === 'article' ? 'article' : 'website' ?>">
<meta property="og:site_name" content="<?= SITE_NAME ?>">
<meta property="og:locale" content="<?= h(LANGS[lang()]['locale']) ?>">
<?php foreach (LANGS as $code => $langMeta): if ($code === lang() || !seo_translated($code)) continue; ?>
<meta property="og:locale:alternate" content="<?= h($langMeta['locale']) ?>">
<?php endforeach; ?>
<meta property="og:url" content="<?= h($canonical) ?>">
<meta property="og:title" content="<?= h($meta['title']) ?>">
<meta property="og:description" content="<?= h($meta['desc']) ?>">
<meta property="og:image" content="<?= h($ogImage) ?>">
<meta property="og:image:alt" content="<?= SITE_NAME ?>">
<?php if ($published): ?>
<meta property="article:published_time" content="<?= h($published) ?>">
<meta property="article:modified_time" content="<?= h((string) $modified) ?>">
<?php endif; ?>
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= h($meta['title']) ?>">
<meta name="twitter:description" content="<?= h($meta['desc']) ?>">
<meta name="twitter:image" content="<?= h($ogImage) ?>">

<?php /* Le vrai logo, pas le « A » redessiné en SVG : Chrome et Firefox
         préféraient le SVG dès qu'il était déclaré, et c'est le dessin qui
         s'affichait dans l'onglet. On ne sert donc que les PNG du logo. */ ?>
<?php /* 32 px pour l'onglet, 180 px pour les écrans denses et l'écran
         d'accueil iOS. On ne déclare pas le 512 px : il pèse 111 Ko, soit
         plus que tout le CSS du site, pour une icône de 16 px. */ ?>
<link rel="icon" href="/assets/img/favicon-32.png?v=<?= ASSET_VERSION ?>" type="image/png" sizes="32x32">
<link rel="icon" href="/assets/img/apple-touch-icon.png?v=<?= ASSET_VERSION ?>" type="image/png" sizes="180x180">
<link rel="apple-touch-icon" href="/assets/img/apple-touch-icon.png?v=<?= ASSET_VERSION ?>">
<meta name="theme-color" content="#f6f6f8" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0c0c10" media="(prefers-color-scheme: dark)">
<meta name="apple-mobile-web-app-title" content="Artaun">

<!-- Polices auto-hébergées : plus aucune requête vers un tiers pour le
     rendu du texte. On précharge les deux familles réellement visibles au
     premier écran (corps de texte et titres) ; le reste suit naturellement. -->
<link rel="preload" href="/assets/fonts/inter-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/assets/fonts/space-grotesk-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/assets/fonts/fonts.css?v=<?= ASSET_VERSION ?>">
<link rel="stylesheet" href="/assets/css/style.css?v=<?= ASSET_VERSION ?>">

<!-- Applique le thème avant le premier rendu : pas de flash blanc en mode sombre. -->
<script src="/assets/js/theme.js?v=<?= ASSET_VERSION ?>"></script>

<?php
// ---------------------------------------------------------------- schema.org
// Un seul graphe : l'organisation, le site (avec sa recherche interne), le
// fil d'Ariane, et le type propre à la page. Les moteurs recoupent le tout
// par @id plutôt que de lire quatre blocs indépendants.
$graph = [
    [
        '@type' => 'Organization',
        '@id'   => SITE_URL . '/#organization',
        'name'  => SITE_NAME,
        'url'   => SITE_URL,
        'email' => SITE_EMAIL,
        'logo'  => ['@type' => 'ImageObject', 'url' => SITE_URL . '/assets/img/og-image.png', 'width' => 512, 'height' => 512],
        'image' => SITE_URL . '/assets/img/og-image.png',
        'description' => t('meta.home.desc'),
        'address' => [
            '@type' => 'PostalAddress',
            'streetAddress'   => '1 rue des Aziaux',
            'postalCode'      => '52410',
            'addressLocality' => 'Eurville-Bienville',
            'addressRegion'   => 'Haute-Marne',
            'addressCountry'  => 'FR',
        ],
        'contactPoint' => [
            '@type'             => 'ContactPoint',
            'contactType'       => 'customer support',
            'email'             => SITE_EMAIL,
            'availableLanguage' => ['fr', 'en', 'de', 'es'],
            'areaServed'        => ['FR', 'BE', 'CH', 'LU', 'CA', 'DE', 'ES', 'GB'],
        ],
        'sameAs' => [LINKS['discord']],
    ],
    [
        '@type'      => 'WebSite',
        '@id'        => SITE_URL . '/#website',
        'url'        => SITE_URL,
        'name'       => SITE_NAME,
        'inLanguage' => LANGS[lang()]['hreflang'],
        'publisher'  => ['@id' => SITE_URL . '/#organization'],
    ],
    [
        '@type'           => 'BreadcrumbList',
        '@id'             => $canonical . '#breadcrumb',
        'itemListElement' => array_map(fn($i, $c) => [
            '@type'    => 'ListItem',
            'position' => $i + 1,
            'name'     => $c['name'],
            'item'     => SITE_URL . $c['url'],
        ], array_keys($crumbs), $crumbs),
    ],
    [
        '@type'      => 'WebPage',
        '@id'        => $canonical . '#webpage',
        'url'        => $canonical,
        'name'       => $meta['title'],
        'description'=> $meta['desc'],
        'inLanguage' => LANGS[lang()]['hreflang'],
        'isPartOf'   => ['@id' => SITE_URL . '/#website'],
        'breadcrumb' => ['@id' => $canonical . '#breadcrumb'],
    ],
];

// Pas d'aggregateRating ici : Google n'affiche pas d'étoiles pour des avis
// qu'une organisation publie sur elle-même, et une note sans avis vérifiables
// derrière expose à une action manuelle « données structurées trompeuses ».
// Les vrais avis (Google Business Profile, Trustpilot) feront le travail.

echo jsonld(['@context' => 'https://schema.org', '@graph' => $graph]);
?>
</head>
<body data-label-prev="<?= e('a11y.carousel_prev') ?>" data-label-next="<?= e('a11y.carousel_next') ?>">
<a class="skip-link" href="#main"><?= e('skip') ?></a>
