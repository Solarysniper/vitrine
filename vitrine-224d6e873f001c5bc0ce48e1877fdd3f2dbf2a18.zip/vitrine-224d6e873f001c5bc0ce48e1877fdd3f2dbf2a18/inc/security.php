<?php
/**
 * Artaun Hosting — socle de sécurité partagé (site + points d'API).
 *
 * Trois responsabilités, volontairement regroupées ici pour qu'aucun
 * point d'entrée ne puisse les oublier :
 *
 *  1. IDENTIFIER LE VISITEUR. Le site est derrière Cloudflare : au niveau
 *     de PHP, REMOTE_ADDR vaut l'IP d'un nœud Cloudflare, pas celle du
 *     visiteur. Toute limitation « par IP » écrite sur REMOTE_ADDR range
 *     donc des milliers de visiteurs dans le même seau (et n'arrête aucun
 *     attaquant, qui change de nœud à volonté). client_ip() rétablit la
 *     vraie IP — mais UNIQUEMENT si la connexion vient bien d'un réseau
 *     Cloudflare, sinon n'importe qui enverrait un faux en-tête.
 *
 *  2. LIMITER LE DÉBIT. throttle() applique un seau par IP et un seau
 *     global : le premier arrête un abus isolé, le second protège les
 *     dépendances coûteuses (API Gemini, WHOIS, webhooks) même lors d'une
 *     attaque distribuée.
 *
 *  3. REFUSER LES REQUÊTES QUI NE VIENNENT PAS DU SITE. Les points d'API
 *     en POST n'ont aucune raison d'être appelés depuis une autre origine.
 */

declare(strict_types=1);

if (defined('ARTAUN_SECURITY')) return;
define('ARTAUN_SECURITY', true);

// --------------------------------------------------------------------------
// Réseaux de confiance (proxies en amont)
// --------------------------------------------------------------------------
// Plages publiées par Cloudflare (https://www.cloudflare.com/ips/), plus les
// boucles locales : nginx et Apache tournent sur la même machine et se
// relaient la requête.
const TRUSTED_PROXIES = [
    '127.0.0.0/8', '::1/128', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16',
    '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
    '141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
    '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
    '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
    '2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
    '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
];

/** Une IP appartient-elle à un CIDR (v4 ou v6) ? */
function ip_in_cidr(string $ip, string $cidr): bool
{
    [$subnet, $bits] = array_pad(explode('/', $cidr, 2), 2, null);
    $ipBin     = @inet_pton($ip);
    $subnetBin = @inet_pton($subnet);
    if ($ipBin === false || $subnetBin === false || strlen($ipBin) !== strlen($subnetBin)) {
        return false;
    }
    $bits = $bits === null ? strlen($ipBin) * 8 : (int) $bits;

    $whole = intdiv($bits, 8);
    $rest  = $bits % 8;
    if ($whole > 0 && strncmp($ipBin, $subnetBin, $whole) !== 0) return false;
    if ($rest === 0) return true;

    $mask = chr(0xFF << (8 - $rest) & 0xFF);
    return (($ipBin[$whole] & $mask) === ($subnetBin[$whole] & $mask));
}

/** Une IP appartient-elle à un réseau de confiance (proxy en amont) ? */
function is_trusted_proxy(string $ip): bool
{
    foreach (TRUSTED_PROXIES as $cidr) {
        if (ip_in_cidr($ip, $cidr)) return true;
    }
    return false;
}

/**
 * Le PAIR RÉEL qui a établi la connexion vers nous.
 *
 * Point subtil et important : nginx transmet la requête à PHP par la boucle
 * locale, donc REMOTE_ADDR vaut toujours 127.0.0.1 — le juger « de confiance »
 * ne prouve rien. Ce qui compte est l'adresse qui a joint NGINX, que nginx
 * écrit lui-même dans X-Real-IP (et en fin de X-Forwarded-For). Un client ne
 * peut pas la falsifier : nginx écrase tout en-tête X-Real-IP entrant par la
 * vraie adresse du pair. C'est donc sur elle, et non sur REMOTE_ADDR, que
 * repose la décision de confiance.
 */
function upstream_peer(): string
{
    $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');

    // Si nginx nous relaie (REMOTE_ADDR local), le vrai pair est dans
    // X-Real-IP. Sinon, le pair EST REMOTE_ADDR.
    if (is_trusted_proxy($remote)) {
        if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
            $real = trim((string) $_SERVER['HTTP_X_REAL_IP']);
            if (filter_var($real, FILTER_VALIDATE_IP)) return $real;
        }
        // À défaut de X-Real-IP, on prend le DERNIER maillon de la chaîne
        // X-Forwarded-For : c'est celui ajouté par le proxy le plus proche.
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $hops = array_map('trim', explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR']));
            $last = end($hops);
            if ($last !== false && filter_var($last, FILTER_VALIDATE_IP)) return $last;
        }
    }
    return filter_var($remote, FILTER_VALIDATE_IP) ?: '0.0.0.0';
}

/** La requête nous arrive-t-elle bien par un proxy connu (Cloudflare) ? */
function from_trusted_proxy(): bool
{
    static $cached = null;
    if ($cached !== null) return $cached;
    return $cached = is_trusted_proxy(upstream_peer());
}

/**
 * IP réelle du visiteur.
 *
 * On ne fait confiance à CF-Connecting-IP / X-Forwarded-For QUE si le pair
 * qui a joint nginx est bien un nœud Cloudflare (upstream_peer). Sinon —
 * typiquement un attaquant qui joint l'origine en direct, en contournant
 * Cloudflare, et qui forge un CF-Connecting-IP — on ignore ces en-têtes et
 * on retient sa vraie adresse : il ne peut donc pas changer d'identité pour
 * échapper aux limitations.
 */
function client_ip(): string
{
    static $ip = null;
    if ($ip !== null) return $ip;

    $peer = upstream_peer();

    // Le pair est un nœud Cloudflare : le vrai visiteur est derrière, dans
    // CF-Connecting-IP (posé par Cloudflare, pas par le client) ou en tête
    // de X-Forwarded-For.
    if (is_trusted_proxy($peer)) {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $cf = trim((string) $_SERVER['HTTP_CF_CONNECTING_IP']);
            if (filter_var($cf, FILTER_VALIDATE_IP)) return $ip = $cf;
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            foreach (explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR']) as $part) {
                $part = trim($part);
                // On saute les maillons qui sont eux-mêmes des proxies connus.
                if (filter_var($part, FILTER_VALIDATE_IP) && !is_trusted_proxy($part)) {
                    return $ip = $part;
                }
            }
        }
    }

    // Connexion directe (hors Cloudflare) : le pair est le visiteur.
    return $ip = $peer;
}

/** Clé de seau stable et anonyme (on ne stocke jamais l'IP en clair). */
function client_key(string $salt = ''): string
{
    return substr(hash('sha256', $salt . '|' . client_ip()), 0, 40);
}

// --------------------------------------------------------------------------
// Limitation de débit
// --------------------------------------------------------------------------

/** Dossier des compteurs, hors DocumentRoot. */
function throttle_dir(): string
{
    static $dir = null;
    if ($dir !== null) return $dir;

    $dir = __DIR__ . '/../var/throttle';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    if (!is_writable($dir)) $dir = sys_get_temp_dir() . '/artaun-throttle';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    return $dir;
}

/**
 * Enregistre un passage dans un seau et dit s'il déborde.
 * Fenêtre glissante : on garde les horodatages, on jette les périmés.
 */
function throttle_hit(string $bucket, int $max, int $window): bool
{
    $file = throttle_dir() . '/' . preg_replace('/[^a-z0-9_.-]/i', '', $bucket) . '.json';
    $now  = time();

    $fp = @fopen($file, 'c+');
    if ($fp === false) return true;           // compteur illisible : on laisse passer
    @flock($fp, LOCK_EX);

    $raw  = stream_get_contents($fp) ?: '';
    $hits = json_decode($raw, true);
    if (!is_array($hits)) $hits = [];

    $hits = array_values(array_filter($hits, fn($t) => is_int($t) && $t > $now - $window));
    $ok   = count($hits) < $max;
    if ($ok) $hits[] = $now;

    // On borne la taille du fichier : un seau ne garde jamais plus que sa
    // propre limite, même sous rafale.
    if (count($hits) > $max) $hits = array_slice($hits, -$max);

    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($hits));
    @flock($fp, LOCK_UN);
    fclose($fp);

    return $ok;
}

/**
 * Limitation à deux étages : par visiteur ET globale.
 *
 * Le seau global protège ce qui coûte cher côté Artaun (appels Gemini,
 * requêtes WHOIS, webhooks Discord) : même réparti sur mille IP, un abus
 * ne peut pas dépasser le plafond global.
 *
 * $onFail est appelé au lieu d'un exit brut, pour que chaque point d'entrée
 * réponde dans son propre format (JSON côté API, HTML côté site).
 */
function throttle(string $name, int $perIp, int $window, int $global = 0, ?callable $onFail = null): bool
{
    $retryAfter = max(1, (int) ceil($window / 4));

    $ok = throttle_hit($name . '-' . client_key($name), $perIp, $window);
    if ($ok && $global > 0) {
        $ok = throttle_hit($name . '-global', $global, $window);
    }
    if ($ok) return true;

    header('Retry-After: ' . $retryAfter);
    if ($onFail !== null) { $onFail($retryAfter); }
    return false;
}

/** Nettoyage opportuniste : les seaux morts ne s'accumulent pas. */
function throttle_gc(): void
{
    if (random_int(1, 200) !== 1) return;
    foreach (glob(throttle_dir() . '/*.json') ?: [] as $file) {
        if (time() - (int) @filemtime($file) > 86400) @unlink($file);
    }
}

// --------------------------------------------------------------------------
// Provenance des requêtes
// --------------------------------------------------------------------------

/** Hôtes autorisés à appeler les points d'API depuis un navigateur. */
function allowed_hosts(): array
{
    $host = parse_url(SITE_URL, PHP_URL_HOST) ?: 'artaun.fr';
    return [$host, 'www.' . $host];
}

/**
 * Vrai si la requête provient bien d'une page du site.
 *
 * Un formulaire hébergé ailleurs peut parfaitement envoyer un POST vers nos
 * points d'API : CORS empêche l'attaquant de LIRE la réponse, mais pas la
 * requête de partir — assez pour noyer un webhook Discord ou brûler le
 * quota Gemini. On exige donc une origine connue.
 *
 * Les appels serveur-à-serveur (bot Discord, synchronisation ClientXCMS)
 * n'ont pas d'origine : ils s'authentifient par clé partagée et court-
 * circuitent ce contrôle via $allowServerToServer.
 */
function same_origin(bool $allowServerToServer = false): bool
{
    $origin  = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    $hosts   = allowed_hosts();

    if ($origin !== '') {
        $host = parse_url($origin, PHP_URL_HOST);
        return $host !== null && in_array(strtolower($host), $hosts, true);
    }
    if ($referer !== '') {
        $host = parse_url($referer, PHP_URL_HOST);
        return $host !== null && in_array(strtolower($host), $hosts, true);
    }

    // Ni Origin ni Referer : c'est le cas d'un appel serveur-à-serveur, ou
    // d'un navigateur très restrictif. On tranche selon le point d'entrée.
    return $allowServerToServer;
}

/**
 * Le chat, les formulaires et la recherche de domaine sont appelés en
 * fetch() depuis nos propres pages : ce jeton confirme que la requête vient
 * bien d'une page servie par nous, et pas d'un script tiers rejouant l'URL.
 * Lié à la journée et à l'IP : inutilisable ailleurs, sans état à stocker.
 */
function request_token(): string
{
    $secret = (string) (secrets()['bot_secret'] ?? SITE_URL);
    return hash_hmac('sha256', gmdate('Y-m-d') . '|' . client_ip(), $secret);
}

/** Vérifie un jeton, en acceptant celui de la veille (minuit + onglet ouvert). */
function check_request_token(string $given): bool
{
    if ($given === '') return false;
    $secret = (string) (secrets()['bot_secret'] ?? SITE_URL);
    foreach ([gmdate('Y-m-d'), gmdate('Y-m-d', time() - 86400)] as $day) {
        if (hash_equals(hash_hmac('sha256', $day . '|' . client_ip(), $secret), $given)) {
            return true;
        }
    }
    return false;
}

// --------------------------------------------------------------------------
// Entrées
// --------------------------------------------------------------------------

/**
 * Nettoie une chaîne venue de l'extérieur : caractères de contrôle retirés,
 * UTF-8 validé, longueur bornée.
 *
 * Retirer les caractères de contrôle n'est pas cosmétique : ils servent à
 * casser les formats en aval (injection de sauts de ligne dans un en-tête
 * de courriel, faux champs dans un embed Discord, corruption d'un log).
 */
function clean_text(?string $raw, int $max = 500): string
{
    $value = (string) $raw;
    if (!mb_check_encoding($value, 'UTF-8')) {
        $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');
    }
    // On garde \n et \t, on jette le reste des caractères de contrôle.
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?? '';
    return mb_substr(trim($value), 0, $max);
}

/** Valeur d'en-tête sûre (une seule ligne, jamais d'injection CRLF). */
function clean_header(?string $raw, int $max = 200): string
{
    return mb_substr(str_replace(["\r", "\n"], '', clean_text($raw, $max)), 0, $max);
}

// --------------------------------------------------------------------------
// En-têtes de réponse
// --------------------------------------------------------------------------

/**
 * En-têtes de sécurité posés depuis PHP, en plus de ceux du .htaccess :
 * si un jour le site change de serveur web ou que mod_headers est absent,
 * la protection reste en place.
 */
function send_security_headers(): void
{
    if (headers_sent()) return;

    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=(), usb=(), interest-cohort=()');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header_remove('X-Powered-By');

    if (!empty($_SERVER['HTTPS']) || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}
