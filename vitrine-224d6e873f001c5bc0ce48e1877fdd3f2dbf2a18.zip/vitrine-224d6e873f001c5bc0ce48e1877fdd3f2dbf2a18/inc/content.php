<?php
/**
 * Artaun Hosting — moteur de contenu éditorial (documentation + blog).
 *
 * POURQUOI DES FICHIERS TEXTE
 * Un article n'a pas besoin d'une base de données : un fichier se relit, se
 * corrige et se traduit sans outil. Déposer un fichier suffit à publier ;
 * rien d'autre n'est à déclarer, ni ici ni dans le sitemap.
 *
 * ARBORESCENCE
 *   content/docs/<langue>/<categorie>/NN-cle.txt
 *   content/blog/<langue>/NN-cle.txt
 *
 *   - NN   : deux chiffres qui fixent l'ordre d'affichage.
 *   - cle  : identifiant STABLE, identique dans les quatre langues. C'est
 *            lui qui relie la version française à sa traduction allemande,
 *            et qui permet au sélecteur de langue de rester sur le même
 *            article au lieu de retomber sur l'accueil.
 *
 * EN-TÊTE DE FICHIER (une ligne « clé: valeur » par champ, puis une ligne vide)
 *   title:       titre affiché et balise <title>
 *   description: résumé d'une à deux phrases (meta description)
 *   keywords:    mots-clés séparés par des virgules
 *   slug:        URL dans CETTE langue — c'est ce qui permet d'avoir
 *                /fr/docs/plesk/installer-wordpress/ et
 *                /en/docs/plesk/install-wordpress/. Sans slug, la clé sert
 *                d'URL.
 *   date:        (blog) date de publication AAAA-MM-JJ
 *   updated:     (facultatif) date de dernière mise à jour
 *   author:      (blog) auteur affiché
 *   tag:         (blog) rubrique
 *
 * LE FRANÇAIS EST LA LANGUE CANONIQUE : la liste et l'ordre des articles en
 * découlent toujours. Une langue sans traduction affiche le français, et le
 * signale au lecteur plutôt que de faire semblant.
 *
 * MISE EN FORME DU CORPS (volontairement minimale, aucune dépendance)
 *   ## Titre        → <h2> (entre dans le sommaire)
 *   ### Sous-titre  → <h3>
 *   - élément       → liste à puces
 *   1. élément      → liste numérotée
 *   > Astuce        → encadré « astuce »
 *   ! Attention     → encadré « avertissement »
 *   | a | b |       → tableau (la ligne de tirets fait l'en-tête)
 *   ```             → bloc de code
 *   **gras**, `code`, [texte](url)
 */

declare(strict_types=1);

if (defined('ARTAUN_CONTENT')) return;
define('ARTAUN_CONTENT', true);

const CONTENT_ROOT = __DIR__ . '/../content';

// --------------------------------------------------------------------------
// Lecture des fichiers
// --------------------------------------------------------------------------

/**
 * Analyse un fichier article : en-tête « clé: valeur » puis corps.
 * Résultat mis en cache : une page de catégorie ouvre vingt fichiers, on ne
 * les relit pas à chaque appel.
 */
function content_parse(string $path): array
{
    static $cache = [];
    if (isset($cache[$path])) return $cache[$path];

    $raw = @file_get_contents($path);
    if ($raw === false) return $cache[$path] = ['meta' => [], 'body' => ''];

    $lines = explode("\n", str_replace("\r\n", "\n", $raw));
    $meta  = [];
    $i     = 0;
    $known = ['title', 'description', 'keywords', 'slug', 'date', 'updated', 'author', 'tag', 'icon', 'read'];

    while ($i < count($lines) && $i < 14) {
        $line = $lines[$i];
        if (preg_match('/^([a-z]+):\s*(.*)$/i', $line, $m) && in_array(strtolower($m[1]), $known, true)) {
            $meta[strtolower($m[1])] = trim($m[2]);
            $i++;
            continue;
        }
        if (trim($line) === '') { $i++; break; }
        break;
    }

    return $cache[$path] = [
        'meta' => $meta,
        'body' => ltrim(implode("\n", array_slice($lines, $i)), "\n"),
    ];
}

/** Fichiers d'un dossier, triés par préfixe numérique, indexés par clé stable. */
function content_scan(string $dir): array
{
    if (!is_dir($dir)) return [];
    $files = glob($dir . '/[0-9][0-9]-*.txt') ?: [];
    sort($files, SORT_STRING);

    $out = [];
    foreach ($files as $file) {
        $key = preg_replace('/^\d{2}-/', '', basename($file, '.txt'));
        $out[$key] = $file;
    }
    return $out;
}

/**
 * Liste des articles d'une section, dans la langue demandée.
 * La structure vient TOUJOURS du français ; chaque entrée pointe vers le
 * fichier réellement disponible et dit s'il s'agit d'un repli.
 */
function content_list(string $section, string $lang, string $category = ''): array
{
    static $cache = [];
    $ck = $section . '|' . $lang . '|' . $category;
    if (isset($cache[$ck])) return $cache[$ck];

    $sub    = $category !== '' ? '/' . $category : '';
    $canon  = content_scan(CONTENT_ROOT . '/' . $section . '/' . LANG_DEFAULT . $sub);
    $local  = $lang === LANG_DEFAULT ? $canon : content_scan(CONTENT_ROOT . '/' . $section . '/' . $lang . $sub);

    $out = [];
    foreach ($canon as $key => $canonFile) {
        $file     = $local[$key] ?? $canonFile;
        $fallback = !isset($local[$key]);
        $parsed   = content_parse($file);

        $out[$key] = [
            'key'      => $key,
            'file'     => $file,
            'fallback' => $fallback,
            'meta'     => $parsed['meta'],
            'title'    => $parsed['meta']['title'] ?? $key,
            'desc'     => $parsed['meta']['description'] ?? '',
            'slug'     => $parsed['meta']['slug'] ?? $key,
            'category' => $category,
        ];
    }
    return $cache[$ck] = $out;
}

/** Retrouve un article depuis son slug LOCALISÉ (celui qui est dans l'URL). */
function content_by_slug(string $section, string $lang, string $category, string $slug): ?array
{
    foreach (content_list($section, $lang, $category) as $article) {
        if ($article['slug'] === $slug) return $article;
    }
    // Un lien partagé avant une traduction peut porter la clé nue : on
    // l'accepte plutôt que de renvoyer une 404 pour une URL qui a existé.
    foreach (content_list($section, $lang, $category) as $article) {
        if ($article['key'] === $slug) return $article;
    }
    return null;
}

/** Slug d'un article dans une AUTRE langue — pour le sélecteur de langue. */
function content_slug_in(string $section, string $lang, string $category, string $key): string
{
    foreach (content_list($section, $lang, $category) as $article) {
        if ($article['key'] === $key) return $article['slug'];
    }
    return $key;
}

// --------------------------------------------------------------------------
// Documentation
// --------------------------------------------------------------------------

/**
 * Catégories de la documentation.
 * 'slug' donne l'URL par langue : /fr/docs/espace-client/ mais
 * /en/docs/client-area/ — une URL dans la langue du lecteur se référence
 * beaucoup mieux qu'un slug français servi aux quatre langues.
 */
const DOC_CATEGORIES = [
    'presentation' => [
        'icon' => 'flag',
        'slug' => ['fr' => 'presentation', 'en' => 'about-artaun', 'de' => 'ueber-artaun', 'es' => 'presentacion'],
    ],
    'espace-client' => [
        'icon' => 'user',
        'slug' => ['fr' => 'espace-client', 'en' => 'client-area', 'de' => 'kundenbereich', 'es' => 'area-de-cliente'],
    ],
    'pterodactyl' => [
        'icon' => 'brand-pterodactyl',
        'slug' => ['fr' => 'pterodactyl', 'en' => 'pterodactyl', 'de' => 'pterodactyl', 'es' => 'pterodactyl'],
    ],
    'jeux' => [
        'icon' => 'gamepad',
        'slug' => ['fr' => 'serveurs-de-jeux', 'en' => 'game-servers', 'de' => 'gameserver', 'es' => 'servidores-de-juego'],
    ],
    'plesk' => [
        'icon' => 'brand-plesk',
        'slug' => ['fr' => 'plesk', 'en' => 'plesk', 'de' => 'plesk', 'es' => 'plesk'],
    ],
    'vps-linux' => [
        'icon' => 'brand-linux',
        'slug' => ['fr' => 'vps-linux', 'en' => 'linux-vps', 'de' => 'linux-vps', 'es' => 'vps-linux'],
    ],
    'vps-windows' => [
        'icon' => 'brand-windows',
        'slug' => ['fr' => 'vps-windows', 'en' => 'windows-vps', 'de' => 'windows-vps', 'es' => 'vps-windows'],
    ],
    'domaines' => [
        'icon' => 'link',
        'slug' => ['fr' => 'noms-de-domaine', 'en' => 'domain-names', 'de' => 'domainnamen', 'es' => 'nombres-de-dominio'],
    ],
    'mail' => [
        'icon' => 'mail',
        'slug' => ['fr' => 'mail-pro', 'en' => 'mail-pro', 'de' => 'mail-pro', 'es' => 'mail-pro'],
    ],
    'securite' => [
        'icon' => 'shield',
        'slug' => ['fr' => 'securite', 'en' => 'security', 'de' => 'sicherheit', 'es' => 'seguridad'],
    ],
    'facturation' => [
        'icon' => 'euro',
        'slug' => ['fr' => 'facturation', 'en' => 'billing', 'de' => 'abrechnung', 'es' => 'facturacion'],
    ],
];

/** Slug d'une catégorie de doc dans une langue. */
function doc_cat_slug(string $category, ?string $lang = null): string
{
    $lang = $lang ?: lang();
    return DOC_CATEGORIES[$category]['slug'][$lang] ?? DOC_CATEGORIES[$category]['slug'][LANG_DEFAULT] ?? $category;
}

/** Retrouve la catégorie depuis le slug présent dans l'URL. */
function doc_cat_from_slug(string $slug, ?string $lang = null): ?string
{
    $lang = $lang ?: lang();
    foreach (DOC_CATEGORIES as $key => $meta) {
        if (($meta['slug'][$lang] ?? '') === $slug) return $key;
        // Un slug d'une autre langue reste accepté : un lien partagé entre
        // deux visiteurs ne doit pas tomber en 404.
        if (in_array($slug, $meta['slug'], true)) return $key;
        if ($slug === $key) return $key;
    }
    return null;
}

/** Catégories réellement peuplées, dans l'ordre déclaré. */
function doc_categories(string $lang): array
{
    $out = [];
    foreach (DOC_CATEGORIES as $key => $meta) {
        $articles = content_list('docs', $lang, $key);
        if ($articles) {
            $out[$key] = ['icon' => $meta['icon'], 'articles' => $articles, 'count' => count($articles)];
        }
    }
    return $out;
}

/** Nombre total d'articles de documentation publiés. */
function doc_total(string $lang): int
{
    $n = 0;
    foreach (doc_categories($lang) as $cat) $n += $cat['count'];
    return $n;
}

/** URL d'une page de documentation. */
function doc_url(?string $category = null, ?string $slug = null, ?string $lang = null): string
{
    $lang = $lang ?: lang();
    $base = url('docs', $lang);
    if ($category === null) return $base;
    $out = $base . doc_cat_slug($category, $lang) . '/';
    return $slug === null ? $out : $out . $slug . '/';
}

/** Article précédent / suivant, toutes catégories confondues. */
function doc_adjacent(string $lang, string $category, string $key): array
{
    $flat = [];
    foreach (doc_categories($lang) as $catKey => $cat) {
        foreach ($cat['articles'] as $article) {
            $flat[] = ['category' => $catKey, 'key' => $article['key'], 'slug' => $article['slug'], 'title' => $article['title']];
        }
    }
    $idx = null;
    foreach ($flat as $i => $item) {
        if ($item['category'] === $category && $item['key'] === $key) { $idx = $i; break; }
    }
    if ($idx === null) return ['prev' => null, 'next' => null];
    return [
        'prev' => $flat[$idx - 1] ?? null,
        'next' => $flat[$idx + 1] ?? null,
    ];
}

// --------------------------------------------------------------------------
// Blog
// --------------------------------------------------------------------------

/** Articles de blog, du plus récent au plus ancien. */
function blog_posts(string $lang): array
{
    static $cache = [];
    if (isset($cache[$lang])) return $cache[$lang];

    $posts = array_values(content_list('blog', $lang));
    usort($posts, fn($a, $b) => strcmp((string) ($b['meta']['date'] ?? ''), (string) ($a['meta']['date'] ?? '')));
    return $cache[$lang] = $posts;
}

/** Un article de blog depuis son slug localisé. */
function blog_post(string $lang, string $slug): ?array
{
    foreach (blog_posts($lang) as $post) {
        if ($post['slug'] === $slug || $post['key'] === $slug) return $post;
    }
    return null;
}

/** URL d'une page de blog. */
function blog_url(?string $slug = null, ?string $lang = null): string
{
    $lang = $lang ?: lang();
    $base = url('blog', $lang);
    return $slug === null ? $base : $base . $slug . '/';
}

/** Trois articles à lire ensuite (jamais celui qu'on est en train de lire). */
function blog_related(string $lang, string $key, int $max = 3): array
{
    $out = [];
    foreach (blog_posts($lang) as $post) {
        if ($post['key'] === $key) continue;
        $out[] = $post;
        if (count($out) >= $max) break;
    }
    return $out;
}

/** Temps de lecture estimé, en minutes (≈ 200 mots par minute). */
function reading_time(string $body): int
{
    return max(1, (int) ceil(str_word_count(strip_tags($body)) / 200));
}

// --------------------------------------------------------------------------
// Rendu du corps
// --------------------------------------------------------------------------

/**
 * Mise en forme en ligne.
 *
 * L'ÉCHAPPEMENT VIENT EN PREMIER, toujours : le texte est neutralisé, puis
 * seules les balises que NOUS produisons sont réintroduites. Un article ne
 * peut donc pas injecter de HTML, même s'il contient du code ou un extrait
 * de configuration.
 */
function content_inline(string $text): string
{
    $out = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    $out = preg_replace('/`([^`]+)`/', '<code>$1</code>', $out);
    $out = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $out);
    $out = preg_replace('/(?<![\w*])\*([^*\n]+)\*(?![\w*])/', '<em>$1</em>', $out);

    // Liens : seules les cibles internes et http(s) sont acceptées. Un
    // « javascript: » glissé dans un article ne deviendra jamais un lien.
    $out = preg_replace_callback(
        '/\[([^\]]+)\]\(([^)\s]+)\)/',
        function (array $m): string {
            $label = $m[1];
            $href  = html_entity_decode($m[2], ENT_QUOTES, 'UTF-8');
            $isSafe = str_starts_with($href, '/')
                   || str_starts_with($href, '#')
                   || preg_match('#^https?://#i', $href) === 1
                   || str_starts_with($href, 'mailto:');
            if (!$isSafe) return $label;

            $external = preg_match('#^https?://#i', $href) === 1
                     && !str_contains($href, parse_url(SITE_URL, PHP_URL_HOST) ?: 'artaun.fr');
            $attrs = $external ? ' target="_blank" rel="noopener nofollow"' : '';
            return '<a href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '"' . $attrs . '>' . $label . '</a>';
        },
        $out
    ) ?? $out;

    return $out;
}

/** Identifiant d'ancre unique pour un titre. */
function content_slugify(string $text, array &$used): string
{
    $s = strtolower(strip_tags($text));
    $s = strtr($s, [
        'à'=>'a','â'=>'a','ä'=>'a','á'=>'a','ã'=>'a','å'=>'a','ç'=>'c','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
        'î'=>'i','ï'=>'i','í'=>'i','ô'=>'o','ö'=>'o','ó'=>'o','õ'=>'o','ù'=>'u','û'=>'u','ü'=>'u','ú'=>'u',
        'ÿ'=>'y','ñ'=>'n','ß'=>'ss','œ'=>'oe','æ'=>'ae',
    ]);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';
    $s = trim($s, '-') ?: 'section';

    $base = $s; $n = 2;
    while (isset($used[$s])) $s = $base . '-' . $n++;
    $used[$s] = true;
    return $s;
}

/**
 * Convertit le corps en HTML et en extrait le sommaire.
 * Retourne ['html' => string, 'toc' => [['id','text','level'], ...]]
 */
function content_render(string $body): array
{
    $lines = explode("\n", $body);
    $html  = '';
    $toc   = [];
    $used  = [];

    $mode    = null;   // null | ul | ol | code | table
    $para    = [];
    $buffer  = [];
    $rows    = [];

    $flushPara = function () use (&$para, &$html): void {
        if ($para) {
            $html .= '<p>' . content_inline(implode(' ', $para)) . "</p>\n";
            $para = [];
        }
    };
    $closeList = function () use (&$mode, &$html): void {
        if ($mode === 'ul') { $html .= "</ul>\n"; $mode = null; }
        if ($mode === 'ol') { $html .= "</ol>\n"; $mode = null; }
    };
    $closeTable = function () use (&$mode, &$html, &$rows): void {
        if ($mode !== 'table') return;
        if ($rows) {
            $head = array_shift($rows);
            $html .= "<div class=\"table-wrap\"><table>\n<thead><tr>";
            foreach ($head as $cell) $html .= '<th>' . content_inline($cell) . '</th>';
            $html .= "</tr></thead>\n<tbody>\n";
            foreach ($rows as $row) {
                $html .= '<tr>';
                foreach ($row as $cell) $html .= '<td>' . content_inline($cell) . '</td>';
                $html .= "</tr>\n";
            }
            $html .= "</tbody>\n</table></div>\n";
        }
        $rows = [];
        $mode = null;
    };

    foreach ($lines as $line) {
        $trim = rtrim($line);
        $t    = trim($trim);

        if ($mode === 'code') {
            if ($t === '```') {
                $html .= '<pre><code>' . htmlspecialchars(implode("\n", $buffer), ENT_QUOTES, 'UTF-8') . "</code></pre>\n";
                $buffer = [];
                $mode = null;
            } else {
                $buffer[] = $line;
            }
            continue;
        }

        // Tableau : « | a | b | », la ligne de tirets sert juste de séparateur.
        if (str_starts_with($t, '|') && str_ends_with($t, '|')) {
            $flushPara(); $closeList();
            if ($mode !== 'table') { $mode = 'table'; $rows = []; }
            $cells = array_map('trim', explode('|', trim($t, '|')));
            if (!preg_match('/^[\s\-:|]+$/', $t)) $rows[] = $cells;
            continue;
        }
        if ($mode === 'table') $closeTable();

        if ($t === '```') { $flushPara(); $closeList(); $mode = 'code'; $buffer = []; continue; }
        if ($t === '')    { $flushPara(); $closeList(); continue; }

        if (preg_match('/^###\s+(.*)$/', $t, $m)) {
            $flushPara(); $closeList();
            $id = content_slugify($m[1], $used);
            $html .= '<h3 id="' . $id . '">' . content_inline($m[1]) . "</h3>\n";
            $toc[] = ['id' => $id, 'text' => $m[1], 'level' => 3];
            continue;
        }
        if (preg_match('/^##\s+(.*)$/', $t, $m)) {
            $flushPara(); $closeList();
            $id = content_slugify($m[1], $used);
            $html .= '<h2 id="' . $id . '">' . content_inline($m[1]) . "</h2>\n";
            $toc[] = ['id' => $id, 'text' => $m[1], 'level' => 2];
            continue;
        }
        if (preg_match('/^>\s+(.*)$/', $t, $m)) {
            $flushPara(); $closeList();
            $html .= '<aside class="callout callout-tip">' . icon('bolt') . '<p>' . content_inline($m[1]) . "</p></aside>\n";
            continue;
        }
        if (preg_match('/^!\s+(.*)$/', $t, $m)) {
            $flushPara(); $closeList();
            $html .= '<aside class="callout callout-warn">' . icon('shield') . '<p>' . content_inline($m[1]) . "</p></aside>\n";
            continue;
        }
        if (preg_match('/^[-*]\s+(.*)$/', $t, $m)) {
            $flushPara();
            if ($mode !== 'ul') { $closeList(); $html .= "<ul>\n"; $mode = 'ul'; }
            $html .= '<li>' . content_inline($m[1]) . "</li>\n";
            continue;
        }
        if (preg_match('/^\d+\.\s+(.*)$/', $t, $m)) {
            $flushPara();
            if ($mode !== 'ol') { $closeList(); $html .= "<ol>\n"; $mode = 'ol'; }
            $html .= '<li>' . content_inline($m[1]) . "</li>\n";
            continue;
        }

        $para[] = $t;
    }

    $flushPara(); $closeList(); $closeTable();
    if ($mode === 'code' && $buffer) {
        $html .= '<pre><code>' . htmlspecialchars(implode("\n", $buffer), ENT_QUOTES, 'UTF-8') . "</code></pre>\n";
    }

    return ['html' => $html, 'toc' => $toc];
}
