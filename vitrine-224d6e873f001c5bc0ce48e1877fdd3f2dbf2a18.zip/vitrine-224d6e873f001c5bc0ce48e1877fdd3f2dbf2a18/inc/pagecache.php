<?php
/**
 * Cache de page complet pour les visiteurs anonymes.
 *
 * POURQUOI C'EST SÛR ICI
 * Une page comme /fr/vps-linux/ est STRICTEMENT identique pour tout le
 * monde : la langue est dans l'URL, le thème est appliqué par JavaScript
 * avant le premier rendu, le bandeau cookies et l'assistant sont eux aussi
 * pilotés côté navigateur. Aucun contenu ne dépend du visiteur, donc rien
 * ne peut « fuiter » d'un visiteur à l'autre — ce qui est LE risque d'un
 * cache de page, et la raison pour laquelle on le restreint autant.
 *
 * CE QUI N'EST JAMAIS MIS EN CACHE
 *   · tout ce qui n'est pas un GET ;
 *   · toute URL portant une chaîne de requête ;
 *   · toute réponse dont le code n'est pas 200 (une 404 mise en cache en
 *     200 serait un vrai dégât pour le référencement) ;
 *   · les points d'API, qui ne passent pas par ce fichier.
 *
 * INVALIDATION
 * L'empreinte inclut la date de modification la plus récente parmi les
 * sources (gabarits, config, contenus, traductions). Modifier un fichier
 * change l'empreinte, donc la clé : les anciennes entrées cessent d'être
 * lues et la purge opportuniste les supprime. Aucune commande à lancer
 * après une mise à jour.
 */

declare(strict_types=1);

if (defined('ARTAUN_PAGECACHE')) return;
define('ARTAUN_PAGECACHE', true);

function page_cache_dir(): string
{
    $dir = __DIR__ . '/../var/pagecache';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}

/**
 * Empreinte du code et du contenu.
 *
 * Parcourir l'arborescence à chaque requête coûterait cher (plusieurs
 * centaines de fichiers), mais la recalculer trop rarement rend le site
 * déroutant : on modifie un prix et il ne bouge pas. Dix secondes est le
 * compromis retenu — assez pour absorber une rafale de requêtes, assez
 * court pour qu'une correction se voie presque tout de suite.
 *
 * Pour forcer une purge immédiate : supprimer var/pagecache/, ou
 * incrémenter ASSET_VERSION dans inc/config.php.
 */
function page_cache_build_id(): string
{
    static $id = null;
    if ($id !== null) return $id;

    $stamp = page_cache_dir() . '/.build';
    if (is_readable($stamp) && (time() - (int) filemtime($stamp)) < 10) {
        $cached = trim((string) @file_get_contents($stamp));
        if ($cached !== '') return $id = $cached;
    }
    // Si l'écriture du tampon échoue (droits), on recalcule à chaque requête :
    // plus lent, mais jamais faux. Mieux vaut cela qu'un contenu figé.

    $newest = 0;
    $roots = [__DIR__, __DIR__ . '/../pages', __DIR__ . '/../lang', __DIR__ . '/../content'];
    foreach ($roots as $root) {
        if (!is_dir($root)) continue;
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
        );
        foreach ($it as $file) {
            $m = (int) $file->getMTime();
            if ($m > $newest) $newest = $m;
        }
    }
    // Catalogue synchronisé depuis l'espace client (prix) : réécrit seulement quand il change.
    $catalog = __DIR__ . '/../var/catalog.json';
    if (is_file($catalog)) $newest = max($newest, (int) filemtime($catalog));
    // Options (config/options.ini) : basculer un interrupteur régénère toutes les pages.
    $options = __DIR__ . '/../config/options.ini';
    if (is_file($options)) $newest = max($newest, (int) filemtime($options));
    $newest .= '|' . (is_file($options) ? md5((string) @file_get_contents($options)) : '');
    $id = substr(sha1($newest . '|' . ASSET_VERSION), 0, 12);
    @file_put_contents($stamp, $id, LOCK_EX);
    return $id;
}

/** Sert la page depuis le cache si elle s'y trouve. Ne revient pas si elle y est. */
function page_cache_serve(string $lang, string $path): ?string
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') return null;
    if (($_SERVER['QUERY_STRING'] ?? '') !== '' && !preg_match('/^lang=[a-z]{2}&path=/', (string) $_SERVER['QUERY_STRING'])) return null;

    require_once __DIR__ . '/live_incidents.php';
    $key  = page_cache_build_id() . '-' . artaun_incident_sig() . '-' . $lang . '-' . sha1($path);
    $file = page_cache_dir() . '/' . $key . '.html';

    if (is_readable($file)) {
        header('X-Artaun-Cache: hit');
        readfile($file);
        return 'served';
    }
    return $file;
}

/** Enregistre la page rendue, uniquement si la réponse est un 200 propre. */
function page_cache_store(string $file, string $html): void
{
    if (http_response_code() !== 200) return;
    if ($html === '' || stripos($html, '</html>') === false) return;

    $tmp = $file . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, $html) !== false) {
        @rename($tmp, $file);
    }

    // Purge opportuniste : les entrées d'une génération précédente
    // (empreinte différente) n'ont plus de raison d'exister.
    if (random_int(1, 50) === 1) {
        $current = page_cache_build_id();
        foreach (glob(page_cache_dir() . '/*.html') ?: [] as $old) {
            if (!str_starts_with(basename($old), $current)) @unlink($old);
        }
    }
}
