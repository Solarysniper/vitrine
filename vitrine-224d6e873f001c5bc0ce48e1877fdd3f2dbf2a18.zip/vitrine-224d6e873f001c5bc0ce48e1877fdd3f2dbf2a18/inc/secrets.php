<?php
/**
 * Lecture des secrets — partagée par le site et les points d'API.
 *
 * Ordre de recherche, du plus sûr au moins sûr :
 *   1. variables d'environnement (SetEnv Apache ou pool PHP-FPM) ;
 *   2. fichier hors DocumentRoot (../artaun-secrets.php) ;
 *   3. config/secrets.php, protégé par .htaccess — dépannage seulement.
 *
 * Le site fonctionne sans aucun secret : seuls l'assistant et l'envoi des
 * formulaires par webhook sont alors désactivés.
 */

declare(strict_types=1);

if (!function_exists('secrets')) {

    function secrets(): array
    {
        static $cache = null;
        if ($cache !== null) return $cache;

        $fromEnv = array_filter([
            'webhook_contact'     => getenv('ARTAUN_WEBHOOK_CONTACT') ?: '',
            'webhook_abuse'       => getenv('ARTAUN_WEBHOOK_ABUSE') ?: '',
            'gemini_key'          => getenv('ARTAUN_GEMINI_KEY') ?: '',
            'bot_url'             => getenv('ARTAUN_BOT_URL') ?: '',
            'bot_secret'          => getenv('ARTAUN_BOT_SECRET') ?: '',
            'domain_sync_secret'  => getenv('ARTAUN_DOMAIN_SYNC_SECRET') ?: '',
        ]);

        // Les deux emplacements sont FUSIONNÉS, du moins sûr au plus sûr :
        // un fichier hors DocumentRoot complète (et écrase) un éventuel
        // fichier de dépannage resté dans config/. Auparavant la boucle
        // s'arrêtait au premier fichier trouvé : un artaun-secrets.php
        // partiel masquait alors silencieusement toutes les autres clés
        // (assistant et webhooks coupés sans que rien ne le signale).
        $fromFile = [];
        foreach ([__DIR__ . '/../config/secrets.php', dirname(__DIR__, 2) . '/artaun-secrets.php'] as $file) {
            if (is_readable($file)) {
                $loaded = require $file;
                if (is_array($loaded)) $fromFile = array_merge($fromFile, array_filter($loaded, fn($v) => $v !== '' && $v !== null));
            }
        }

        // L'environnement l'emporte sur le fichier.
        $cache = array_merge($fromFile, $fromEnv);

        // Un copier-coller depuis un panel ajoute souvent un espace ou un
        // retour à la ligne en fin de valeur : ça suffit à rendre l'URL du
        // webhook invalide côté cURL sans que rien ne le signale ailleurs.
        foreach ($cache as $k => $v) {
            if (is_string($v)) $cache[$k] = trim($v);
        }

        return $cache;
    }

    /** L'assistant n'est proposé que s'il peut réellement répondre. */
    function chat_enabled(): bool
    {
        return trim((string) (secrets()['gemini_key'] ?? '')) !== '';
    }
}
