<?php
/** État des incidents (status.artaun.fr), cache 30 s. Partagé par le bandeau et le cache de pages. */
if (!function_exists('artaun_live_incidents')) {
function artaun_live_incidents(): array
{
    $cache = __DIR__ . '/../var/status-incidents.json';
    if (is_file($cache) && time() - filemtime($cache) < 30) {
        return json_decode((string)file_get_contents($cache), true) ?: [];
    }
    // Copie périmée : servie tout de suite, rafraîchie après l'envoi de la page (le visiteur n'attend plus
    // l'appel à status.artaun.fr). touch() évite que les requêtes suivantes relancent le même appel.
    if (is_file($cache) && function_exists('fastcgi_finish_request') && time() - filemtime($cache) < 600) {
        @touch($cache);
        register_shutdown_function(function () {
            fastcgi_finish_request();
            artaun_live_incidents_fetch();
        });
        return json_decode((string)file_get_contents($cache), true) ?: [];
    }
    return artaun_live_incidents_fetch();
}

function artaun_live_incidents_fetch(): array
{
    $cache = __DIR__ . '/../var/status-incidents.json';
    $ch = curl_init('https://status.artaun.fr/?format=bot');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 2, CURLOPT_CONNECTTIMEOUT => 1,
        CURLOPT_RESOLVE => ['status.artaun.fr:443:127.0.0.1'],   // même serveur : pas de détour par Cloudflare
        CURLOPT_USERAGENT => 'ArtaunVitrine/1.0',
    ]);
    $raw = curl_exec($ch);
    $ok = curl_getinfo($ch, CURLINFO_HTTP_CODE) === 200;
    curl_close($ch);
    $d = $ok ? (json_decode((string)$raw, true) ?: []) : [];
    if ($ok) @file_put_contents($cache, json_encode($d), LOCK_EX);
    elseif (is_file($cache)) $d = json_decode((string)file_get_contents($cache), true) ?: [];
    return $d;
}

}

/** Signature de l'état (clé du cache de pages : la page change dès qu'un incident change). */
function artaun_incident_sig(): string
{
    $d = artaun_live_incidents(); $now = time(); $p = [];
    foreach (($d['incidents'] ?? []) as $i) if (($i['status'] ?? '') !== 'resolved') $p[] = $i['id'] . ':' . $i['status'] . ':' . (end($i['updates'])['t'] ?? 0);
    foreach (($d['maintenances'] ?? []) as $m) if (empty($m["cancelled"]) && ($m["start"] ?? 0) <= $now && $now < ($m['end'] ?? 0)) $p[] = 'm' . $m['start'];
    return $p ? substr(sha1(implode('|', $p)), 0, 8) : '0';
}
