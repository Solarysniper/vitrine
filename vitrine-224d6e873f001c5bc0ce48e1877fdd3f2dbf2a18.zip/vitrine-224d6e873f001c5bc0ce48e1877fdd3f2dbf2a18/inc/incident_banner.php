<?php
/**
 * Bandeau d'incident / de maintenance en cours, tiré de status.artaun.fr (Artaun Network).
 * Cache local de 30 s dans var/ ; aucune requête côté navigateur (CSP connect-src 'self').
 */
require_once __DIR__ . '/live_incidents.php';

$__st = artaun_live_incidents();
$__now = time();
$__open = array_values(array_filter($__st['incidents'] ?? [], fn($i) => ($i['status'] ?? '') !== 'resolved'));
$__maint = array_values(array_filter($__st['maintenances'] ?? [], fn($m) => empty($m["cancelled"]) && ($m["start"] ?? 0) <= $__now && $__now < ($m['end'] ?? 0)));
$__labels = ['investigating' => 'Investigation', 'identified' => 'Cause identifiée', 'monitoring' => 'Sous surveillance', 'update' => 'Mise à jour'];
if ($__open || $__maint):
    $__i = $__open[0] ?? null;
    $__bad = $__i && in_array($__i['impact'] ?? '', ['majeur', 'critique'], true);
?>
<div role="status" style="border-bottom:1px solid var(--border);background:<?= $__i ? ($__bad ? 'var(--bad-soft)' : 'var(--warn-soft)') : 'var(--info-soft)' ?>">
  <div class="wrap" style="display:flex;align-items:center;gap:10px;padding-top:10px;padding-bottom:10px;font-size:13.5px;flex-wrap:wrap">
    <?php if ($__i): ?>
      <strong style="color:<?= $__bad ? 'var(--bad)' : 'var(--warn)' ?>">⚠ <?= h($__labels[$__i['status']] ?? 'Incident en cours') ?> — <?= h($__i['title']) ?></strong>
      <span style="color:var(--text-2);flex:1;min-width:200px"><?= h(mb_strimwidth((string)($__i['last'] ?? ''), 0, 180, '…')) ?></span>
      <?php if (count($__open) > 1): ?><span style="color:var(--muted)">+<?= count($__open) - 1 ?> autre(s)</span><?php endif; ?>
    <?php else: $__m = $__maint[0]; ?>
      <strong style="color:var(--info)">🔧 Maintenance en cours — <?= h($__m['title']) ?></strong>
      <span style="color:var(--text-2);flex:1">jusqu'à <?= date('H:i', (int)$__m['end']) ?></span>
    <?php endif; ?>
    <a href="https://status.artaun.fr" style="font-weight:600;white-space:nowrap">Voir le statut →</a>
  </div>
</div>
<?php endif;
