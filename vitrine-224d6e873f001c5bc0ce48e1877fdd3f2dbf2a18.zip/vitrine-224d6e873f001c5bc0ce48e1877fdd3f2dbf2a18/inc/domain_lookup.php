<?php
/**
 * Disponibilité d'un nom de domaine (RDAP puis WHOIS), partagée par
 * api/domain-check.php et l'assistant (api/chat.php).
 */

declare(strict_types=1);

/**
 * Découpe et valide un nom de domaine saisi librement (avec ou sans
 * protocole/www). Renvoie [nom, extension] en minuscules, ou null si le
 * format est invalide.
 */
function normalize_domain(string $raw): ?array
{
    $raw = trim(mb_strtolower($raw));
    $raw = preg_replace('#^https?://#', '', $raw);
    $raw = preg_replace('#^www\.#', '', $raw);
    $raw = explode('/', $raw)[0];

    if (!preg_match('/^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)\.([a-z]{2,24})$/', $raw, $m)) {
        return null;
    }

    return [$m[1], $m[3]];
}

/**
 * RDAP d'abord, WHOIS en confirmation si le RDAP répond 404 (ambigu — voir
 * l'en-tête du fichier). Ne renvoie JAMAIS "available" sur la seule foi
 * d'un 404 RDAP non confirmé.
 */
function check_domain_status(string $name, string $tld, array $whoisServers): string
{
    $rdap = rdap_lookup($name, $tld);
    if ($rdap === 'taken') {
        return 'taken';
    }
    if ($rdap === 'available') {
        // Le RDAP a positivement confirmé (une charge utile JSON valide a
        // été reçue en 404, ce qui arrive pour les registres qui répondent
        // explicitement "objet non trouvé" plutôt qu'un 404 muet) : pas
        // besoin de confirmation WHOIS supplémentaire.
        return 'available';
    }

    // $rdap === 'ambiguous' (404 sans confirmation nette, ou erreur réseau)
    $server = $whoisServers[$tld] ?? null;
    if ($server === null) {
        return 'unknown';
    }

    return whois_lookup($name . '.' . $tld, $server);
}

function rdap_lookup(string $name, string $tld): string
{
    $ch = curl_init('https://rdap.org/domain/' . $name . '.' . $tld);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_PROTOCOLS_STR  => 'https',
        CURLOPT_REDIR_PROTOCOLS_STR => 'https',
        CURLOPT_TIMEOUT        => 6,
        CURLOPT_HTTPHEADER     => ['Accept: application/rdap+json'],
    ]);
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code >= 200 && $code < 300) {
        return 'taken';
    }
    if ($code === 404 && is_string($body) && $body !== '') {
        $data = json_decode($body, true);
        // Certains registres renvoient explicitement un objet d'erreur
        // RDAP (RFC 9083) confirmant "objet non trouvé" plutôt qu'un corps
        // vide — dans ce cas précis on peut faire confiance au 404.
        if (is_array($data) && isset($data['errorCode']) && (int) $data['errorCode'] === 404) {
            return 'available';
        }
    }

    return 'ambiguous';
}

function whois_lookup(string $domain, string $server): string
{
    $fp = @fsockopen($server, 43, $errno, $errstr, 5);
    if ($fp === false) {
        return 'unknown';
    }
    stream_set_timeout($fp, 5);
    fwrite($fp, $domain . "\r\n");

    $response = '';
    while (!feof($fp)) {
        $chunk = fread($fp, 4096);
        if ($chunk === false) {
            break;
        }
        $response .= $chunk;
        if (strlen($response) > 65536) {
            break; // garde-fou : jamais lire indéfiniment
        }
    }
    fclose($fp);

    if ($response === '') {
        return 'unknown';
    }

    $lower = mb_strtolower($response);
    $freePatterns = [
        'no match', 'not found', 'no entries found', 'no data found',
        'no object found', 'status: free', 'status: available',
        'domain not found', 'no matching record', 'available for registration',
        'nothing found', 'object does not exist',
    ];
    foreach ($freePatterns as $pattern) {
        if (str_contains($lower, $pattern)) {
            return 'available';
        }
    }

    // Une réponse non vide qui ne matche aucun motif "libre" connu contient
    // très probablement les données d'un enregistrement existant (registrar,
    // dates de création/expiration, serveurs de noms...).
    return 'taken';
}
