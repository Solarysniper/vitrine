<?php
/**
 * Artaun Hosting — calcul des métadonnées de référencement.
 *
 * Tout ce qui décrit une page pour un moteur de recherche est décidé ici, en
 * un seul endroit : titre, description, mots-clés, URL canonique, et surtout
 * l'URL ÉQUIVALENTE DANS CHAQUE LANGUE.
 *
 * Ce dernier point est le plus important et le plus facile à rater : un
 * hreflang qui renvoie vers l'accueil au lieu de la traduction réelle de la
 * page annule le bénéfice du multilingue, et le sélecteur de langue fait
 * perdre sa page au visiteur. Les slugs étant traduits (/fr/serveur-minecraft/
 * ↔ /en/minecraft-server/, /fr/docs/plesk/installer-wordpress/ ↔
 * /en/docs/plesk/install-wordpress/), l'équivalence se calcule, elle ne se
 * devine pas.
 */

declare(strict_types=1);

if (defined('ARTAUN_SEO')) return;
define('ARTAUN_SEO', true);

/**
 * URL (chemin) de la page courante dans la langue demandée.
 * S'appuie sur le contexte de routage laissé par index.php.
 */
function seo_path(string $lang): string
{
    $page = current_page();

    $soonKey    = $GLOBALS['soonKey']    ?? null;
    $docCat     = $GLOBALS['docCat']     ?? null;
    $docArticle = $GLOBALS['docArticle'] ?? null;
    $blogPost   = $GLOBALS['blogPost']   ?? null;

    switch ($page) {
        case 'soon':
            return $soonKey ? url('soon', $lang) . $soonKey . '/' : url('home', $lang);

        case 'docs':
            return url('docs', $lang);

        case 'docs-category':
            return $docCat ? doc_url($docCat, null, $lang) : url('docs', $lang);

        case 'docs-article':
            if (!$docCat || !$docArticle) return url('docs', $lang);
            return doc_url($docCat, content_slug_in('docs', $lang, $docCat, $docArticle['key']), $lang);

        case 'blog':
            return url('blog', $lang);

        case 'blog-post':
            if (!$blogPost) return url('blog', $lang);
            return blog_url(content_slug_in('blog', $lang, '', $blogPost['key']), $lang);

        case '404':
            return url('home', $lang);

        default:
            return url($page, $lang);
    }
}

/**
 * La page courante existe-t-elle réellement dans cette langue ?
 * Un article non traduit s'affiche en français sous l'URL de la langue :
 * utile au lecteur, mais pour Google c'est un doublon (noindex, pas de hreflang).
 */
function seo_translated(string $lang): bool
{
    $page = current_page();
    $post = $GLOBALS['blogPost'] ?? null;
    $doc  = $GLOBALS['docArticle'] ?? null;
    $key  = ($post ?? $doc)['key'] ?? null;
    if ($key === null) return true;
    $list = $page === 'blog-post' ? blog_posts($lang) : content_list('docs', $lang, $GLOBALS['docCat'] ?? '');
    foreach ($list as $a) {
        if ($a['key'] === $key) return empty($a['fallback']);
    }
    return false;
}

/** Prix d'appel pour un titre : « 4 € » plutôt que « 4,00 € ». */
function seo_price(float $amount): string
{
    return str_replace([',00 ', '.00'], [' ', ''], price($amount));
}

/**
 * Titre ou description rédigés pour la recherche (lang/content/seo.json),
 * s'ils existent pour cette page. « %s » y reçoit le prix d'appel.
 */
function seo_override(string $page, string $field): ?string
{
    $key = 'seo.' . $page . '.' . $field;
    if (!has($key)) return null;
    $from = isset(CATALOG[$page]) ? product_from($page) : null;
    if ($from === null && $page === 'vps')  $from = min(array_map(fn($k) => product_from($k), ['vps-linux', 'vps-kvm', 'vps-windows']));
    if ($from === null && $page === 'web')  $from = product_from('web-hosting');
    $text = t($key);
    return str_contains($text, '%s') ? sprintf($text, seo_price((float) $from)) : $text;
}

/** Titre, description et mots-clés de la page courante. */
function seo_meta(): array
{
    $page   = current_page();
    $isHome = $page === 'home';

    $soonKey    = $GLOBALS['soonKey']    ?? null;
    $docCat     = $GLOBALS['docCat']     ?? null;
    $docArticle = $GLOBALS['docArticle'] ?? null;
    $blogPost   = $GLOBALS['blogPost']   ?? null;

    $suffix   = t('meta.suffix');
    $keywords = t('meta.keywords');
    $type     = 'website';
    $title    = '';
    $desc     = '';

    if ($isHome) {
        $title = t('meta.home.title');
        $desc  = t('meta.home.desc');

    } elseif (isset(CATALOG[$page])) {
        $title = product_text($page, 'title') . $suffix;
        $desc  = product_text($page, 'lead');
        $type  = 'product';
        $kw    = [product_text($page, 'name'), t('meta.kw.hosting'), t('meta.kw.france')];
        $keywords = implode(', ', $kw) . ', ' . $keywords;

    } elseif (in_array($page, ['games', 'vps', 'web', 'revendeurs'], true)) {
        $title = t('cat.' . $page . '.title') . $suffix;
        $desc  = t('cat.' . $page . '.lead');

    } elseif (in_array($page, ['legal-notice', 'terms', 'sales', 'privacy', 'cookies', 'aup', 'dpa'], true)) {
        $title = ($GLOBALS['ARTAUN']['strings']['doc.' . $page]['title'] ?? $page) . $suffix;
        $desc  = has('meta.' . $page . '.desc') ? t('meta.' . $page . '.desc') : t('meta.home.desc');

    } elseif ($page === 'soon' && $soonKey) {
        $title = t('soon.' . $soonKey . '.title') . $suffix;
        $desc  = t('soon.' . $soonKey . '.desc');

    } elseif ($page === 'docs') {
        $title = t('docs.meta.title');
        $desc  = t('docs.meta.desc');
        $keywords = t('docs.meta.keywords') . ', ' . $keywords;

    } elseif ($page === 'docs-category' && $docCat) {
        $title = t('docs.cat.' . $docCat . '.title') . ' — ' . t('docs.title') . $suffix;
        $desc  = t('docs.cat.' . $docCat . '.desc');
        $keywords = t('docs.cat.' . $docCat . '.title') . ', ' . t('docs.meta.keywords') . ', ' . $keywords;

    } elseif ($page === 'docs-article' && $docArticle) {
        // Pas de « — Documentation » ici : le titre de l'article est déjà
        // explicite, et ces 16 caractères poussaient la plupart des titres
        // au-delà de la limite d'affichage de Google, qui les tronquait.
        // Les pages de CATÉGORIE le gardent : « VPS Linux » seul est ambigu.
        $title = $docArticle['title'] . (mb_strlen($docArticle['title']) > 48 ? '' : $suffix);
        $desc  = $docArticle['desc'];
        $keywords = ($docArticle['meta']['keywords'] ?? '') . ', ' . $keywords;
        $type  = 'article';

    } elseif ($page === 'blog') {
        $title = t('blog.meta.title');
        $desc  = t('blog.meta.desc');
        $keywords = t('blog.meta.keywords') . ', ' . $keywords;

    } elseif ($page === 'blog-post' && $blogPost) {
        $title = $blogPost['title'] . (mb_strlen($blogPost['title']) > 48 ? '' : $suffix);
        $desc  = $blogPost['desc'];
        $keywords = ($blogPost['meta']['keywords'] ?? '') . ', ' . $keywords;
        $type  = 'article';

    } elseif ($page === '404') {
        $title = t('404.title') . $suffix;
        $desc  = t('404.lead');

    } else {
        $key = [
            'acces-rapide' => 'qa.title', 'status' => 'status.title', 'contact' => 'contact.title',
            'abuse' => 'abuse.title', 'students' => 'students.title', 'domains' => 'domains_page.title', 'migration' => 'v4.mig.title', 'team' => 'v4.team.title',
        ][$page] ?? 'meta.home.title';
        $title = t($key) . $suffix;
        $desc  = has('meta.' . $page . '.desc') ? t('meta.' . $page . '.desc') : t('meta.home.desc');
    }

    // Nouveaux jeux (fiches générées) : titre et description écrits pour la recherche, prix réel inclus.
    if (isset(CATALOG[$page]) && !empty(CATALOG[$page]['extra']) && !has('seo.' . $page . '.title')) {
        $title = t('v4.seo.game_title', product_text($page, 'name'), seo_price(product_from($page)));
        $desc  = t('v4.seo.game_desc', product_text($page, 'name'), product_text($page, 'tagline'), seo_price(product_from($page)));
        $keywords = implode(', ', array_map(fn($k) => t($k, product_text($page, 'name')), ['v4.seo.kw1', 'v4.seo.kw2', 'v4.seo.kw3'])) . ', ' . $keywords;
    }
    $title = seo_override($page, 'title') ?? $title;
    $desc  = seo_override($page, 'desc')  ?? $desc;

    // Une description trop longue est tronquée par Google au milieu d'une
    // phrase : on coupe nous-mêmes, sur un mot entier.
    $desc = trim(preg_replace('/\s+/', ' ', $desc) ?? '');
    if (mb_strlen($desc) > 168) {
        $desc = rtrim(mb_substr($desc, 0, 165), " ,;:—-") . '…';
    }

    return [
        'title'    => $title,
        'desc'     => $desc,
        'keywords' => trim(preg_replace('/\s*,\s*/', ', ', $keywords) ?? '', ', '),
        'type'     => $type,
    ];
}

/**
 * Fil d'Ariane de la page courante : [['name' => …, 'url' => …], …].
 * Sert à la fois au balisage schema.org et au fil affiché en haut de page.
 */
function seo_breadcrumb(): array
{
    $page   = current_page();
    $crumbs = [['name' => t('nav.home'), 'url' => url('home')]];

    $docCat     = $GLOBALS['docCat']     ?? null;
    $docArticle = $GLOBALS['docArticle'] ?? null;
    $blogPost   = $GLOBALS['blogPost']   ?? null;
    $soonKey    = $GLOBALS['soonKey']    ?? null;

    if (isset(CATALOG[$page])) {
        $cat = CATALOG[$page]['category'];
        $catPage = ['web' => 'web', 'vps' => 'vps', 'game' => 'games', 'bot' => 'games', 'reseller' => 'revendeurs'][$cat] ?? null;
        if ($catPage) $crumbs[] = ['name' => t('cat.' . $catPage . '.title'), 'url' => url($catPage)];
        $crumbs[] = ['name' => product_text($page, 'name'), 'url' => url($page)];

    } elseif (in_array($page, ['games', 'vps', 'web', 'revendeurs'], true)) {
        $crumbs[] = ['name' => t('cat.' . $page . '.title'), 'url' => url($page)];

    } elseif (in_array($page, ['docs', 'docs-category', 'docs-article'], true)) {
        $crumbs[] = ['name' => t('docs.title'), 'url' => url('docs')];
        if ($docCat) $crumbs[] = ['name' => t('docs.cat.' . $docCat . '.title'), 'url' => doc_url($docCat)];
        if ($docArticle) $crumbs[] = ['name' => $docArticle['title'], 'url' => doc_url($docCat, $docArticle['slug'])];

    } elseif (in_array($page, ['blog', 'blog-post'], true)) {
        $crumbs[] = ['name' => t('blog.title'), 'url' => url('blog')];
        if ($blogPost) $crumbs[] = ['name' => $blogPost['title'], 'url' => blog_url($blogPost['slug'])];

    } elseif ($page === 'soon' && $soonKey) {
        $crumbs[] = ['name' => t('soon.' . $soonKey . '.title'), 'url' => url('soon') . $soonKey . '/'];

    } elseif ($page !== 'home' && $page !== '404') {
        $label = [
            'acces-rapide' => 'qa.title', 'status' => 'status.title', 'contact' => 'contact.title',
            'abuse' => 'abuse.title', 'students' => 'students.title', 'domains' => 'domains_page.title', 'migration' => 'v4.mig.title', 'team' => 'v4.team.title',
            'legal-notice' => 'legal.notice', 'terms' => 'legal.terms', 'sales' => 'legal.sales', 'privacy' => 'legal.privacy', 'cookies' => 'legal.cookies', 'aup' => 'legal.aup', 'dpa' => 'legal.dpa',
        ][$page] ?? null;
        if ($label) $crumbs[] = ['name' => t($label), 'url' => url($page)];
    }

    return $crumbs;
}

/** Bloc JSON-LD prêt à insérer. */
function jsonld(array $data): string
{
    return '<script type="application/ld+json">'
         . json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
         . '</script>';
}

/** Identité de l'éditeur, réutilisée par tous les balisages. */
function seo_publisher(): array
{
    return [
        '@type' => 'Organization',
        'name'  => SITE_NAME,
        'url'   => SITE_URL,
        'logo'  => ['@type' => 'ImageObject', 'url' => SITE_URL . '/assets/img/og-image.png'],
    ];
}
