<?php
/**
 * Infrastructure réelle d'Artaun Hosting — source unique pour toutes les pages (24/10/2026).
 * Jeux : nœud Intel Xeon Gold 6248R (4 GHz). Tout le reste (VPS, web, bots, mail) : Intel Xeon Gold 6230.
 * Partout : NVMe Entreprise, DDR4 ECC, Anti-DDoS Netrix Mitigation L3/L4/L7 (24 Tbps), datacenter à Paris.
 */

const INFRA = [
    'ddos'     => ['name' => 'Netrix Mitigation', 'short' => 'Netrix', 'capacity' => '24 Tbps', 'layers' => 'L3 · L4 · L7'],
    'cpu_game' => ['model' => 'Intel Xeon Gold 6248R', 'ghz' => 4.0, 'cores' => 24],
    'cpu'      => ['model' => 'Intel Xeon Gold 6230', 'ghz' => 3.9, 'cores' => 20],
    'storage'  => 'NVMe Entreprise',
    'ram'      => 'DDR4 ECC',
    'city'     => 'Paris',
];

/** Processeur d'une offre : 6248R pour les serveurs de jeu, 6230 pour le reste. */
function infra_cpu(?string $productKey = null): array
{
    $cat = $productKey !== null ? (CATALOG[$productKey]['category'] ?? '') : '';
    return $cat === 'game' ? INFRA['cpu_game'] : INFRA['cpu'];
}

/** Fréquence au format de la langue (4 GHz, 3,9 GHz / 3.9 GHz). */
function infra_ghz(float $ghz): string
{
    $s = floor($ghz) == $ghz ? (string) (int) $ghz : number_format($ghz, 1, lang() === 'en' ? '.' : ',', '');
    return $s . ' GHz';
}

/**
 * Prix affiché, convertible dans la monnaie choisie par le visiteur (assets/js/app.js lit data-eur).
 * Le montant en euros reste dans le HTML : c'est lui qui est facturé, et celui que lisent les moteurs.
 */
function money(float $eur): string
{
    return '<span data-eur="' . number_format($eur, 2, '.', '') . '">' . h(price($eur)) . '</span>';
}

/** Monnaies d'affichage reçues de l'espace client (synchro du catalogue), pour le sélecteur. */
function display_currencies(): array
{
    $sync = function_exists('catalog_sync_data') ? catalog_sync_data() : [];
    $out = [];
    foreach ((array) ($sync['currencies'] ?? []) as $code => $c) {
        if (!is_array($c) || !preg_match('/^[A-Z]{3}$/', (string) $code)) continue;
        $out[$code] = [
            'code' => $code,
            'name' => mb_substr((string) ($c['name'] ?? $code), 0, 40),
            'symbol' => mb_substr((string) ($c['symbol'] ?? $code), 0, 6),
            'rate' => (float) ($c['rate'] ?? 1),
            'decimals' => max(0, min(3, (int) ($c['decimals'] ?? 2))),
        ];
    }
    if (!isset($out['EUR'])) {
        $out = ['EUR' => ['code' => 'EUR', 'name' => 'Euro', 'symbol' => '€', 'rate' => 1.0, 'decimals' => 2]] + $out;
    }
    return $out;
}

/**
 * Langue déduite du pays du visiteur (visitor_country()) : pays francophones → fr,
 * germanophones → de, hispanophones → es, tous les autres → en. Pour un pays à plusieurs langues (Belgique,
 * Suisse, Luxembourg, Canada), la langue du navigateur départage. null pour un robot ou sans information.
 */
/** Pays du visiteur : en-tête de Cloudflare s'il est là, sinon la base locale de nginx (geoip2, DB-IP). */
function visitor_country(): string
{
    foreach (['HTTP_CF_IPCOUNTRY', 'GEOIP_COUNTRY'] as $k) {
        $cc = strtoupper(substr((string) ($_SERVER[$k] ?? ''), 0, 2));
        if (preg_match('/^[A-Z]{2}$/', $cc) && $cc !== 'XX' && $cc !== 'T1') return $cc;
    }
    return '';
}

function geo_lang(): ?string
{
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '' || preg_match('/bot|crawl|spider|slurp|bing|google|yandex|baidu|duckduck|facebookexternal|embedly|preview|lighthouse|headless|monitor|curl|wget|python|http/i', $ua)) {
        return null;
    }
    $cc = visitor_country();
    if ($cc === '') {
        return null;
    }
    $mixed = ['BE' => 'fr', 'CH' => 'fr', 'LU' => 'fr', 'CA' => 'en'];
    if (isset($mixed[$cc])) {
        foreach (explode(',', strtolower((string) ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''))) as $part) {
            $code = substr(trim($part), 0, 2);
            if (in_array($code, ['fr', 'de', 'en', 'es'], true)) return $code;
        }
        return $mixed[$cc];
    }
    $fr = ['FR', 'MC', 'SN', 'CI', 'ML', 'BF', 'NE', 'TG', 'BJ', 'GN', 'CM', 'GA', 'CG', 'CD', 'CF', 'TD', 'MG', 'DJ', 'KM', 'BI', 'HT',
        'RE', 'GP', 'MQ', 'GF', 'YT', 'PM', 'NC', 'PF', 'WF', 'BL', 'MF', 'MA', 'DZ', 'TN', 'MU', 'SC'];
    $de = ['DE', 'AT', 'LI'];
    $es = ['ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE', 'EC', 'GT', 'CU', 'BO', 'DO', 'HN', 'PY', 'SV', 'NI', 'CR', 'PA', 'UY', 'PR', 'GQ'];
    return in_array($cc, $fr, true) ? 'fr' : (in_array($cc, $de, true) ? 'de' : (in_array($cc, $es, true) ? 'es' : 'en'));
}
