<?php
/** Section « Matériel » : processeur (selon l'offre), DDR4 ECC, NVMe Entreprise, Paris. $product facultatif. */
$hwCpu = infra_cpu($product ?? null);
$hwGame = ($hwCpu === INFRA['cpu_game']);
?>
<section class="sec hw">
  <div class="wrap">
    <header class="sec-head center">
      <p class="eyebrow"><?= e('v4.hw.eyebrow') ?></p>
      <h2><?= e('v4.hw.title') ?></h2>
      <p class="sec-lead"><?= e('v4.hw.lead') ?></p>
    </header>
    <div class="hw-grid">
      <article class="hw-card">
        <span class="hw-ic"><?= icon('cpu') ?></span>
        <?php if (!empty($hwBoth)): ?>
        <h3>Intel Xeon Gold</h3>
        <p class="hw-big"><?= h(infra_ghz(INFRA['cpu_game']['ghz'])) ?></p>
        <p><?= e('v4.hw.cpu_both', INFRA['cpu_game']['model'], infra_ghz(INFRA['cpu_game']['ghz']), INFRA['cpu']['model'], infra_ghz(INFRA['cpu']['ghz'])) ?></p>
        <?php else: ?>
        <h3><?= h($hwCpu['model']) ?></h3>
        <p class="hw-big"><?= h(infra_ghz($hwCpu['ghz'])) ?></p>
        <p><?= $hwGame ? e('v4.hw.cpu_game', infra_ghz($hwCpu['ghz'])) : e('v4.hw.cpu_other', infra_ghz($hwCpu['ghz']), $hwCpu['cores']) ?></p>
        <?php endif; ?>
      </article>
      <article class="hw-card">
        <span class="hw-ic"><?= icon('memory') ?></span>
        <h3><?= h(INFRA['ram']) ?></h3>
        <p class="hw-big">ECC</p>
        <p><?= e('v4.hw.ram') ?></p>
      </article>
      <article class="hw-card">
        <span class="hw-ic"><?= icon('disk') ?></span>
        <h3><?= e('v4.inc.nvme') ?></h3>
        <p class="hw-big">NVMe</p>
        <p><?= e('v4.hw.nvme') ?></p>
      </article>
      <article class="hw-card">
        <span class="hw-ic"><?= icon('pin') ?></span>
        <h3><?= e('v4.hw.paris') ?></h3>
        <p class="hw-big"><?= e('v4.stat.paris_v') ?></p>
        <p><?= e('v4.hw.paris_d') ?></p>
      </article>
    </div>
  </div>
</section>
