<?php
/** Pied de page, bandeau cookies (en bas) et chargement des scripts. */
$page = current_page();
?>
</main>

<footer class="ftr">
  <div class="ftr-inner">
    <div class="ftr-brand">
      <a class="brand" href="<?= h(url('home')) ?>">
        <img class="brand-mark" src="/assets/img/logo.png?v=<?= ASSET_VERSION ?>" width="30" height="30" alt="" loading="lazy">
        <span class="brand-text"><span class="brand-name">Artaun</span><span class="brand-sub">Hosting</span></span>
      </a>
      <p class="ftr-about"><?= e('footer.about') ?></p>
      <p class="ftr-loc"><?= icon('flag') ?><?= e('footer.made') ?> · Equinix PA5</p>
    </div>

    <div class="ftr-col">
      <h2><?= e('footer.services') ?></h2>
      <ul>
        <li><a href="<?= h(url('games')) ?>"><?= e('nav.games') ?></a></li>
        <li><a href="<?= h(url('vps')) ?>"><?= e('nav.vps') ?></a></li>
        <li><a href="<?= h(url('web')) ?>"><?= e('menu.web.title') ?></a></li>
        <li><a href="<?= h(url('bots')) ?>"><?= e('product.bots.name') ?></a></li>
        <li><a href="<?= h(url('revendeurs')) ?>"><?= e('nav.revendeurs') ?></a></li>
        <li><a href="<?= h(url('students')) ?>"><?= e('nav.students') ?></a></li>
      </ul>
    </div>

    <div class="ftr-col">
      <h2><?= e('footer.useful') ?></h2>
      <ul>
        <li><a href="<?= h(url('docs')) ?>"><?= e('docs.title') ?></a></li>
        <li><a href="<?= h(url('blog')) ?>"><?= e('blog.title') ?></a></li>
        <li><a href="<?= h(url('domains')) ?>"><?= e('nav.domains_link.title') ?></a></li>
        <li><a href="<?= h(url('team')) ?>"><?= e('v4.team.title') ?></a></li>
        <li><a href="<?= h(url('migration')) ?>"><?= e('v4.mig.title') ?></a></li>
        <li><a href="<?= h(url('acces-rapide')) ?>"><?= e('footer.quick') ?></a></li>
        <li><a href="<?= h(url('status')) ?>"><?= e('footer.status') ?></a></li>
        <li><a href="<?= h(LINKS['clients']) ?>" rel="noopener"><?= e('nav.client') ?><?= icon('external', 'ext') ?></a></li>
        <li><a href="<?= h(LINKS['panel']) ?>" rel="noopener">Pterodactyl<?= icon('external', 'ext') ?></a></li>
        <li><a href="<?= h(LINKS['plesk']) ?>" rel="noopener">Plesk<?= icon('external', 'ext') ?></a></li>
      </ul>
    </div>

    <div class="ftr-col">
      <h2><?= e('footer.support') ?></h2>
      <ul>
        <li><a href="<?= h(LINKS['support']) ?>" rel="noopener"><?= e('footer.ticket') ?><?= icon('external', 'ext') ?></a></li>
        <li><a href="<?= h(url('docs')) ?>"><?= e('docs.title') ?></a></li>
        <li><a href="<?= h(LINKS['discord']) ?>" rel="noopener">Discord<?= icon('external', 'ext') ?></a></li>
        <li><a href="<?= h(url('contact')) ?>"><?= e('nav.contact') ?></a></li>
        <li><a href="<?= h(url('abuse')) ?>"><?= e('footer.abuse') ?></a></li>
      </ul>
    </div>
  </div>

  <div class="ftr-bottom">
    <p>© <?= date('Y') ?> <?= SITE_NAME ?>. <?= e('footer.rights') ?> <span class="ftr-tm"><?= e('footer.trademarks') ?></span></p>
    <ul class="ftr-legal">
      <li><a href="<?= h(url('legal-notice')) ?>"><?= e('legal.notice') ?></a></li>
      <li><a href="<?= h(url('sales')) ?>"><?= e('legal.sales') ?></a></li>
      <li><a href="<?= h(url('terms')) ?>"><?= e('legal.terms') ?></a></li>
      <li><a href="<?= h(url('privacy')) ?>"><?= e('legal.privacy') ?></a></li>
      <li><a href="<?= h(url('cookies')) ?>"><?= e('legal.cookies') ?></a></li>
      <li><a href="<?= h(url('aup')) ?>"><?= e('legal.aup') ?></a></li>
      <li><a href="<?= h(url('dpa')) ?>"><?= e('legal.dpa') ?></a></li>
    </ul>
  </div>
</footer>

<!-- Bandeau cookies : en bas, discret, sans blocage de la page -->
<div class="cookie" id="cookie" hidden>
  <div class="cookie-card">
    <span class="cookie-ic"><?= icon('cookie') ?></span>
    <div class="cookie-text">
      <p><?= e('cookie.text') ?> <a class="cookie-more" href="<?= h(url('cookies')) ?>"><?= e('cookie.more') ?></a></p>
    </div>
    <div class="cookie-actions">
      <button type="button" class="btn btn-ghost btn-sm" data-cookie-refuse><?= e('cookie.refuse') ?></button>
      <button type="button" class="btn btn-primary btn-sm" data-cookie-accept><?= e('cookie.accept') ?></button>
    </div>
  </div>
</div>

<?php
// Pas de clé, pas de widget : mieux vaut aucun assistant qu'un assistant muet.
require_once __DIR__ . '/secrets.php';
if (chat_enabled()) require __DIR__ . '/chat.php';
?>
<?php /* Langue : en bas à gauche, drapeau et nom de la langue (la devise reste dans la barre du haut). */ ?>
<div class="picker picker-lang" data-picker>
  <button type="button" class="picker-btn picker-lang-btn" aria-expanded="false" aria-label="<?= e('a11y.lang') ?>">
    <?= flag(lang()) ?><span><?= h(LANGS[lang()]['label']) ?></span><?= icon('chevron', 'picker-lang-chev') ?>
  </button>
  <ul class="picker-menu" hidden>
    <?php foreach (LANGS as $code => $meta): ?>
    <li><a href="<?= h(seo_path($code)) ?>" data-lang="<?= h($code) ?>" hreflang="<?= h($meta['hreflang']) ?>"<?= $code === lang() ? ' aria-current="true"' : '' ?>><?= flag($code) ?><?= h($meta['label']) ?></a></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php
?>

<?php
// Données pour app.js : monnaies d'affichage et barre « cette page existe dans votre langue ».
// Identiques pour tous les visiteurs (la page est mise en cache) ; le pays vient du cookie artaun_geo.
$siteData = ['currencies' => display_currencies(), 'langSuggest' => []];
$v4 = json_decode((string) @file_get_contents(__DIR__ . '/../lang/content/v4.json'), true) ?: [];
foreach (array_keys(LANGS) as $code) {
    $siteData['langSuggest'][$code] = ['text' => $v4['v4.lang.suggest'][$code] ?? '', 'go' => $v4['v4.lang.switch'][$code] ?? '', 'stay' => $v4['v4.lang.stay'][$code] ?? ''];
}
?>
<script type="application/json" id="site-data"><?= json_encode($siteData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script src="/assets/js/app.js?v=<?= ASSET_VERSION ?>" defer></script>
<?php if (chat_enabled()): ?><script src="/assets/js/chat.js?v=<?= ASSET_VERSION ?>" defer></script><?php endif; ?>
<?php if ($page === 'status'): ?>
<script src="/assets/js/status.js?v=<?= ASSET_VERSION ?>" defer></script>
<?php endif; ?>
<?php if (in_array($page, ['contact', 'abuse'], true)): ?>
<script src="/assets/js/forms.js?v=<?= ASSET_VERSION ?>" defer></script>
<?php endif; ?>
<?php if (in_array($page, ['home', 'domains'], true)): ?>
<div id="domain-i18n" hidden
     data-checking="<?= e('domain.checking') ?>"
     data-invalid="<?= e('domain.invalid') ?>"
     data-not-sold="<?= e('domain.not_sold') ?>"
     data-unknown="<?= e('domain.unknown') ?>"
     data-available="<?= e('domain.available') ?>"
     data-taken="<?= e('domain.taken') ?>"
     data-transfer-offer="<?= e('domain.transfer_offer') ?>"
     data-transfer-btn="<?= e('domain.transfer_btn') ?>"
     data-buy="<?= e('domain.buy') ?>"
     data-see-store="<?= e('domain.see_store') ?>"
     data-price-label="<?= e('domain.price_label') ?>"
     data-renew-label="<?= e('domain.renew_label') ?>"
     data-store-url="<?= h(LINKS['store']) ?>"
     data-product-id="<?= h((string) DOMAIN_PRODUCT_ID) ?>"></div>
<script src="/assets/js/domain-search.js?v=<?= ASSET_VERSION ?>" defer></script>
<?php endif; ?>
</body>
</html>
