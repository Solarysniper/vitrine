<?php
/**
 * Catalogue synchronisé avec l'espace client.
 *
 * L'espace client pousse toutes les 10 minutes var/catalog.json (api/catalog-sync.php) :
 * noms, prix réels par durée, essais gratuits, limites des offres mail. Ici on le
 * fusionne avec CATALOG_BASE (textes, logos, caractéristiques) pour obtenir CATALOG.
 * Sans fichier de synchro, CATALOG_BASE est utilisé tel quel.
 */

declare(strict_types=1);

/** Données reçues de l'espace client ([] si absentes ou illisibles). */
function catalog_sync_data(): array
{
    static $data = null;
    if ($data !== null) return $data;
    $file = __DIR__ . '/../var/catalog.json';
    $raw = is_readable($file) ? (string) @file_get_contents($file) : '';
    $json = $raw !== '' ? json_decode($raw, true) : null;
    return $data = (is_array($json) && is_array($json['products'] ?? null)) ? $json : [];
}

/** Correspondance des durées de la vitrine vers celles de l'espace client. */
const PERIOD_KEYS = ['monthly' => 'monthly', 'quarterly' => 'quarterly', 'semiannual' => 'semiannually', 'annual' => 'annually'];
const PERIOD_MONTHS = ['monthly' => 1, 'quarterly' => 3, 'semiannual' => 6, 'annual' => 12];

/** Caractéristiques d'une offre mail d'après ses vraies limites. */
function catalog_mail_specs(array $m): array
{
    $specs = [];
    $specs[] = $m['mailboxes'] === null ? ['mailboxu'] : ['mailbox', $m['mailboxes']];
    if ($m['storage_gb'] !== null) $specs[] = ['mailstorage', $m['storage_gb']];
    if ($m['domains'] !== null) $specs[] = $m['domains'] > 1 ? ['maildomains', $m['domains']] : ['maildomain'];
    $specs[] = $m['aliases'] === null ? ['mailaliasu'] : ['mailalias', $m['aliases']];
    $specs[] = ['webmail'];
    $specs[] = ['mailsec'];
    if (!empty($m['vault_gb'])) $specs[] = ['mailvault', $m['vault_gb']];
    if (!empty($m['newsletters'])) $specs[] = ['mailnews'];
    if (!empty($m['sign'])) $specs[] = ['mailsign'];
    return $specs;
}

/** CATALOG = CATALOG_BASE + noms/prix/essais/limites de l'espace client. */
function catalog_build(array $base): array
{
    $sync = catalog_sync_data();
    $products = $sync['products'] ?? [];
    // Garde-fou : une synchro manifestement incomplète ne doit jamais vider le site.
    $trusted = count($products) >= 10;
    if (!$products) return $base;

    foreach ($base as $key => $prod) {
        $plans = [];
        foreach ($prod['plans'] as $plan) {
            $sku = (int) ($plan['sku'] ?? 0);
            $s = $sku > 0 ? ($products[$sku] ?? $products[(string) $sku] ?? null) : null;
            if ($sku > 0 && $s === null && $trusted) continue; // offre retirée ou masquée dans l'espace client
            if ($s !== null) {
                if (($s['name'] ?? '') !== '') $plan['name'] = $s['name'];
                // Offres nommées « <Jeu> <Offre> » dans l'espace client : la fiche du jeu n'affiche que « <Offre> ».
                $prefix = (string) ($prod['plan_prefix'] ?? '');
                if ($prefix !== '' && str_starts_with($plan['name'], $prefix) && strlen($plan['name']) > strlen($prefix)) {
                    $plan['name'] = substr($plan['name'], strlen($prefix));
                }
                $prices = (array) ($s['prices'] ?? []);
                if (isset($prices['monthly'])) $plan['price'] = (float) $prices['monthly'];
                elseif ($prices) $plan['price'] = (float) reset($prices);
                $plan['prices'] = $prices;
                $plan['trial'] = (int) ($s['trial'] ?? 0);
                $mail = $sync['mail_plans'][$sku] ?? $sync['mail_plans'][(string) $sku] ?? null;
                if (is_array($mail) && ($prod['category'] ?? '') === 'web' && $key === 'mail-pro') {
                    $plan['specs'] = catalog_mail_specs($mail);
                }
            }
            $plans[] = $plan;
        }
        // Offres créées dans l'espace client pour le même jeu (même groupe), absentes de la fiche : ajoutées
        // d'office, avec leurs ressources réelles, triées par prix (jeux et bots seulement).
        if ($trusted && in_array($prod['category'] ?? '', ['game', 'bot'], true) && $plans !== []) {
            $known = array_map(fn ($pl) => (int) ($pl['sku'] ?? 0), $plans);
            $groups = array_unique(array_filter(array_map(fn ($sku) => $products[$sku]['group_id'] ?? null, $known)));
            $tail = array_values(array_filter($plans[0]['specs'] ?? [], fn ($s) => !in_array($s[0], ['cpu', 'ram', 'ssd', 'nvme'], true)));
            $model = ($prod['category'] ?? '') === 'game' ? ['4', 'Intel Xeon Gold 6248R'] : ['3,9', 'Intel Xeon Gold 6230'];
            foreach ($products as $sku => $s) {
                if (in_array((int) $sku, $known, true) || !in_array($s['group_id'] ?? null, $groups, true) || empty($s['res']['ram'])) continue;
                $prices = (array) ($s['prices'] ?? []);
                $cores = (float) $s['res']['cpu'];
                $plans[] = ['name' => (string) $s['name'], 'price' => (float) ($prices['monthly'] ?? reset($prices)), 'sku' => (int) $sku, 'prices' => $prices,
                    'trial' => (int) ($s['trial'] ?? 0), 'auto' => true,
                    'specs' => array_merge([['cpu', floor($cores) == $cores ? (int) $cores : $cores, $model[0], $model[1]], ['ram', (int) $s['res']['ram']], ['nvme', (int) $s['res']['disk']]], $tail)];
            }
            usort($plans, fn ($a, $b) => (float) $a['price'] <=> (float) $b['price']);
        }
        if ($plans === []) {
            unset($base[$key]);
            continue;
        }
        $base[$key]['plans'] = $plans;
        $base[$key]['from'] = min(array_map(fn ($p) => (float) $p['price'], $plans));
    }
    return $base;
}

/** Prix mensualisé d'une offre pour une durée de la vitrine (vrai prix si synchronisé). */
function plan_month_price(array $plan, string $period): float
{
    $key = PERIOD_KEYS[$period] ?? 'monthly';
    $months = PERIOD_MONTHS[$period] ?? 1;
    if (isset($plan['prices'][$key])) return round((float) $plan['prices'][$key] / $months, 2);
    $discount = BILLING_PERIODS[$period]['discount'] ?? 0.0;
    return round((float) $plan['price'] * (1 - $discount), 2);
}

/** Montant facturé pour la durée (null si la durée n'est pas proposée). */
function plan_period_total(array $plan, string $period): ?float
{
    $key = PERIOD_KEYS[$period] ?? 'monthly';
    if (isset($plan['prices'])) return isset($plan['prices'][$key]) ? (float) $plan['prices'][$key] : null;
    return round(plan_month_price($plan, $period) * (PERIOD_MONTHS[$period] ?? 1), 2);
}

/** Remise maximale d'une durée sur les offres d'un produit (pour l'étiquette du sélecteur), en %. */
function product_period_discount(string $productKey, string $period): int
{
    $best = 0.0;
    foreach (CATALOG[$productKey]['plans'] ?? [] as $plan) {
        $monthly = (float) $plan['price'];
        $total = plan_period_total($plan, $period);
        $months = PERIOD_MONTHS[$period] ?? 1;
        if ($monthly > 0 && $total !== null && $months > 1) {
            $best = max($best, 1 - $total / ($monthly * $months));
        }
    }
    return (int) round($best * 100);
}

/** Durées réellement proposées par au moins une offre du produit. */
function product_periods(string $productKey): array
{
    $out = [];
    foreach (array_keys(PERIOD_KEYS) as $period) {
        foreach (CATALOG[$productKey]['plans'] ?? [] as $plan) {
            if (plan_period_total($plan, $period) !== null) { $out[] = $period; break; }
        }
    }
    return $out ?: ['monthly'];
}
