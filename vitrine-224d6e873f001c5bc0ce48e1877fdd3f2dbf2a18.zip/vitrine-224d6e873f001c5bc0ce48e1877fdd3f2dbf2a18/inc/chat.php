<?php
/** Conseiller Artaun — bouton flottant et panneau de conversation. */
?>
<button type="button" class="chat-launcher" id="chat-launcher" aria-expanded="false" aria-controls="chat-panel">
  <span class="chat-launcher-ic"><?= icon('chat') ?></span>
  <span class="chat-launcher-label"><?= e('chat.v2.launcher') ?></span>
  <span class="chat-badge" data-chat-badge hidden>1</span>
</button>

<section class="chat-panel" id="chat-panel" aria-label="<?= e('chat.v2.title') ?>" hidden
         data-labels="<?= h(json_encode([
             'ratelimit'   => t('chat.ratelimit'),
             'error'       => t('chat.error'),
             'connecting'  => t('chat.connecting'),
             'human'       => t('chat.human'),
             'closed'      => t('chat.closed'),
             'subtitle'    => t('chat.subtitle'),
             'order'       => t('chat.v2.order'),
             'details'     => t('chat.v2.details'),
             'recommended' => t('chat.v2.recommended'),
             'trial'       => t('price.trial'),
             'month'       => t('v2.month'),
             'annual'      => t('price.annual'),
         ], JSON_UNESCAPED_UNICODE)) ?>">
  <header class="chat-head">
    <span class="chat-avatar" aria-hidden="true">
      <img src="/assets/img/logo.png?v=<?= ASSET_VERSION ?>" width="34" height="34" alt="" decoding="async">
    </span>
    <span class="chat-id">
      <strong><?= e('chat.v2.title') ?></strong>
      <em data-chat-status><?= e('chat.subtitle') ?></em>
    </span>
    <button type="button" class="icon-btn" data-chat-reset aria-label="<?= e('chat.v2.reset') ?>" title="<?= e('chat.v2.reset') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg></button>
    <button type="button" class="icon-btn" data-chat-close aria-label="<?= e('chat.close') ?>"><?= icon('close') ?></button>
  </header>

  <div class="chat-log" data-chat-log role="log" aria-live="polite">
    <div class="chat-msg is-bot" data-chat-intro>
      <div class="chat-bubble"><?= e('chat.v2.intro') ?></div>
    </div>
    <ul class="chat-quick" data-chat-quick>
      <?php for ($n = 1; $n <= 4; $n++): ?>
      <li><button type="button" data-chat-suggest><?= e('chat.v2.suggest.' . $n) ?></button></li>
      <?php endfor; ?>
      <li><button type="button" class="chat-quick-human" data-chat-human><?= e('chat.v2.human') ?></button></li>
    </ul>
  </div>

  <!-- Escalade : proposée quand le conseiller passe la main -->
  <form class="chat-escalate" data-chat-escalate hidden>
    <h2><?= e('chat.escalate.title') ?></h2>
    <p><?= e('chat.escalate.desc') ?></p>
    <p class="chat-escalate-notice"><?= e('chat.escalate.notice') ?></p>
    <label class="chat-field">
      <span><?= e('chat.escalate.name') ?></span>
      <input type="text" name="name" autocomplete="name" required maxlength="120">
    </label>
    <label class="chat-field">
      <span><?= e('chat.escalate.email') ?></span>
      <input type="email" name="email" autocomplete="email" required maxlength="180">
    </label>
    <div class="chat-escalate-actions">
      <button type="button" class="btn btn-ghost btn-sm" data-chat-escalate-cancel><?= e('chat.escalate.cancel') ?></button>
      <button type="submit" class="btn btn-primary btn-sm"><?= e('chat.escalate.submit') ?></button>
    </div>
  </form>

  <form class="chat-composer" data-chat-form>
    <label class="sr-only" for="chat-input"><?= e('chat.placeholder') ?></label>
    <textarea id="chat-input" data-chat-input rows="1" placeholder="<?= e('chat.placeholder') ?>" maxlength="2000"></textarea>
    <button type="submit" class="chat-send" aria-label="<?= e('chat.send') ?>"><?= icon('arrow') ?></button>
  </form>
  <div class="chat-foot">
    <span class="chat-legal"><?= e('chat.disclaimer') ?></span>
  </div>
</section>
