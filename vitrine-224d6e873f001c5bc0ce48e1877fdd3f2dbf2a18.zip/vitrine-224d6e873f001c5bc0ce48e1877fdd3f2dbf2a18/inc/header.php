<?php
/** Barre de navigation : mega-menu desktop, tiroir mobile, thème, langue. */

/** Un item de menu (produit publié, lien réel vers une page interne, ou service à venir). */
function menu_item(array $item): array
{
    if (isset($item['page'])) {
        return [
            'href'  => url($item['page']),
            'label' => product_text($item['page'], 'name'),
            'desc'  => product_text($item['page'], 'tagline'),
            'icon'  => $item['icon'],
            'key'   => $item['page'],
            'soon'  => false,
            'from'  => product_from($item['page']),
        ];
    }
    if (isset($item['url_key'])) {
        return [
            'href'  => url($item['url_key']),
            'label' => t($item['label']),
            'desc'  => t($item['desc']),
            'icon'  => $item['icon'],
            'key'   => null,
            'soon'  => false,
            'from'  => null,
        ];
    }
    return [
        'href'  => url('soon') . $item['soon'] . '/',
        'label' => t('soon.' . $item['soon'] . '.title'),
        'desc'  => t('soon.' . $item['soon'] . '.desc'),
        'icon'  => $item['icon'],
        'key'   => null,
        'soon'  => true,
        'from'  => null,
    ];
}

/**
 * Pastille d'un item de menu.
 *
 * ELLE EST RENDUE PARTOUT, desktop ET tiroir mobile. Auparavant le tiroir
 * n'affichait que du texte pour les rubriques autres que les jeux : sur
 * téléphone, le logo Windows d'un VPS Windows ou le logo Plesk d'un
 * hébergement web disparaissaient, alors qu'ils sont justement ce qui
 * permet de repérer une offre d'un coup d'œil.
 */
function menu_icon(array $it): string
{
    return $it['key'] ? brand($it['key'], $it['icon']) : icon($it['icon']);
}

$currentPage = current_page();
$soonSuffix  = ($currentPage === 'soon' && isset($soonKey)) ? $soonKey . '/' : '';

/**
 * Sous-menu « Jeux » catégorisé (desktop + mobile) : un groupe par thème,
 * replié, avec le nombre de jeux à côté du nom.
 */
function render_game_categories(string $context): void
{
    $groups = games_grouped();
    foreach ($groups as $subKey => $group):
        $items = array_map('menu_item', $group['items']);
        // Un thème très fourni n'affiche que ses premiers jeux ; le reste est sur la page Jeux, déjà filtrée.
        $total = count($items);
        if ($total > 10) $items = array_slice($items, 0, 8);
        ?>
        <li class="mega-cat">
          <details<?= $context === 'desktop' && $subKey === array_key_first($groups) ? ' open' : '' ?>>
            <summary>
              <span class="mega-cat-ic"><?= icon($group['icon']) ?></span>
              <span class="mega-cat-name"><?= e('subcat.' . $subKey) ?></span>
              <span class="mega-cat-count"><?= $total ?></span>
              <?= icon('chevron', 'chev') ?>
            </summary>
            <ul>
              <?php foreach ($items as $it): ?>
              <li>
                <a href="<?= h($it['href']) ?>">
                  <span class="mega-ic"><?= menu_icon($it) ?></span>
                  <span class="mega-txt">
                    <span class="mega-name"><?= h($it['label']) ?></span>
                    <span class="mega-desc"><?= h($it['desc']) ?></span>
                  </span>
                  <?php if ($it['from']): ?><span class="mega-from"><?= money((float) $it['from']) ?></span><?php endif; ?>
                </a>
              </li>
              <?php endforeach; ?>
              <?php if ($total > count($items)): ?>
              <li class="mega-cat-more"><a href="<?= h(url('games')) ?>#genre-<?= h($subKey) ?>"><?= e('v3.menu.genre_all', $total) ?><?= icon('arrow') ?></a></li>
              <?php endif; ?>
            </ul>
          </details>
        </li>
        <?php
    endforeach;
}

// Rubrique « Ressources » : elle n'est pas dérivée du catalogue (ce ne sont
// pas des offres), donc elle se déclare ici.
$resources = [
    ['href' => url('team'),         'icon' => 'users',    'label' => t('v4.team.title'),  'desc' => t('v4.team.eyebrow')],
    ['href' => url('migration'),    'icon' => 'migrate',  'label' => t('v4.mig.title'),   'desc' => t('v4.mig.eyebrow')],
    ['href' => url('docs'),         'icon' => 'book',     'label' => t('docs.title'),     'desc' => t('meta.docs.desc')],
    ['href' => url('blog'),         'icon' => 'chart',    'label' => t('blog.title'),     'desc' => t('meta.blog.desc')],
    ['href' => url('status'),       'icon' => 'activity', 'label' => t('footer.status'),  'desc' => t('meta.status.desc')],
    ['href' => url('acces-rapide'), 'icon' => 'bolt',     'label' => t('footer.quick'),   'desc' => t('meta.acces-rapide.desc')],
    ['href' => url('students'),     'icon' => 'euro',     'label' => t('nav.students'),   'desc' => t('meta.students.desc')],
    ['href' => url('contact'),      'icon' => 'chat',     'label' => t('nav.contact'),    'desc' => t('meta.contact.desc')],
];
?>
<header class="hdr" id="site-header">
  <div class="hdr-inner">

    <a class="brand" href="<?= h(url('home')) ?>" aria-label="<?= SITE_NAME ?>">
      <img class="brand-mark" src="/assets/img/logo.png?v=<?= ASSET_VERSION ?>" width="30" height="30" alt="" fetchpriority="high">
      <span class="brand-text">
        <span class="brand-name">Artaun</span>
        <span class="brand-sub">Hosting</span>
      </span>
    </a>

    <nav class="nav" aria-label="<?= e('nav.services') ?>">
      <ul class="nav-list">
        <?php foreach (mega_menu() as $key => $block):
            $items = array_map('menu_item', $block['items']); ?>
        <li class="nav-item has-mega">
          <button type="button" class="nav-trigger" aria-expanded="false" aria-controls="mega-<?= h($key) ?>">
            <?= e('nav.' . $key) ?><?= icon('chevron', 'chev') ?>
          </button>
          <div class="mega" id="mega-<?= h($key) ?>" hidden>
            <div class="mega-inner">
              <div class="mega-side">
                <span class="mega-icon"><?= icon($block['icon']) ?></span>
                <h2><?= e('menu.' . $key . '.title') ?></h2>
                <p><?= e('menu.' . $key . '.desc') ?></p>
                <?php if (isset($block['index'])): ?>
                <a class="mega-all" href="<?= h(url($block['index'])) ?>"><?= e('nav.see_all') ?><?= icon('arrow') ?></a>
                <?php endif; ?>
              </div>
              <?php if ($key === 'games'): ?>
              <!-- La liste des jeux dépasse la hauteur de l'écran une fois
                   dépliée : elle défile dans son propre cadre plutôt que de
                   pousser le bas du menu hors de vue. -->
              <div class="mega-scroll">
                <ul class="mega-cats">
                  <?php render_game_categories('desktop'); ?>
                </ul>
              </div>
              <?php else: ?>
              <div class="mega-scroll">
                <ul class="mega-grid">
                  <?php foreach ($items as $it): ?>
                  <li>
                    <a href="<?= h($it['href']) ?>"<?= $it['soon'] ? ' class="is-soon"' : '' ?>>
                      <span class="mega-ic"><?= menu_icon($it) ?></span>
                      <span class="mega-txt">
                        <span class="mega-name">
                          <?= h($it['label']) ?>
                          <?php if ($it['soon']): ?><em class="badge"><?= e('soon.badge') ?></em><?php endif; ?>
                        </span>
                        <span class="mega-desc"><?= h($it['desc']) ?></span>
                      </span>
                      <?php if ($it['from']): ?><span class="mega-from"><?= money((float) $it['from']) ?></span><?php endif; ?>
                    </a>
                  </li>
                  <?php endforeach; ?>
                </ul>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </li>
        <?php endforeach; ?>

        <li class="nav-item has-mega">
          <button type="button" class="nav-trigger" aria-expanded="false" aria-controls="mega-resources">
            <?= e('nav.resources') ?><?= icon('chevron', 'chev') ?>
          </button>
          <div class="mega" id="mega-resources" hidden>
            <div class="mega-inner">
              <div class="mega-side">
                <span class="mega-icon"><?= icon('book') ?></span>
                <h2><?= e('menu.resources.title') ?></h2>
                <p><?= e('menu.resources.desc') ?></p>
                <a class="mega-all" href="<?= h(url('docs')) ?>"><?= e('docs.all') ?><?= icon('arrow') ?></a>
              </div>
              <div class="mega-scroll">
                <ul class="mega-grid">
                  <?php foreach ($resources as $it): ?>
                  <li>
                    <a href="<?= h($it['href']) ?>">
                      <span class="mega-ic"><?= icon($it['icon']) ?></span>
                      <span class="mega-txt">
                        <span class="mega-name"><?= h($it['label']) ?></span>
                        <span class="mega-desc"><?= h($it['desc']) ?></span>
                      </span>
                    </a>
                  </li>
                  <?php endforeach; ?>
                </ul>
              </div>
            </div>
          </div>
        </li>

        <li class="nav-item nav-contact"><a class="nav-link<?= $currentPage === 'contact' ? ' is-current' : '' ?>" href="<?= h(url('contact')) ?>"><?= e('nav.contact') ?></a></li>
      </ul>
    </nav>

    <div class="hdr-actions">
      <?php $curList = display_currencies(); if (count($curList) > 1): ?>
      <div class="picker picker-cur" data-picker>
        <button type="button" class="icon-btn picker-btn" aria-expanded="false" aria-label="<?= e('v4.cur.label') ?>">
          <span class="picker-code" data-cur-current>€</span>
        </button>
        <ul class="picker-menu" hidden>
          <?php foreach ($curList as $c): ?>
          <li><button type="button" data-cur-code="<?= h($c['code']) ?>"><b><?= h($c['code']) ?></b><span><?= h($c['name']) ?></span><small><?= h($c['symbol']) ?></small></button></li>
          <?php endforeach; ?>
          <li class="picker-note" data-cur-note hidden><?= e('v4.cur.note') ?></li>
        </ul>
      </div>
      <?php endif; ?>

      <button type="button" class="icon-btn" data-theme-toggle aria-label="<?= e('a11y.theme') ?>">
        <span class="theme-sun"><?= icon('sun') ?></span>
        <span class="theme-moon"><?= icon('moon') ?></span>
      </button>

      <a class="btn btn-quiet btn-sm hide-sm" href="<?= h(LINKS['login']) ?>" rel="noopener"><?= e('nav.client') ?></a>
      <a class="btn btn-primary btn-sm hide-sm" href="<?= h(url('home')) ?>#offres"><?= e('nav.order') ?></a>

      <button type="button" class="icon-btn burger" data-drawer-open aria-label="<?= e('a11y.menu_open') ?>" aria-expanded="false"><?= icon('menu') ?></button>
    </div>
  </div>
</header>

<div class="drawer" id="drawer" hidden>
  <div class="drawer-head">
    <a class="brand" href="<?= h(url('home')) ?>">
      <img class="brand-mark" src="/assets/img/logo.png?v=<?= ASSET_VERSION ?>" width="30" height="30" alt="">
      <span class="brand-text"><span class="brand-name">Artaun</span><span class="brand-sub">Hosting</span></span>
    </a>
    <button type="button" class="icon-btn" data-drawer-close aria-label="<?= e('a11y.menu_close') ?>"><?= icon('close') ?></button>
  </div>

  <nav class="drawer-nav" aria-label="<?= e('nav.services') ?>">
    <?php foreach (mega_menu() as $key => $block): ?>
    <details class="drawer-group">
      <summary><span><?= icon($block['icon']) ?><?= e('nav.' . $key) ?></span><?= icon('chevron', 'chev') ?></summary>
      <div class="drawer-scroll">
        <?php if ($key === 'games'): ?>
        <ul class="drawer-cats">
          <?php render_game_categories('mobile'); ?>
        </ul>
        <?php else: ?>
        <ul class="drawer-items">
          <?php foreach (array_map('menu_item', $block['items']) as $it): ?>
          <li>
            <a href="<?= h($it['href']) ?>">
              <span class="mega-ic"><?= menu_icon($it) ?></span>
              <span class="mega-txt">
                <span class="mega-name"><?= h($it['label']) ?><?php if ($it['soon']): ?><em class="badge"><?= e('soon.badge') ?></em><?php endif; ?></span>
                <span class="mega-desc"><?= h($it['desc']) ?></span>
              </span>
              <?php if ($it['from']): ?><span class="mega-from"><?= money((float) $it['from']) ?></span><?php endif; ?>
            </a>
          </li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
      </div>
      <?php if (isset($block['index'])): ?>
      <a class="drawer-all" href="<?= h(url($block['index'])) ?>"><?= e('nav.see_all') ?><?= icon('arrow') ?></a>
      <?php endif; ?>
    </details>
    <?php endforeach; ?>

    <details class="drawer-group">
      <summary><span><?= icon('book') ?><?= e('nav.resources') ?></span><?= icon('chevron', 'chev') ?></summary>
      <div class="drawer-scroll">
        <ul class="drawer-items">
          <?php foreach ($resources as $it): ?>
          <li>
            <a href="<?= h($it['href']) ?>">
              <span class="mega-ic"><?= icon($it['icon']) ?></span>
              <span class="mega-txt"><span class="mega-name"><?= h($it['label']) ?></span></span>
            </a>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </details>

    <a class="drawer-link" href="<?= h(url('contact')) ?>"><?= icon('mail') ?><?= e('nav.contact') ?></a>
    <a class="drawer-link" href="<?= h(LINKS['discord']) ?>" rel="noopener"><?= icon('discord') ?>Discord<?= icon('external', 'ext') ?></a>
  </nav>

  <div class="drawer-foot">
    <a class="btn btn-primary btn-block" href="<?= h(url('home')) ?>#offres"><?= e('nav.order') ?></a>
    <a class="btn btn-ghost btn-block" href="<?= h(LINKS['login']) ?>" rel="noopener"><?= e('nav.login') ?></a>
  </div>
</div>
<div class="drawer-veil" data-drawer-close hidden></div>

<?php require __DIR__ . '/incident_banner.php'; ?>
<main id="main">
