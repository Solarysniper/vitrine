<?php
/**
 * Serveurs WHOIS connus par extension, utilisés en repli quand le RDAP
 * (via rdap.org) répond 404 — ce qui peut vouloir dire "libre" OU
 * "extension non couverte par l'annuaire RDAP public" (cas connu de .io,
 * .de et une quarantaine d'autres extensions dites "RDAP furtif"). Sans ce
 * repli, un domaine .io ou .de bien réel pourrait être annoncé "disponible"
 * à tort.
 *
 * Extensions absentes de cette liste : si le RDAP répond 404, le domaine
 * est affiché comme "impossible à vérifier automatiquement" plutôt qu'une
 * fausse disponibilité — jamais de faux positif silencieux.
 */
return [
    'com' => 'whois.verisign-grs.com', 'net' => 'whois.verisign-grs.com',
    'org' => 'whois.pir.org', 'info' => 'whois.afilias.net',
    'biz' => 'whois.nic.biz', 'name' => 'whois.nic.name',
    'pro' => 'whois.afilias-srs.net', 'mobi' => 'whois.nic.mobi',
    'asia' => 'whois.nic.asia', 'xyz' => 'whois.nic.xyz',
    'online' => 'whois.nic.online', 'site' => 'whois.nic.site',
    'store' => 'whois.nic.store', 'club' => 'whois.nic.club',
    'shop' => 'whois.nic.shop', 'app' => 'whois.nic.google',
    'dev' => 'whois.nic.google', 'page' => 'whois.nic.google',
    'tech' => 'whois.nic.tech', 'cloud' => 'whois.nic.cloud',
    'host' => 'whois.nic.host', 'link' => 'whois.nic.link',
    'live' => 'whois.nic.live', 'news' => 'whois.nic.news',
    'top' => 'whois.nic.top', 'vip' => 'whois.nic.vip',
    'world' => 'whois.nic.world', 'wiki' => 'whois.nic.wiki',
    'video' => 'whois.nic.video', 'design' => 'whois.nic.design',
    'studio' => 'whois.nic.studio', 'website' => 'whois.nic.website',
    'email' => 'whois.nic.email', 'guru' => 'whois.nic.guru',
    'expert' => 'whois.nic.expert', 'agency' => 'whois.nic.agency',
    'company' => 'whois.nic.company', 'solutions' => 'whois.nic.solutions',
    'systems' => 'whois.nic.systems', 'support' => 'whois.nic.support',
    'tools' => 'whois.nic.tools', 'network' => 'whois.nic.network',
    'group' => 'whois.nic.group', 'social' => 'whois.nic.social',
    'software' => 'whois.nic.software', 'digital' => 'whois.nic.digital',
    'events' => 'whois.nic.events', 'finance' => 'whois.nic.finance',
    'fitness' => 'whois.nic.fitness', 'health' => 'whois.nic.health',
    'legal' => 'whois.nic.legal', 'media' => 'whois.nic.media',
    'properties' => 'whois.nic.properties', 'restaurant' => 'whois.nic.restaurant',
    'travel' => 'whois.nic.travel', 'photography' => 'whois.nic.photography',
    'gallery' => 'whois.nic.gallery', 'cafe' => 'whois.nic.cafe',
    'click' => 'whois.nic.click', 'contact' => 'whois.nic.contact',
    'games' => 'whois.nic.games', 'blog' => 'whois.nic.blog',
    'best' => 'whois.nic.best', 'music' => 'whois.nic.music',
    // ccTLD
    'fr' => 'whois.nic.fr', 'eu' => 'whois.eu', 'de' => 'whois.denic.de',
    'be' => 'whois.dns.be', 'ch' => 'whois.nic.ch', 'it' => 'whois.nic.it',
    'nl' => 'whois.domain-registry.nl', 'at' => 'whois.nic.at',
    'pl' => 'whois.dns.pl', 'pt' => 'whois.dns.pt', 'se' => 'whois.iis.se',
    'no' => 'whois.norid.no', 'fi' => 'whois.fi', 'dk' => 'whois.dk-hostmaster.dk',
    'ie' => 'whois.weare.ie', 'gr' => 'whois.ics.forth.gr', 'hu' => 'whois.iszt.hu',
    'cz' => 'whois.nic.cz', 'ro' => 'whois.rotld.ro', 'lu' => 'whois.dns.lu',
    'uk' => 'whois.nic.uk', 'io' => 'whois.nic.io', 'me' => 'whois.nic.me',
    'co' => 'whois.nic.co', 'cc' => 'whois.nic.cc', 'tv' => 'whois.nic.tv',
    'us' => 'whois.nic.us', 'ca' => 'whois.cira.ca', 'mx' => 'whois.mx',
    'cl' => 'whois.nic.cl', 'nz' => 'whois.srs.net.nz', 'jp' => 'whois.jprs.jp',
    'kr' => 'whois.kr', 'in' => 'whois.registry.in',
];
