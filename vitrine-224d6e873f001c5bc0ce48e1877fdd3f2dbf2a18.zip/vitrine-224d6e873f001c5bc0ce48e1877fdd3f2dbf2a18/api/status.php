<?php
/**
 * Mesure la disponibilité des services et renvoie un JSON.
 * Le résultat est mis en cache quelques secondes : la page interroge
 * toutes les dix secondes et plusieurs visiteurs peuvent être simultanés.
 */

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/../inc/config.php';
require_once __DIR__ . '/../inc/status_probe.php';

// Chaque appel non servi par le cache déclenche 9 requêtes HTTP sortantes :
// sans plafond, la page d'état devient un amplificateur gratuit.
rate_limit('status', 30, 60, 600);

const CACHE_FILE     = __DIR__ . '/../var/status-cache.json';
const CACHE_TTL      = 8;      // secondes

$cacheDir = dirname(CACHE_FILE);
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);

// Cache encore frais → on renvoie tel quel.
if (is_readable(CACHE_FILE) && (time() - (int) filemtime(CACHE_FILE)) < CACHE_TTL) {
    $cached = json_decode((string) file_get_contents(CACHE_FILE), true);
    if (is_array($cached)) {
        $cached['cached'] = true;
        json_out($cached);
    }
}

$services = status_probe();

$payload = [
    'ok'        => true,
    'checkedAt' => gmdate('c'),
    'services'  => $services,
];

@file_put_contents(CACHE_FILE, json_encode($payload), LOCK_EX);
json_out($payload);
