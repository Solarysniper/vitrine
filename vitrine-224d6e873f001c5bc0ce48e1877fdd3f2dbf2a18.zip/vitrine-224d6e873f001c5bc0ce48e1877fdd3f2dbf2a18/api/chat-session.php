<?php
/**
 * Sessions de conversation — escalade vers un membre de l'équipe.
 *
 * DIFFÉRENCES AVEC L'ANCIENNE VERSION (chat_session.php) :
 * 1. 'staff_reply' exige désormais la clé partagée du bot. Auparavant l'endpoint
 *    était ouvert : n'importe qui pouvait injecter un faux message « staff »
 *    dans la conversation d'un visiteur.
 * 2. Les sessions sont stockées dans var/chat/, hors de portée HTTP, au lieu de
 *    notif/sessions/ qui vivait dans l'arborescence web.
 * 3. Purge automatique au bout de 30 jours : ces fichiers contiennent un nom et
 *    une adresse e-mail, ils n'ont pas à s'accumuler indéfiniment.
 * 4. L'IDENTIFIANT DE SESSION EST ÉMIS PAR LE SERVEUR. Auparavant le
 *    navigateur le fabriquait lui-même (« web- » + Date.now() + 8 caractères
 *    de Math.random) : un tiers pouvait en deviner un et relever, via GET,
 *    les réponses du support destinées à un autre visiteur. Il vient
 *    maintenant de random_bytes(), et le navigateur ne fait que le
 *    transporter.
 */

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

const SESSION_DIR  = __DIR__ . '/../var/chat';
const SESSION_TTL  = 30 * 86400;

if (!is_dir(SESSION_DIR)) @mkdir(SESSION_DIR, 0700, true);

/** Un identifiant de session ne doit jamais pouvoir désigner un autre fichier. */
function session_path(string $raw): string
{
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', $raw);
    // On exige la longueur des identifiants que NOUS émettons : un ancien
    // identifiant court, devinable, n'est plus accepté.
    if (strlen($id) < 24 || strlen($id) > 64) {
        json_out(['ok' => false, 'error' => 'invalid_session'], 400);
    }
    return SESSION_DIR . '/' . $id . '.json';
}

/** Identifiant imprévisible — 32 octets d'aléa cryptographique. */
function new_session_id(): string
{
    return 'web-' . bin2hex(random_bytes(16));
}

function read_session(string $file): array
{
    return is_readable($file) ? (json_decode((string) file_get_contents($file), true) ?: []) : [];
}

function write_session(string $file, array $data): void
{
    @file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/** Nettoyage opportuniste des vieilles conversations. */
function purge_sessions(): void
{
    if (random_int(1, 40) !== 1) return;
    foreach (glob(SESSION_DIR . '/*.json') ?: [] as $file) {
        if (time() - (int) filemtime($file) > SESSION_TTL) @unlink($file);
    }
}
purge_sessions();

$conf = secrets();

// -------------------------------------------------------------------------
// GET : le navigateur relève les réponses de l'équipe auprès du bot.
// -------------------------------------------------------------------------
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    // La relève tourne toutes les 5 s dans l'onglet du visiteur : on la
    // plafonne pour qu'elle ne devienne pas un levier d'attaque, et on
    // refuse ce qui ne vient pas d'une page du site.
    require_same_origin();
    rate_limit('chat-poll', 60, 300, 2000);

    $id   = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($_GET['session'] ?? ''));
    $file = session_path($id);
    if (!is_file($file)) json_out(['ok' => false, 'error' => 'unknown_session'], 404);
    $data = read_session($file);

    $messages = [];
    $botUrl   = rtrim((string) ($conf['bot_url'] ?? ''), '/');

    // Compatibilité avec un bot qui expose /poll. LE BOT FOURNI DANS bot/
    // NE POUSSE PAS ses réponses vers staff_reply : il les garde dans ses
    // propres fichiers (bot/sessions/*.json) et les sert via GET /poll.
    // bot_poll DOIT donc être activé (true) dans les secrets, sinon les
    // réponses de l'équipe ne remontent jamais sur le site.
    if ($botUrl !== '' && !empty($conf['bot_poll'])) {
        $ch = curl_init($botUrl . '/poll?session=' . urlencode($id));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 6,
            CURLOPT_HTTPHEADER     => ['x-api-key: ' . ($conf['bot_secret'] ?? '')],
        ]);
        $raw  = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code === 200 && $raw) {
            $fromBot = json_decode((string) $raw, true);
            if (is_array($fromBot)) {
                $messages = $fromBot['messages'] ?? [];
                if (!empty($fromBot['closed'])) {
                    $data['closed'] = true;
                    write_session($file, $data);
                }
            }
        }
    }

    // Messages déposés directement par le bot via POST staff_reply
    foreach ($data['messages'] ?? [] as $i => $msg) {
        if (empty($msg['read'])) {
            $messages[] = $msg;
            $data['messages'][$i]['read'] = true;
        }
    }
    write_session($file, $data);

    json_out([
        'ok'       => true,
        'messages' => array_values($messages),
        'closed'   => !empty($data['closed']),
    ]);
}

// -------------------------------------------------------------------------
// POST
// -------------------------------------------------------------------------
$body      = json_body();
$action    = field($body, 'action', 30);

// 'staff_reply' est le SEUL cas appelé par le bot Discord (donc sans
// origine, avec la clé partagée). Tout le reste vient du navigateur.
if ($action !== 'staff_reply') {
    require_same_origin();
}

// L'ouverture ne fournit pas d'identifiant : c'est le serveur qui l'émet.
$sessionId = $action === 'init'
    ? new_session_id()
    : preg_replace('/[^a-zA-Z0-9_-]/', '', field($body, 'session', 64));
$file      = session_path($sessionId);
$data      = read_session($file);

switch ($action) {

    // Ouverture d'une conversation après escalade.
    case 'init':
        rate_limit('chat-init', 4, 900, 100);
        $email = field($body, 'email', 180);
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_out(['ok' => false, 'error' => 'invalid_email'], 422);
        }
        write_session($file, [
            'name'       => field($body, 'name', 120),
            'email'      => $email,
            'created_at' => time(),
            'last_user'  => time(),
            'closed'     => false,
            'messages'   => [],
        ]);
        // Le navigateur reçoit l'identifiant et se contente de le
        // retransmettre ensuite : il ne le choisit plus.
        json_out(['ok' => true, 'session' => $sessionId]);

    // Le visiteur écrit : on entretient la session pour le suivi côté équipe,
    // ET on prévient le bot pour que le message apparaisse sur Discord.
    // (Avant : seul le fichier de session local était mis à jour — l'équipe
    // ne voyait donc jamais les messages envoyés après le tout premier.)
    case 'user_message':
        if (!$data) json_out(['ok' => false, 'error' => 'unknown_session'], 404);
        rate_limit('chat-user-msg', 30, 300, 1500);
        $data['last_user'] = time();
        write_session($file, $data);

        $text = field($body, 'message', 1500);
        if ($text !== '') {
            $botUrl = rtrim((string) ($conf['bot_url'] ?? ''), '/');
            if ($botUrl !== '') {
                $ch = curl_init($botUrl . '/notify');
                curl_setopt_array($ch, [
                    CURLOPT_POST           => true,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT        => 6,
                    CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'x-api-key: ' . ($conf['bot_secret'] ?? '')],
                    CURLOPT_POSTFIELDS     => json_encode([
                        'type'    => 'user_message',
                        'session' => $sessionId,
                        'name'    => $data['name']  ?? '',
                        'email'   => $data['email'] ?? '',
                        'summary' => $text,
                    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                ]);
                curl_exec($ch);
                curl_close($ch);
            }
        }

        json_out(['ok' => true]);

    // Réponse d'un membre de l'équipe — RÉSERVÉE AU BOT.
    case 'staff_reply':
        rate_limit('chat-staff-attempts', 60, 600, 600);
        $given    = (string) ($_SERVER['HTTP_X_API_KEY'] ?? '');
        $expected = (string) ($conf['bot_secret'] ?? '');
        if ($expected === '' || !hash_equals($expected, $given)) {
            json_out(['ok' => false, 'error' => 'unauthorized'], 401);
        }
        if (!$data) json_out(['ok' => false, 'error' => 'unknown_session'], 404);

        $text = field($body, 'message', 4000);
        if ($text === '') json_out(['ok' => false, 'error' => 'empty_message'], 422);

        if (strtolower($text) === 'close') {
            $data['closed'] = true;
            write_session($file, $data);
            json_out(['ok' => true, 'closed' => true]);
        }

        $data['messages'][] = [
            'role'      => 'staff',
            'content'   => $text,
            'username'  => field($body, 'username', 80) ?: 'Support',
            'avatar'    => field($body, 'avatar', 300),
            'timestamp' => time(),
            'read'      => false,
        ];
        write_session($file, $data);
        json_out(['ok' => true]);

    // Fin de conversation demandée par le visiteur.
    case 'close':
        if (!$data) json_out(['ok' => false, 'error' => 'unknown_session'], 404);
        $data['closed'] = true;
        write_session($file, $data);
        // Le ticket Discord se ferme aussi (transcription + archivage du fil).
        $botUrl = rtrim((string) ($conf['bot_url'] ?? ''), '/');
        if ($botUrl !== '') {
            $ch = curl_init($botUrl . '/notify');
            curl_setopt_array($ch, [
                CURLOPT_POST           => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 4,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'x-api-key: ' . ($conf['bot_secret'] ?? '')],
                CURLOPT_POSTFIELDS     => json_encode(['type' => 'visitor_closed', 'session' => $sessionId], JSON_UNESCAPED_UNICODE),
            ]);
            curl_exec($ch);
            curl_close($ch);
        }
        json_out(['ok' => true]);
}

json_out(['ok' => false, 'error' => 'unknown_action'], 400);
