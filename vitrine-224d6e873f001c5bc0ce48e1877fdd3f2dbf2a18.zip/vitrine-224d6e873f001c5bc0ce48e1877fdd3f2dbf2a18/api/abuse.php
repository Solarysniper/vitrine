<?php
/** Signalement de contenu illicite → webhook Discord dédié. */

declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/../inc/config.php';

require_same_origin();
rate_limit('abuse', 3, 900, 60);
$body = json_body();

if (field($body, 'website') !== '') {
    json_out(['ok' => true]);
}

$lastname  = field($body, 'lastname', 120);
$firstname = field($body, 'firstname', 120);
$email     = field($body, 'email', 180);
$type      = field($body, 'type', 40);
$desc      = field($body, 'description', 4000);

if ($lastname === '' || $firstname === '' || $email === '' || $type === '' || $desc === '') {
    json_out(['ok' => false, 'error' => 'missing_fields'], 422);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_out(['ok' => false, 'error' => 'invalid_email'], 422);
}
if (!in_array($type, ['phishing', 'malware', 'network', 'dmca', 'hate', 'other'], true)) {
    json_out(['ok' => false, 'error' => 'invalid_type'], 422);
}

$fields = [
    ['name' => 'Déclarant', 'value' => $firstname . ' ' . $lastname, 'inline' => true],
    ['name' => 'E-mail',    'value' => $email, 'inline' => true],
    ['name' => 'Type',      'value' => $type,  'inline' => true],
];
foreach ([['service', 'Service'], ['ip', 'IP'], ['client', 'Client présumé'], ['url', 'URL'], ['notes', 'Notes']] as [$key, $label]) {
    $value = field($body, $key, 500);
    if ($value !== '') $fields[] = ['name' => $label, 'value' => $value, 'inline' => false];
}

$sent = deliver((string) (secrets()['webhook_abuse'] ?? ''), [
    'title'       => 'Signalement de contenu illicite',
    'color'       => 0xB91C1C,
    'description' => $desc,
    'fields'      => $fields,
    'footer'      => ['text' => 'artaun.fr · ' . client_ip()],
    'timestamp'   => gmdate('c'),
], 'Signalement — ' . $type);

if (!$sent) {
    json_out(['ok' => false, 'error' => 'delivery_failed'], 502);
}
json_out(['ok' => true]);
