<?php
/**
 * Reçoit le catalogue poussé par l'espace client (commande refonte:vitrine-sync,
 * toutes les 10 minutes) : noms, prix par durée, essais gratuits, limites des
 * offres mail. Écrit var/catalog.json, lu par inc/catalog.php.
 *
 * Même clé partagée que la synchro des prix de domaines (en-tête x-api-key,
 * comparaison en temps constant, refus sans clé configurée).
 */

declare(strict_types=1);
const API_MAX_BODY = 2 * 1024 * 1024;
require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/../inc/config.php';

rate_limit('catalog-sync-attempts', 20, 600, 200);

$secret = trim((string) (secrets()['domain_sync_secret'] ?? ''));
if ($secret === '') {
    json_out(['ok' => false, 'error' => 'sync_not_configured'], 503);
}
if (!hash_equals($secret, (string) ($_SERVER['HTTP_X_API_KEY'] ?? ''))) {
    json_out(['ok' => false, 'error' => 'unauthorized'], 401);
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);
}
rate_limit('catalog-sync', 30, 3600);

$raw = (string) file_get_contents('php://input', false, null, 0, 2 * 1024 * 1024);
$body = json_decode($raw, true, 8);
if (!is_array($body) || !is_array($body['products'] ?? null) || $body['products'] === []) {
    json_out(['ok' => false, 'error' => 'bad_payload'], 422);
}

// Seulement des valeurs simples et bornées : rien du contenu reçu n'est interprété comme du HTML.
$periods = ['monthly', 'quarterly', 'semiannually', 'annually', 'biennially', 'triennially', 'onetime'];
$products = [];
foreach ($body['products'] as $id => $p) {
    if (!ctype_digit((string) $id) || !is_array($p) || !is_array($p['prices'] ?? null)) continue;
    $prices = [];
    foreach ($p['prices'] as $k => $v) {
        if (in_array($k, $periods, true) && is_numeric($v) && $v >= 0 && $v < 100000) $prices[$k] = round((float) $v, 2);
    }
    if ($prices === []) continue;
    $products[(int) $id] = [
        'name' => mb_substr(strip_tags((string) ($p['name'] ?? '')), 0, 80),
        'group' => mb_substr(strip_tags((string) ($p['group'] ?? '')), 0, 80),
        'group_id' => isset($p['group_id']) && ctype_digit((string) $p['group_id']) ? (int) $p['group_id'] : null,
        'res' => is_array($p['res'] ?? null) ? ['cpu' => max(0, min(64, (float) ($p['res']['cpu'] ?? 0))), 'ram' => max(0, min(1024, (int) ($p['res']['ram'] ?? 0))), 'disk' => max(0, min(10000, (int) ($p['res']['disk'] ?? 0)))] : null,
        'status' => in_array($p['status'] ?? '', ['active', 'unreferenced'], true) ? $p['status'] : 'active',
        'prices' => $prices,
        'trial' => isset($p['trial']) && is_numeric($p['trial']) ? max(0, min(60, (int) $p['trial'])) : null,
        'stock' => isset($p['stock']) && is_numeric($p['stock']) ? (int) $p['stock'] : null,
    ];
}
$mail = [];
foreach ((array) ($body['mail_plans'] ?? []) as $id => $m) {
    if (!ctype_digit((string) $id) || !is_array($m)) continue;
    $num = fn ($v) => is_numeric($v) ? (int) $v : null;
    $mail[(int) $id] = ['mailboxes' => $num($m['mailboxes'] ?? null), 'storage_gb' => $num($m['storage_gb'] ?? null), 'domains' => $num($m['domains'] ?? null),
        'aliases' => $num($m['aliases'] ?? null), 'vault_gb' => $num($m['vault_gb'] ?? null), 'newsletters' => !empty($m['newsletters']), 'sign' => !empty($m['sign'])];
}
$clean = fn ($v, $n) => mb_substr(trim(strip_tags((string) $v)), 0, $n);
$reviews = [];
foreach (array_slice((array) ($body['reviews'] ?? []), 0, 40) as $r) {
    if (!is_array($r) || !isset($r['rating']) || (int) $r['rating'] < 1 || (int) $r['rating'] > 5) continue;
    $reviews[] = ['rating' => (int) $r['rating'], 'name' => $clean($r['name'] ?? '', 40), 'title' => $clean($r['title'] ?? '', 80), 'text' => $clean($r['text'] ?? '', 260),
        'date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($r['date'] ?? '')) ? (string) $r['date'] : ''];
}
if ($products === []) {
    json_out(['ok' => false, 'error' => 'no_valid_rows'], 422);
}

$target = __DIR__ . '/../var/catalog.json';
// Réécrit seulement si quelque chose a changé : la date du fichier invalide le cache des pages.
$prev = is_readable($target) ? json_decode((string) file_get_contents($target), true) : null;
// Monnaies d'affichage : code ISO, libellé et symbole courts, taux borné (rien n'est interprété comme du HTML).
$currencies = [];
foreach (array_slice((array) ($body['currencies'] ?? []), 0, 20, true) as $code => $c) {
    if (!preg_match('/^[A-Z]{3}$/', (string) $code) || !is_array($c)) continue;
    $rate = (float) ($c['rate'] ?? 0);
    if ($rate <= 0 || $rate > 100000) continue;
    $currencies[$code] = ['name' => $clean($c['name'] ?? $code, 40), 'symbol' => $clean($c['symbol'] ?? $code, 6), 'rate' => $rate, 'decimals' => max(0, min(3, (int) ($c['decimals'] ?? 2)))];
}
if (is_array($prev) && ($prev['products'] ?? null) == $products && ($prev['mail_plans'] ?? null) == $mail && ($prev['reviews'] ?? null) == $reviews && ($prev['currencies'] ?? null) == $currencies) {
    json_out(['ok' => true, 'unchanged' => true, 'products' => count($products)]);
}
$tmp = $target . '.tmp';
$json = json_encode(['generated' => (string) ($body['generated'] ?? date('c')), 'received' => date('c'), 'products' => $products, 'mail_plans' => $mail, 'reviews' => $reviews, 'currencies' => $currencies], JSON_UNESCAPED_UNICODE);
if ($json === false || file_put_contents($tmp, $json, LOCK_EX) === false || !rename($tmp, $target)) {
    json_out(['ok' => false, 'error' => 'write_failed'], 500);
}

json_out(['ok' => true, 'products' => count($products), 'mail_plans' => count($mail)]);
