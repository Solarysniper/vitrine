<?php
/**
 * Vérification de disponibilité d'un domaine + prix, pour la barre de
 * recherche de l'accueil.
 *
 * Deux usages (paramètre `mode`) :
 *  - 'register' (défaut) : on espère que le domaine soit LIBRE (achat).
 *  - 'transfer' : on espère qu'il soit déjà PRIS (transfert) — le prix
 *    renvoyé est alors le prix de transfert, pas celui de 1ère année.
 *
 * Vérification de disponibilité en deux temps :
 *  1. RDAP (https://rdap.org, structuré, rapide) — 200 = pris, 404 = a
 *     priori libre.
 *  2. Un 404 RDAP est ambigu : ça peut aussi vouloir dire "extension non
 *     couverte par l'annuaire RDAP public" (cas connu de .io, .de et une
 *     quarantaine d'autres extensions dites "RDAP furtif" — un 404 RDAP ne
 *     garantit alors RIEN). On confirme donc systématiquement un 404 par
 *     une requête WHOIS classique avant d'annoncer "disponible". Si aucun
 *     serveur WHOIS connu n'existe pour l'extension, ou que la requête
 *     échoue, on répond "unknown" plutôt qu'un faux "disponible".
 */

/**
 * Vérification de disponibilité d'un domaine + prix, pour la barre de
 * recherche du site (accueil + page /domaines/). Un seul flux désormais
 * (plus de paramètre `mode` register/transfer séparé) : on vérifie la
 * disponibilité, et on renvoie systématiquement le prix pertinent selon le
 * résultat — 1ère année + renouvellement si libre, prix de transfert si
 * déjà pris. Le front décide quoi afficher (bouton "Acheter" ou
 * "Transférer") à partir du seul champ `status`.
 *
 * Vérification de disponibilité en deux temps :
 *  1. RDAP (https://rdap.org, structuré, rapide) — 200 = pris, 404 = a
 *     priori libre.
 *  2. Un 404 RDAP est ambigu : ça peut aussi vouloir dire "extension non
 *     couverte par l'annuaire RDAP public" (cas connu de .io, .de et une
 *     quarantaine d'autres extensions dites "RDAP furtif" — un 404 RDAP ne
 *     garantit alors RIEN). On confirme donc systématiquement un 404 par
 *     une requête WHOIS classique avant d'annoncer "disponible". Si aucun
 *     serveur WHOIS connu n'existe pour l'extension, ou que la requête
 *     échoue, on répond "unknown" plutôt qu'un faux "disponible".
 */

declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/../inc/config.php';
require_once __DIR__ . '/../inc/i18n.php';

require_once __DIR__ . '/../inc/domain_prices.php';
require_once __DIR__ . '/../inc/domain_lookup.php';
$prices = load_domain_prices();
$whoisServers = require __DIR__ . '/../inc/whois_servers.php';

// Chaque vérification ouvre une requête RDAP et parfois une connexion
// WHOIS sortante : plafond serré par visiteur, plafond global pour que
// même une attaque distribuée ne puisse pas saturer ces dépendances.
require_same_origin();
rate_limit('domain-check', 12, 60, 300);

$raw = $_GET['domain'] ?? '';
$reqLang = (string) ($_GET['lang'] ?? 'fr');
$reqLang = array_key_exists($reqLang, LANGS) ? $reqLang : 'fr';

$domain = normalize_domain((string) $raw);
if ($domain === null) {
    json_out(['ok' => false, 'error' => 'invalid_domain'], 422);
}

[$name, $tld] = $domain;

if (!isset($prices[$tld])) {
    json_out(['ok' => true, 'domain' => $name . '.' . $tld, 'sold' => false]);
}

$status = check_domain_status($name, $tld, $whoisServers);

$response = [
    'ok'     => true,
    'domain' => $name . '.' . $tld,
    'name'   => $name,
    'tld'    => $tld,
    'sold'   => true,
    'status' => $status, // 'available' | 'taken' | 'unknown'
];

if ($status === 'available') {
    $response['price'] = $prices[$tld]['register'];
    $response['price_renew'] = $prices[$tld]['renew'];
    $response['price_fmt'] = price((float) $prices[$tld]['register'], $reqLang);
    $response['price_renew_fmt'] = price((float) $prices[$tld]['renew'], $reqLang);
} elseif ($status === 'taken') {
    $response['price'] = $prices[$tld]['transfer'];
    $response['price_fmt'] = price((float) $prices[$tld]['transfer'], $reqLang);
}

json_out($response);

