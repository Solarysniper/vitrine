<?php
/** Formulaire de contact → webhook Discord. */

declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/../inc/config.php';

// Un formulaire public est la porte d'entrée la plus simple pour noyer un
// webhook Discord : plafond par visiteur ET plafond global.
require_same_origin();
rate_limit('contact', 3, 900, 60);
$body = json_body();

// Pot de miel : rempli = robot.
if (field($body, 'website') !== '') {
    json_out(['ok' => true]);
}

$name    = field($body, 'name', 120);
$email   = field($body, 'email', 180);
$subject = field($body, 'subject', 180);
$message = field($body, 'message', 4000);

if ($name === '' || $email === '' || $subject === '' || $message === '') {
    json_out(['ok' => false, 'error' => 'missing_fields'], 422);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_out(['ok' => false, 'error' => 'invalid_email'], 422);
}
if (mb_strlen($message) < 10) {
    json_out(['ok' => false, 'error' => 'message_too_short'], 422);
}

$sent = deliver((string) (secrets()['webhook_contact'] ?? ''), [
    'title'       => 'Nouveau message de contact',
    'color'       => 0x2B46C9,
    'description' => $message,
    'fields'      => [
        ['name' => 'Nom',    'value' => $name,    'inline' => true],
        ['name' => 'E-mail', 'value' => $email,   'inline' => true],
        ['name' => 'Sujet',  'value' => $subject, 'inline' => false],
    ],
    'footer'    => ['text' => 'artaun.fr · ' . client_ip()],
    'timestamp' => gmdate('c'),
], 'Contact — ' . $subject);

if (!$sent) {
    json_out(['ok' => false, 'error' => 'delivery_failed'], 502);
}
json_out(['ok' => true]);
