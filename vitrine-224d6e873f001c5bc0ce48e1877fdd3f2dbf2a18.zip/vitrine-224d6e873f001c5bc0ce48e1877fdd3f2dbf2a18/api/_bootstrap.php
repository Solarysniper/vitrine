<?php
/**
 * Socle commun aux points d'API : réponses JSON, provenance, limitation de
 * débit, envoi. La lecture des secrets vit dans inc/secrets.php et le socle
 * de sécurité (IP réelle, seaux, jetons) dans inc/security.php — tous deux
 * partagés avec le site.
 */

declare(strict_types=1);

require_once __DIR__ . '/../inc/secrets.php';
require_once __DIR__ . '/../inc/config.php';
require_once __DIR__ . '/../inc/security.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex, nofollow');
header('Vary: Origin');

throttle_gc();

function json_out(array $payload, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Plafond général, appliqué à TOUT appel d'API avant même de savoir lequel.
 * C'est le premier rempart : une rafale s'arrête ici, sans avoir touché
 * une seule dépendance externe.
 */
function api_guard(): void
{
    if (!throttle('api', 120, 60, 4000)) {
        json_out(['ok' => false, 'error' => 'rate_limited'], 429);
    }

    // Une requête d'API ne doit jamais être mise en cache ni indexée, et
    // un corps démesuré n'a aucune raison d'être : on coupe court.
    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    // Limite relevée par l'endpoint lui-même si besoin (catalogue : plusieurs centaines d'offres).
    if ($length > (defined('API_MAX_BODY') ? API_MAX_BODY : 64 * 1024)) {
        json_out(['ok' => false, 'error' => 'payload_too_large'], 413);
    }
}
api_guard();

/**
 * Exige que l'appel vienne d'une page du site.
 * $allowServerToServer : points d'entrée appelés par le bot Discord ou
 * ClientXCMS, qui s'authentifient par clé partagée et n'ont pas d'origine.
 */
function require_same_origin(bool $allowServerToServer = false): void
{
    if (!same_origin($allowServerToServer)) {
        json_out(['ok' => false, 'error' => 'forbidden_origin'], 403);
    }
}

/** Corps JSON de la requête. */
function json_body(): array
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_out(['ok' => false, 'error' => 'method_not_allowed'], 405);
    }
    $raw = (string) file_get_contents('php://input', false, null, 0, 64 * 1024);
    $body = json_decode($raw, true, 8);
    if (!is_array($body)) {
        json_out(['ok' => false, 'error' => 'bad_request'], 400);
    }
    return $body;
}

/**
 * Limitation par IP + plafond global, en JSON.
 * Conservé sous son ancien nom : tous les points d'API l'appellent déjà.
 */
function rate_limit(string $bucket, int $max, int $windowSeconds, int $global = 0): void
{
    $ok = throttle($bucket, $max, $windowSeconds, $global, function (int $retryAfter) {
        json_out(['ok' => false, 'error' => 'rate_limited', 'retry_after' => $retryAfter], 429);
    });
    if (!$ok) exit;
}

/** Champ texte nettoyé (caractères de contrôle retirés, longueur bornée). */
function field(array $body, string $key, int $max = 500): string
{
    $value = $body[$key] ?? '';
    if (is_array($value) || is_object($value)) return '';
    return clean_text(is_scalar($value) ? (string) $value : '', $max);
}

/**
 * Envoi vers un webhook Discord.
 *
 * L'URL est vérifiée avant l'appel : seul un webhook Discord légitime est
 * accepté. Sans ce contrôle, une valeur de configuration erronée (ou
 * altérée) transformerait ce code en relais vers n'importe quelle machine
 * — y compris une adresse interne (SSRF).
 */
function post_discord(string $webhook, array $embed): bool
{
    $webhook = trim($webhook);
    if ($webhook === '') return false;

    $parts = parse_url($webhook);
    $hostOk = isset($parts['host']) && in_array(strtolower($parts['host']), ['discord.com', 'discordapp.com', 'ptb.discord.com', 'canary.discord.com'], true);
    if (($parts['scheme'] ?? '') !== 'https' || !$hostOk || !str_starts_with((string) ($parts['path'] ?? ''), '/api/webhooks/')) {
        error_log('[artaun] webhook refusé (URL non conforme à un webhook Discord)');
        return false;
    }

    $ch = curl_init($webhook);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_PROTOCOLS_STR  => 'https',
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode(['embeds' => [$embed]], JSON_UNESCAPED_UNICODE),
    ]);
    $resp = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($code < 200 || $code >= 300) {
        error_log('[artaun] échec webhook Discord — HTTP ' . $code . ' ' . $err . ' — réponse : ' . substr((string) $resp, 0, 300));
        return false;
    }
    return true;
}

/**
 * Achemine un message vers l'équipe.
 * Webhook Discord si disponible, sinon courriel : un formulaire qui n'envoie
 * rien parce qu'une clé manque est pire qu'un formulaire lent.
 */
function deliver(string $webhook, array $embed, string $subject): bool
{
    if (post_discord($webhook, $embed)) return true;

    $lines = [$embed['description'] ?? ''];
    foreach ($embed['fields'] ?? [] as $f) {
        $lines[] = $f['name'] . ' : ' . $f['value'];
    }
    $lines[] = '';
    $lines[] = 'Envoyé depuis ' . SITE_URL . ' — ' . client_ip();

    // Sujet et en-têtes nettoyés : un retour à la ligne glissé dans le sujet
    // permettrait d'ajouter des destinataires (injection d'en-têtes SMTP).
    return @mail(
        SITE_EMAIL,
        clean_header($subject, 180),
        implode("\n", $lines),
        "Content-Type: text/plain; charset=UTF-8\r\nFrom: no-reply@" . parse_url(SITE_URL, PHP_URL_HOST)
    );
}
