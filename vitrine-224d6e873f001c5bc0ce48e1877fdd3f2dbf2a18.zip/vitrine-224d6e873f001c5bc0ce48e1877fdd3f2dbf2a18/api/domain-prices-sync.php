<?php
/**
 * Reçoit les prix de domaines poussés depuis l'admin ClientXCMS (addon
 * openprovider-domains, voir sa méthode syncToVitrine()) et régénère
 * entièrement inc/domain-prices.txt à partir de ce qui est envoyé.
 *
 * Protégé par une clé partagée (en-tête x-api-key, comparée en temps
 * constant — même principe que api/chat-session.php pour staff_reply).
 * Sans cette clé configurée des deux côtés, cet endpoint refuse tout,
 * fail-closed : mieux vaut un prix pas encore synchronisé qu'un endpoint
 * qui accepterait n'importe quelle requête.
 */

declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';
require_once __DIR__ . '/../inc/config.php';

// Appelé par ClientXCMS, sans navigateur : pas d'origine à vérifier, la
// clé partagée fait foi. On limite quand même les tentatives.
rate_limit('domain-sync-attempts', 20, 600, 200);

$secret = trim((string) (secrets()['domain_sync_secret'] ?? ''));
if ($secret === '') {
    json_out(['ok' => false, 'error' => 'sync_not_configured'], 503);
}

$given = (string) ($_SERVER['HTTP_X_API_KEY'] ?? '');
if (!hash_equals($secret, $given)) {
    json_out(['ok' => false, 'error' => 'unauthorized'], 401);
}

rate_limit('domain-prices-sync', 30, 3600);

$body = json_body();
$prices = $body['prices'] ?? null;
if (!is_array($prices) || $prices === []) {
    json_out(['ok' => false, 'error' => 'empty_payload'], 422);
}

$lines = [];
$lines[] = '# Prix des extensions de domaines — Artaun Hosting';
$lines[] = '#';
$lines[] = '# Fichier régénéré AUTOMATIQUEMENT à chaque sauvegarde de prix côté';
$lines[] = '# admin ClientXCMS (Extensions & prix). Une modification manuelle ici';
$lines[] = '# sera écrasée au prochain envoi — pour un changement durable, faites-le';
$lines[] = '# depuis l\'admin ClientXCMS, pas ici.';
$lines[] = '#';
$lines[] = '# Dernière synchronisation : ' . date('Y-m-d H:i:s');
$lines[] = '';

$written = 0;
foreach ($prices as $ext => $row) {
    $ext = preg_replace('/[^a-z0-9]/', '', mb_strtolower((string) $ext));
    if ($ext === '' || !is_array($row)) {
        continue;
    }
    $register = (float) ($row['register'] ?? $row['renew'] ?? 0);
    $renew = (float) ($row['renew'] ?? $register);
    $transfer = (float) ($row['transfer'] ?? $renew);

    $lines[] = $ext;
    $lines[] = 'achat = ' . format_price_value($register);
    $lines[] = 'renouvellement = ' . format_price_value($renew);
    $lines[] = 'transfert = ' . format_price_value($transfer);
    $lines[] = '';
    $written++;
}

if ($written === 0) {
    json_out(['ok' => false, 'error' => 'no_valid_rows'], 422);
}

// Écrit dans var/ (seul dossier inscriptible par le site) ; inc/ reste en lecture seule.
$target = __DIR__ . '/../var/domain-prices.txt';
$tmp = $target . '.tmp';
if (file_put_contents($tmp, implode("\n", $lines), LOCK_EX) === false || !rename($tmp, $target)) {
    json_out(['ok' => false, 'error' => 'write_failed'], 500);
}

json_out(['ok' => true, 'written' => $written]);

function format_price_value(float $n): string
{
    // Nombre entier : pas de décimales. Sinon 2 décimales avec un point
    // (parsé indifféremment par domain_prices.php côté lecture).
    return (float) (int) $n === $n ? (string) (int) $n : number_format($n, 2, '.', '');
}
