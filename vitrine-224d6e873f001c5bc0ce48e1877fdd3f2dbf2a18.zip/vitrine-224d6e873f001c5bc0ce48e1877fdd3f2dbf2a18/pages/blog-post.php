<?php
/** Article de blog : corps long, sommaire, articles liés. */

$parsed   = content_parse($blogPost['file']);
$rendered = content_render($parsed['body']);
$related  = blog_related(lang(), $blogPost['key']);
$date     = $blogPost['meta']['date'] ?? null;
$updated  = $blogPost['meta']['updated'] ?? $date;
$author   = $blogPost['meta']['author'] ?? SITE_NAME;
$minutes  = reading_time($parsed['body']);
?>

<section class="page-hero page-hero-doc">
  <div class="wrap wrap-narrow">
    <p class="blog-meta">
      <?php if (!empty($blogPost['meta']['tag'])): ?><em class="badge badge-brand"><?= h($blogPost['meta']['tag']) ?></em><?php endif; ?>
      <?php if ($date): ?><time datetime="<?= h($date) ?>"><?= e('blog.published') ?> <?= h($date) ?></time><?php endif; ?>
      <span><?= e('blog.read_time', $minutes) ?></span>
    </p>
    <h1><?= h($blogPost['title']) ?></h1>
    <p class="page-lead"><?= h($blogPost['desc']) ?></p>
    <p class="page-from"><?= e('blog.by') ?> <b><?= h($author) ?></b></p>
    <?php if (!empty($blogPost['fallback'])): ?>
    <aside class="callout callout-warn doc-fallback"><?= icon('flag') ?><p><?= e('docs.fallback') ?></p></aside>
    <?php endif; ?>
  </div>
</section>

<section class="sec sec-tight">
  <div class="wrap">
    <div class="docs-layout docs-layout-post">
      <article class="prose prose-wide"><?= $rendered['html'] ?></article>

      <?php if (count($rendered['toc']) > 1): ?>
      <aside class="docs-toc">
        <p class="docs-side-title"><?= e('docs.toc') ?></p>
        <ol data-toc>
          <?php foreach ($rendered['toc'] as $item): ?>
          <li class="toc-l<?= (int) $item['level'] ?>"><a href="#<?= h($item['id']) ?>"><?= h($item['text']) ?></a></li>
          <?php endforeach; ?>
        </ol>
      </aside>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php if ($related): ?>
<section class="sec">
  <div class="wrap">
    <header class="sec-head">
      <p class="eyebrow"><?= e('blog.eyebrow') ?></p>
      <h2><?= e('blog.related') ?></h2>
    </header>
    <div class="cards-3">
      <?php foreach ($related as $post): ?>
      <a class="card card-lift" href="<?= h(blog_url($post['slug'])) ?>">
        <span class="card-ic"><?= icon($post['meta']['icon'] ?? 'chart') ?></span>
        <h3><?= h($post['title']) ?></h3>
        <p><?= h($post['desc']) ?></p>
        <span class="card-from"><?= e('blog.read_time', reading_time(content_parse($post['file'])['body'])) ?></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="sec cta-band">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('blog.cta.title') ?></h2>
        <p><?= e('blog.cta.lead') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary btn-lg" href="<?= h(url('home')) ?>#offres"><?= e('v3.cta.offers') ?></a>
        <a class="btn btn-ghost btn-lg" href="<?= h(url('blog')) ?>"><?= e('blog.back') ?></a>
      </div>
    </div>
  </div>
</section>

<?php
echo jsonld(array_filter([
    '@context'         => 'https://schema.org',
    '@type'            => 'BlogPosting',
    'headline'         => $blogPost['title'],
    'description'      => $blogPost['desc'],
    'inLanguage'       => LANGS[lang()]['hreflang'],
    'mainEntityOfPage' => ['@type' => 'WebPage', '@id' => SITE_URL . seo_path(lang())],
    'author'           => ['@type' => 'Organization', 'name' => $author, 'url' => SITE_URL],
    'publisher'        => seo_publisher(),
    'datePublished'    => $date,
    'dateModified'     => $updated,
    'keywords'         => $blogPost['meta']['keywords'] ?? '',
    'articleSection'   => $blogPost['meta']['tag'] ?? null,
    'wordCount'        => str_word_count(strip_tags($parsed['body'])),
    'image'            => SITE_URL . '/assets/img/og-image.png',
]));
?>
