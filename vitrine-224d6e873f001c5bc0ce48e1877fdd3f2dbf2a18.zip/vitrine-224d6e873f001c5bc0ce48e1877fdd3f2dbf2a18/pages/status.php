<?php
/** État des services — la mesure est faite côté serveur par /api/status.php. */

$groups = [];
foreach (STATUS_SERVICES as $svc) {
    $groups[$svc['group']][] = $svc;
}
?>
<section class="page-hero">
  <div class="wrap">
    <h1><?= e('status.title') ?></h1>
    <p class="page-lead"><?= e('status.lead') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap">

    <div class="status-banner is-checking" data-status-banner
         data-l-ok="<?= e('status.all_ok') ?>"
         data-l-warn="<?= e('status.degraded') ?>"
         data-l-down="<?= e('status.down') ?>">
      <span class="pulse"></span>
      <strong data-status-headline><?= e('status.checking') ?></strong>
      <span class="status-updated"><?= e('status.updated') ?> <time data-status-time>—</time></span>
    </div>

    <div class="status-summary">
      <div class="stat"><span class="stat-k"><?= e('status.services') ?></span><b data-stat-total><?= count(STATUS_SERVICES) ?></b></div>
      <div class="stat"><span class="stat-k"><?= e('status.up') ?></span><b data-stat-up>—</b></div>
      <div class="stat"><span class="stat-k"><?= e('status.latency') ?></span><b data-stat-latency>—</b></div>
    </div>

    <?php foreach ($groups as $groupKey => $services): ?>
    <section class="status-group">
      <h2><?= e('status.group.' . $groupKey) ?></h2>
      <ul class="status-list">
        <?php foreach ($services as $svc): ?>
        <li class="status-row" data-service="<?= h($svc['id']) ?>">
          <span class="status-led" aria-hidden="true"></span>
          <span class="status-name"><?= e('status.svc.' . $svc['id']) ?></span>
          <span class="status-spark" data-spark></span>
          <span class="status-ms" data-ms>—</span>
          <span class="status-state" data-state
                data-l-up="<?= e('status.up') ?>"
                data-l-warn="<?= e('status.warn') ?>"
                data-l-down="<?= e('status.offline') ?>"><?= e('status.checking') ?></span>
        </li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endforeach; ?>

    <p class="status-note"><?= icon('discord') ?><?= e('status.incident_note') ?> <a href="<?= h(LINKS['discord']) ?>" rel="noopener">Discord</a></p>
  </div>
</section>
