<?php
/** Rendu générique des documents juridiques. */
$doc = $GLOBALS['ARTAUN']['strings']['doc.' . current_page()] ?? null;
if (!$doc) { require __DIR__ . '/404.php'; return; }
?>
<section class="page-head">
  <div class="wrap wrap-narrow">
    <p class="eyebrow"><?= h($doc['eyebrow']) ?></p>
    <h1><?= h($doc['title']) ?></h1>
    <p class="doc-meta"><?= h($doc['updated']) ?></p>
    <?php if (!empty($doc['note'])): ?>
    <p class="doc-note"><?= icon('flag') ?><?= h($doc['note']) ?></p>
    <?php endif; ?>
  </div>
</section>

<section class="sec">
  <div class="wrap wrap-narrow doc-layout">
    <nav class="doc-toc" aria-label="Sommaire">
      <ol>
        <?php foreach ($doc['sections'] as $i => $s): ?>
        <li><a href="#s<?= $i + 1 ?>"><?= h($s['title']) ?></a></li>
        <?php endforeach; ?>
      </ol>
    </nav>
    <div class="doc">
      <?php foreach ($doc['sections'] as $i => $s): ?>
      <article class="doc-sec" id="s<?= $i + 1 ?>">
        <h2><span class="doc-n"><?= sprintf('%02d', $i + 1) ?></span><?= h($s['title']) ?></h2>
        <?= preg_replace_callback('/\{url:([a-z-]+)\}/', fn($m) => h(url($m[1])), $s['body']) ?>
      </article>
      <?php endforeach; ?>
      <p class="doc-contact"><?= e('contact.title') ?> : <a href="mailto:<?= SITE_EMAIL ?>"><?= SITE_EMAIL ?></a></p>
    </div>
  </div>
</section>
