<?php
/** Page « bientôt disponible » d'un service annoncé. */
$key = $soonKey;
?>
<section class="page-hero">
  <div class="wrap">
    <p class="eyebrow"><span class="dot"></span><?= e('soon.badge') ?></p>
    <h1><?= e('soon.' . $key . '.title') ?></h1>
    <p class="page-lead"><?= e('soon.' . $key . '.desc') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap wrap-narrow">
    <div class="soon-card">
      <span class="card-ic"><?= icon('clock') ?></span>
      <h2><?= e('soon.title') ?></h2>
      <p><?= e('soon.lead') ?></p>
      <div class="cta-actions">
        <a class="btn btn-primary" href="<?= h(LINKS['discord']) ?>" rel="noopener"><?= e('soon.notify') ?></a>
        <a class="btn btn-ghost" href="<?= h(url('home')) ?>"><?= e('soon.back') ?></a>
      </div>
    </div>
  </div>
</section>
