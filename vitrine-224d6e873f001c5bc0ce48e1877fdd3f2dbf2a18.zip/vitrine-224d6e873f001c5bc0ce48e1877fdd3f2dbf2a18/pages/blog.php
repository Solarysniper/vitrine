<?php
/** Blog : liste des articles, le plus récent mis en avant. */

$posts    = blog_posts(lang());
$featured = $posts ? array_shift($posts) : null;
?>

<section class="page-hero page-hero-center">
  <div class="wrap">
    <p class="eyebrow"><?= e('blog.eyebrow') ?></p>
    <h1><?= e('blog.title') ?></h1>
    <p class="page-lead"><?= e('blog.lead') ?></p>
  </div>
</section>

<?php if (!$featured): ?>
<section class="sec">
  <div class="wrap wrap-narrow">
    <p class="sec-lead center"><?= e('blog.empty') ?></p>
  </div>
</section>
<?php else: ?>

<section class="sec sec-tight">
  <div class="wrap">
    <a class="blog-hero" href="<?= h(blog_url($featured['slug'])) ?>">
      <span class="blog-hero-mark"><?= icon($featured['meta']['icon'] ?? 'bolt') ?></span>
      <div class="blog-hero-txt">
        <p class="blog-meta">
          <?php if (!empty($featured['meta']['tag'])): ?><em class="badge badge-brand"><?= h($featured['meta']['tag']) ?></em><?php endif; ?>
          <?php if (!empty($featured['meta']['date'])): ?><time datetime="<?= h($featured['meta']['date']) ?>"><?= h($featured['meta']['date']) ?></time><?php endif; ?>
          <span><?= e('blog.read_time', reading_time(content_parse($featured['file'])['body'])) ?></span>
        </p>
        <h2><?= h($featured['title']) ?></h2>
        <p class="blog-hero-lead"><?= h($featured['desc']) ?></p>
        <span class="link-btn"><?= e('cat.discover') ?></span>
      </div>
    </a>
  </div>
</section>

<section class="sec sec-tight">
  <div class="wrap">
    <div class="blog-grid">
      <?php foreach ($posts as $post): ?>
      <a class="blog-card" href="<?= h(blog_url($post['slug'])) ?>">
        <span class="card-ic"><?= icon($post['meta']['icon'] ?? 'chart') ?></span>
        <p class="blog-meta">
          <?php if (!empty($post['meta']['tag'])): ?><em class="badge"><?= h($post['meta']['tag']) ?></em><?php endif; ?>
          <?php if (!empty($post['meta']['date'])): ?><time datetime="<?= h($post['meta']['date']) ?>"><?= h($post['meta']['date']) ?></time><?php endif; ?>
        </p>
        <h2><?= h($post['title']) ?></h2>
        <p><?= h($post['desc']) ?></p>
        <span class="blog-card-go"><?= e('blog.read_time', reading_time(content_parse($post['file'])['body'])) ?><?= icon('arrow') ?></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="sec cta-band">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('blog.cta.title') ?></h2>
        <p><?= e('blog.cta.lead') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary btn-lg" href="<?= h(url('home')) ?>#offres"><?= e('v3.cta.offers') ?></a>
        <a class="btn btn-ghost btn-lg" href="<?= h(url('docs')) ?>"><?= e('docs.title') ?></a>
      </div>
    </div>
  </div>
</section>

<?php
$all = blog_posts(lang());
if ($all) {
    echo jsonld([
        '@context'        => 'https://schema.org',
        '@type'           => 'Blog',
        'name'            => t('blog.meta.title'),
        'description'     => t('blog.meta.desc'),
        'url'             => SITE_URL . seo_path(lang()),
        'inLanguage'      => LANGS[lang()]['hreflang'],
        'publisher'       => seo_publisher(),
        'blogPost'        => array_map(fn($p) => [
            '@type'         => 'BlogPosting',
            'headline'      => $p['title'],
            'description'   => $p['desc'],
            'url'           => SITE_URL . blog_url($p['slug']),
            'datePublished' => $p['meta']['date'] ?? null,
            'author'        => ['@type' => 'Organization', 'name' => SITE_NAME],
        ], array_slice($all, 0, 12)),
    ]);
}
?>
