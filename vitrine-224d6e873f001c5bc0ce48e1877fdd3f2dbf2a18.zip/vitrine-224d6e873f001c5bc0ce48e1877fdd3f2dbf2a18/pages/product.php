<?php
/**
 * Gabarit produit — piloté par le catalogue, identique pour toutes les offres (refonte du 24/10/2026) :
 * héros (titre, chiffres clés, visuel), offres, Anti-DDoS Netrix, matériel, pourquoi Artaun, FAQ en deux
 * colonnes, guides, offres proches, bandeau final.
 */

$data  = CATALOG[$product];
$cat   = $data['category'];
$plans = $data['plans'];
$name  = product_text($product, 'name');
$isGame = $cat === 'game';
$cpu   = infra_cpu($product);

$catPage = ['web' => 'web', 'vps' => 'vps', 'game' => 'games', 'bot' => 'games', 'reseller' => 'revendeurs', 'ip' => 'datacenter'][$cat] ?? 'home';

// Produits proches pour « voir aussi » : même genre d'abord pour les jeux (maillage interne).
$sameCat = array_keys(products_in($cat));
$related = array_values(array_diff($sameCat, [$product]));
if ($isGame && !empty($data['subcategory'])) {
    usort($related, fn($a, $b) => (int) ((CATALOG[$b]['subcategory'] ?? '') === $data['subcategory']) <=> (int) ((CATALOG[$a]['subcategory'] ?? '') === $data['subcategory']));
}
$related = array_slice($related, 0, 3);
$featIcons = ['web' => ['globe', 'lock', 'archive'], 'vps' => ['terminal', 'server', 'bolt'], 'game' => ['gauge', 'gamepad', 'shield'], 'bot' => ['clock', 'terminal', 'euro'], 'reseller' => ['feather', 'euro', 'shield'], 'ip' => ['route', 'bolt', 'shield']][$cat] ?? ['check', 'check', 'check'];
// FAQ : série propre à l'offre (faq.p.<offre>.N) si elle existe ; sinon, pour un jeu, une série générée au nom
// du jeu (prix réel) ; sinon celle de la famille. Google l'affiche en résultat enrichi : mieux vaut qu'elle soit précise.
$faqItems = [];
if (has('faq.p.' . $product . '.1.q') || ($cat !== 'game')) {
    $faqPrefix = has('faq.p.' . $product . '.1.q') ? 'faq.p.' . $product : (has('faq.' . $cat . '.1.q') ? 'faq.' . $cat : 'faq.web');
    for ($n = 1; $n <= 12 && has($faqPrefix . '.' . $n . '.q'); $n++) $faqItems[] = [t($faqPrefix . '.' . $n . '.q'), t($faqPrefix . '.' . $n . '.a')];
} else {
    for ($n = 1; $n <= 5; $n++) $faqItems[] = [t('v4.gfaq.' . $n . '.q', $name), t('v4.gfaq.' . $n . '.a', $name, price($data['from']))];
}
$faqCount = count($faqItems);
$featCat = has('feat.' . $cat . '.1.title') ? $cat : 'web';

// Titre : le nom de l'offre en couleur (deuxième ligne de lecture, comme sur les grands hébergeurs).
$title = product_text($product, 'title');
$titleHtml = h($title);
if ($name !== '' && mb_stripos($title, $name) !== false) {
    $pos = mb_stripos($title, $name);
    $titleHtml = h(mb_substr($title, 0, $pos)) . '<span class="hl">' . h(mb_substr($title, $pos, mb_strlen($name))) . '</span>' . h(mb_substr($title, $pos + mb_strlen($name)));
}

// Caractéristiques « principales » (en gras, avec icône) et « incluses » (coche).
$specIcon = ['cpu' => 'cpu', 'ram' => 'memory', 'ssd' => 'disk', 'nvme' => 'disk', 'db' => 'database', 'dbu' => 'database', 'ip' => 'globe', 'ipded' => 'globe',
    'net' => 'activity', 'bw' => 'activity', 'mail' => 'mail', 'mailu' => 'mail', 'mailbox' => 'mail', 'mailstorage' => 'disk', 'maildomains' => 'link',
    'mailalias' => 'route', 'accounts' => 'user', 'accountsu' => 'user', 'domains' => 'link'];
$art = game_art($product);
// Essai gratuit (première offre, configuré dans l'espace client) et migration gratuite : mis en avant dès le héros.
$trialIdx = null;
foreach ($plans as $i => $pl) { if (has_free_trial($product, $i)) { $trialIdx = $i; break; } }
$trialPlan = $trialIdx !== null ? $plans[$trialIdx] : null;
$canMigrate = in_array($cat, ['game', 'bot', 'vps'], true) || in_array($product, ['web-hosting', 'vps-pterodactyl'], true);
?>

<section class="ph<?= $art ? ' ph-bg' : '' ?>">
  <?php if ($art): ?>
  <?php $hero = game_hero($product); ?>
  <div class="ph-bg-art" aria-hidden="true"><?php if ($hero): ?><picture><?php if ($hero['mobile']): ?><source media="(max-width:860px)" srcset="<?= h($hero['mobile']) ?>"><?php endif; ?><img src="<?= h($hero['src']) ?>" alt="" fetchpriority="high" decoding="async"<?= $hero['focus'] ? ' style="--focus:' . h($hero['focus']) . '"' : '' ?>></picture><?php else: ?><img class="is-lowres" src="<?= h($art) ?>" alt="" width="720" height="405" fetchpriority="high" decoding="async"><?php endif; ?></div>
  <?php endif; ?>
  <div class="wrap ph-grid">
    <div class="ph-copy">
      <p class="ph-eyebrow"><span class="ph-logo"><?= brand($product, $data['icon'], 'ph-logo-img', true) ?></span><?= e('v4.hero.eyebrow', t('cat.' . ($catPage === 'datacenter' ? 'vps' : ($catPage === 'home' ? 'web' : $catPage)) . '.title')) ?></p>
      <h1 class="ph-title"><?= $titleHtml ?></h1>
      <p class="ph-lead"><?= h(product_text($product, 'lead')) ?></p>
      <div class="ph-cta">
        <a class="btn btn-primary btn-lg" href="#offres"><?= e('v4.cta.offers') ?></a>
        <?php if ($trialPlan && !empty($trialPlan['sku'])): ?><a class="btn btn-trial btn-lg" href="<?= h(trial_url((int) $trialPlan['sku'])) ?>" rel="nofollow noopener"><?= icon('gift') ?><?= e('trial.cta') ?></a><?php endif; ?>
        <?php if (chat_enabled()): ?><button type="button" class="btn-link" data-chat-open data-chat-ask="<?= h(t('v2.ai.ask', $name)) ?>"><?= e('v2.ai.cta') ?> <span aria-hidden="true">›</span></button><?php endif; ?>
      </div>
      <p class="ph-from"><?= sprintf(h(t('v4.hero.from', '%s')), '<b>' . money($data['from']) . '</b>') ?></p>
      <?php if ($trialPlan || $canMigrate): ?>
      <ul class="ph-perks">
        <?php if ($trialPlan): ?><li class="is-trial"><?= icon('gift') ?><?= e('trial.pill') ?></li><?php endif; ?>
        <?php if ($canMigrate): ?><li><a href="#migration"><?= icon('migrate') ?><?= e('mig.chip') ?></a></li><?php endif; ?>
      </ul>
      <?php endif; ?>
    </div>

    <?php if (!$art): ?>
    <div class="ph-visual">
      <div class="ph-spec-card">
        <div class="ph-spec-row"><span><?= icon('cpu') ?><?= e('v4.stat.cpu', '') ?></span><b><?= h($cpu['model']) ?></b></div>
        <div class="ph-spec-row"><span><?= icon('gauge') ?>GHz</span><b><?= h(infra_ghz($cpu['ghz'])) ?></b></div>
        <div class="ph-spec-row"><span><?= icon('memory') ?><?= e('v4.stat.ram') ?></span><b><?= h(INFRA['ram']) ?></b></div>
        <div class="ph-spec-row"><span><?= icon('disk') ?><?= e('v4.stat.nvme') ?></span><b>NVMe</b></div>
        <div class="ph-spec-row"><span><?= icon('shieldok') ?><?= e('v4.stat.ddos') ?></span><b><?= h(INFRA['ddos']['capacity']) ?></b></div>
        <div class="ph-spec-row"><span><?= icon('pin') ?><?= e('v4.stat.paris') ?></span><b><?= e('v4.stat.paris_v') ?></b></div>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <div class="wrap">
    <dl class="statband">
      <div><dt><?= h(infra_ghz($cpu['ghz'])) ?></dt><dd><?= e('v4.stat.cpu', $cpu['model']) ?></dd></div>
      <div><dt><?= h(INFRA['ddos']['capacity']) ?></dt><dd><?= e('v4.stat.ddos') ?></dd></div>
      <div><dt><?= e('v4.stat.nvme_v') ?></dt><dd><?= e('v4.stat.nvme') ?></dd></div>
      <div><dt><?= e('v4.stat.paris_v') ?></dt><dd><?= e('v4.stat.paris') ?></dd></div>
    </dl>
  </div>
</section>

<section class="sec" id="pricing">
  <span id="offres" class="anchor" aria-hidden="true"></span>
  <div class="wrap">
    <header class="sec-head center">
      <h2><?= e('v4.offers.title', $name) ?></h2>
      <p class="sec-lead"><?= e('v4.offers.lead') ?></p>
      <?php if ($trialPlan): ?><p class="trial-note"><?= icon('gift') ?><span><?= e('trial.offers.note', $trialPlan['name']) ?></span></p><?php endif; ?>
    </header>
    <?php $periods = product_periods($product); ?>
    <?php if (count($periods) > 1): ?>
    <div class="billing">
      <div class="toggle" data-billing role="group">
        <?php foreach ($periods as $per): $pct = product_period_discount($product, $per); ?>
        <button type="button"<?= $per === 'monthly' ? ' class="is-active"' : '' ?> data-period="<?= h($per) ?>"><?= e('price.' . $per) ?><?php if ($pct > 0): ?><em>-<?= $pct ?>%</em><?php endif; ?></button>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="plans-carousel<?= count($plans) > 4 ? ' has-nav' : '' ?>" data-carousel>
      <?php if (count($plans) > 4): ?>
      <button type="button" class="carousel-nav carousel-prev" data-carousel-prev aria-label="<?= e('a11y.carousel_prev') ?>"><?= icon('arrow', 'rot') ?></button>
      <?php endif; ?>
      <div class="plans plans-<?= count($plans) > 4 ? 'wide' : 'std' ?>" data-carousel-track>
        <?php foreach ($plans as $pIdx => $plan): $pop = !empty($plan['popular']); $trial = has_free_trial($product, $pIdx);
          $main = []; $extra = [];
          foreach ($plan['specs'] as $sp) { isset($specIcon[$sp[0]]) ? $main[] = $sp : $extra[] = $sp; } ?>
        <article class="plan plan2<?= $pop ? ' is-popular' : '' ?>">
          <?php if ($pop): ?><span class="plan-tag"><?= e('price.popular') ?></span>
          <?php elseif ($trial): ?><span class="plan-tag plan-tag-trial"><?= e('price.trial') ?></span>
          <?php endif; ?>
          <p class="plan-cat"><?= $isGame && count($plans) >= 3 && count($plans) <= 5 ? e('v4.aud.' . (int) round(1 + $pIdx * 4 / (count($plans) - 1))) : h($name) ?></p>
          <h3 class="plan-name"><?= h($plan['name']) ?></h3>
          <p class="plan-price">
            <span class="amount" data-eur="<?= number_format((float) $plan['price'], 2, '.', '') ?>"<?php foreach (array_keys(PERIOD_KEYS) as $per): if (plan_period_total($plan, $per) === null) continue; ?> data-eur-<?= $per ?>="<?= number_format(plan_month_price($plan, $per), 2, '.', '') ?>"<?php endforeach; ?>><?= h(price($plan['price'])) ?></span>
            <span class="per"><?= e('price.per') ?></span>
          </p>
          <p class="plan-note"><?= e('v4.offers.no_commit') ?></p>
          <p class="plan-billed"<?php foreach (['quarterly', 'semiannual', 'annual'] as $per): $tot = plan_period_total($plan, $per); if ($tot === null) continue; ?> data-tpl-<?= $per ?>="<?= h(t('price.billed_every', '{p}', t('price.every.' . $per))) ?>" data-tot-<?= $per ?>="<?= number_format($tot, 2, '.', '') ?>"<?php endforeach; ?> hidden></p>
          <ul class="plan-main">
            <?php foreach ($main as $sp): ?>
            <li><?= icon($specIcon[$sp[0]]) ?><span><?= h(spec($sp)) ?></span></li>
            <?php endforeach; ?>
          </ul>
          <?php if ($extra): ?>
          <ul class="plan-specs">
            <?php foreach ($extra as $sp): ?>
            <li><?= icon($sp[0] === 'ddos' ? 'shieldok' : 'check', 'tick') ?><span><?= h(spec($sp)) ?></span></li>
            <?php endforeach; ?>
          </ul>
          <?php endif; ?>
          <a class="btn <?= $pop ? 'btn-primary' : 'btn-ghost' ?> btn-block" href="<?= h(plan_url($plan['sku'])) ?>" data-order-link rel="nofollow noopener"><?= e('price.order') ?></a>
          <?php if ($trial && !empty($plan['sku'])): ?><a class="plan-trial" href="<?= h(trial_url((int) $plan['sku'])) ?>" rel="nofollow noopener"><?= icon('gift') ?><?= e('trial.plan_cta') ?></a><?php endif; ?>
        </article>
        <?php endforeach; ?>
      </div>
      <?php if (count($plans) > 4): ?>
      <button type="button" class="carousel-nav carousel-next" data-carousel-next aria-label="<?= e('a11y.carousel_next') ?>"><?= icon('arrow') ?></button>
      <?php endif; ?>
    </div>

  </div>
</section>

<?php if ($canMigrate): ?>
<section class="sec sec-tight" id="migration">
  <div class="wrap">
    <div class="mig-band">
      <div class="mig-band-txt">
        <p class="eyebrow"><?= e('mig.band.eyebrow') ?></p>
        <h2><?= e('mig.band.title') ?></h2>
        <p><?= e('mig.band.lead') ?></p>
      </div>
      <ol class="mig-band-steps">
        <?php for ($n = 1; $n <= 3; $n++): ?><li><b><?= $n ?></b><span><?= e('mig.band.s' . $n) ?></span></li><?php endfor; ?>
      </ol>
      <div class="mig-band-cta">
        <a class="btn btn-primary" href="<?= h(url('migration')) ?>"><?= icon('migrate') ?><?= e('mig.band.cta') ?></a>
        <small><?= e('mig.band.free') ?></small>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php require __DIR__ . '/../inc/ddos_section.php'; ?>

<?php require __DIR__ . '/../inc/product_seo.php'; ?>

<section class="sec">
  <div class="wrap">
    <header class="sec-head center">
      <h2><?= e('v4.why.title', $isGame ? t('v4.cta.server', $name) : $name) ?></h2>
    </header>
    <div class="cards-3">
      <?php for ($n = 1; $n <= 3; $n++): ?>
      <article class="card">
        <span class="card-ic"><?= icon($featIcons[$n - 1]) ?></span>
        <h3><?= e('feat.' . $featCat . '.' . $n . '.title') ?></h3>
        <p><?= e('feat.' . $featCat . '.' . $n . '.desc') ?></p>
      </article>
      <?php endfor; ?>
    </div>
  </div>
</section>

<?php if ($faqCount): ?>
<section class="sec">
  <div class="wrap faq2">
    <header class="faq2-head">
      <h2><?= e('home.faq.title') ?></h2>
      <p><?= e('v4.faq.lead', $name) ?></p>
      <a class="btn btn-ghost" href="<?= h(url('contact')) ?>"><?= e('v4.faq.contact') ?></a>
    </header>
    <div class="faq">
      <?php foreach ($faqItems as $n => [$q, $a]): ?>
      <details class="faq-item"<?= $n === 0 ? ' open' : '' ?>>
        <summary><?= h($q) ?><?= icon('chevron', 'chev') ?></summary>
        <div class="faq-a"><p><?= h($a) ?></p></div>
      </details>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php
// Guides du blog liés à l'offre : maillage interne des pages commerciales vers le contenu éditorial.
$guideKeys = [
    'minecraft' => ['dimensionner-serveur-minecraft', 'comprendre-anti-ddos'],
    'fivem' => ['heberger-serveur-fivem', 'comprendre-anti-ddos'],
    'redm' => ['heberger-serveur-fivem', 'comprendre-anti-ddos'],
    'bots' => ['heberger-bot-discord', 'vps-linux-ou-windows'],
    'vps-linux' => ['securiser-son-vps', 'vps-linux-ou-windows', 'vps-ou-mutualise'],
    'vps-kvm' => ['securiser-son-vps', 'decrypter-fiche-technique', 'vps-linux-ou-windows'],
    'vps-windows' => ['vps-linux-ou-windows', 'securiser-son-vps'],
    'vps-pterodactyl' => ['devenir-revendeur-hebergement', 'securiser-son-vps'],
    'reseller-vps' => ['devenir-revendeur-hebergement', 'decrypter-fiche-technique'],
    'web-reseller' => ['devenir-revendeur-hebergement', 'choisir-hebergeur-web'],
    'web-hosting' => ['choisir-hebergeur-web', 'vps-ou-mutualise', 'heberger-en-france'],
    'mail-pro' => ['comprendre-dns', 'heberger-en-france'],
    'ip-addon' => ['comprendre-dns', 'comprendre-anti-ddos'],
][$product] ?? ($isGame ? ['comprendre-anti-ddos', 'decrypter-fiche-technique'] : []);
$guides = array_values(array_filter(array_map(fn($k) => blog_post(lang(), $k), $guideKeys)));
?>
<?php if ($guides): ?>
<section class="sec">
  <div class="wrap">
    <header class="sec-head">
      <p class="eyebrow"><?= e('blog.title') ?></p>
      <h2><?= e('seo.guides.title') ?></h2>
    </header>
    <div class="cards-3">
      <?php foreach ($guides as $g): ?>
      <a class="card" href="<?= h(blog_url($g['slug'])) ?>">
        <h3><?= h($g['title']) ?></h3>
        <p><?= h($g['desc']) ?></p>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($related): ?>
<section class="sec">
  <div class="wrap">
    <header class="sec-head">
      <p class="eyebrow"><?= e('nav.services') ?></p>
      <h2><?= e('cat.' . $catPage . '.title') ?></h2>
    </header>
    <div class="cards-3">
      <?php foreach ($related as $rel): ?>
      <?php $relArt = game_art($rel); ?>
      <a class="card<?= $relArt ? ' card-media' : '' ?>" href="<?= h(url($rel)) ?>">
        <?php if ($relArt): ?><span class="game-art"><img src="<?= h($relArt) ?>" alt="<?= h(product_text($rel, 'name')) ?>" width="720" height="405" loading="lazy" decoding="async"></span><span class="card-body"><?php else: ?><span class="card-ic"><?= brand($rel, CATALOG[$rel]['icon']) ?></span><?php endif; ?>
        <h3><?= h(product_text($rel, 'name')) ?></h3>
        <p><?= h(product_text($rel, 'tagline')) ?></p>
        <span class="card-from"><?= e('cat.starting') ?> <b><?= money(product_from($rel)) ?></b> <?= e('price.per') ?></span>
        <?php if ($relArt): ?></span><?php endif; ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="sec">
  <div class="wrap">
    <div class="cta2">
      <div>
        <h2><?= e('v4.cta.title', $isGame ? t('v4.cta.server', $name) : $name) ?></h2>
        <p><?= e('v4.cta.lead') ?></p>
        <div class="cta-actions">
          <a class="btn btn-light btn-lg" href="#offres"><?= e('v4.cta.offers') ?></a>
          <a class="btn btn-outline-light btn-lg" href="<?= h(url('contact')) ?>"><?= e('v4.cta.contact') ?></a>
        </div>
      </div>
      <span class="cta2-mark" aria-hidden="true"><?= brand($product, $data['icon']) ?></span>
    </div>
  </div>
</section>

<?php
if ($faqCount) {
    echo jsonld([
        '@context'   => 'https://schema.org',
        '@type'      => 'FAQPage',
        'mainEntity' => array_map(fn($qa) => [
            '@type'          => 'Question',
            'name'           => $qa[0],
            'acceptedAnswer' => ['@type' => 'Answer', 'text' => $qa[1]],
        ], $faqItems),
    ]);
}
?>
<script type="application/ld+json">
<?= json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'Product',
    'name'     => product_text($product, 'title'),
    'description' => product_text($product, 'lead'),
    'brand'    => ['@type' => 'Brand', 'name' => SITE_NAME],
    'category' => t('cat.' . $catPage . '.title'),
    'image'    => SITE_URL . ($art ?: '/assets/img/og-image.png'),
    'url'      => SITE_URL . seo_path(lang()),
    'additionalProperty' => [
        ['@type' => 'PropertyValue', 'name' => 'CPU', 'value' => $cpu['model']],
        ['@type' => 'PropertyValue', 'name' => 'RAM', 'value' => INFRA['ram']],
        ['@type' => 'PropertyValue', 'name' => 'Storage', 'value' => INFRA['storage']],
        ['@type' => 'PropertyValue', 'name' => 'Anti-DDoS', 'value' => INFRA['ddos']['name'] . ' ' . INFRA['ddos']['capacity']],
        ['@type' => 'PropertyValue', 'name' => 'Location', 'value' => 'Paris, France'],
    ],
    'offers'   => [
        '@type'         => 'AggregateOffer',
        'priceCurrency' => 'EUR',
        'lowPrice'      => number_format($data['from'], 2, '.', ''),
        'highPrice'     => number_format(max(array_column($plans, 'price')), 2, '.', ''),
        'offerCount'    => count($plans),
        'availability'  => 'https://schema.org/InStock',
        'seller'        => ['@type' => 'Organization', 'name' => SITE_NAME],
        'offers'        => array_map(fn($plan) => [
            '@type'           => 'Offer',
            'name'            => $name . ' — ' . $plan['name'],
            'price'           => number_format($plan['price'], 2, '.', ''),
            'priceCurrency'   => 'EUR',
            'availability'    => 'https://schema.org/InStock',
            'url'             => SITE_URL . seo_path(lang()) . '#offres',
        ], $plans),
    ],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
</script>
