<?php
/** Page « Notre équipe » : qui nous sommes, l'équipe, l'infrastructure en photos. */
$people = [
    ['Nolhan L.', 'president'], ['Martin L.', 'vice'], ['Jérémy R.', 'ops'],
    ['Mael P.', 'supportlead'], ['Yase J.', 'supportops'], ['Edouard', 'support'],
];
$photos = ['baie-serveurs' => 1, 'serveur-ouvert' => 2, 'reseau-pare-feu' => 3, 'mise-en-baie' => 4, 'cablage' => 5];
$initials = fn(string $n) => mb_strtoupper(mb_substr($n, 0, 1) . (preg_match('/\s(\S)/u', $n, $m) ? $m[1] : ''));
?>
<section class="hero2 mig-hero">
  <div class="wrap hero2-inner">
    <span class="pill"><?= icon('users') ?><?= e('v4.team.eyebrow') ?></span>
    <h1 class="hero2-title"><?= e('v4.team.h1a') ?> <span><?= e('v4.team.h1b') ?></span></h1>
    <p class="hero2-lead"><?= e('v4.team.lead') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap team-story">
    <h2><?= e('v4.team.story_t') ?></h2>
    <p><?= e('v4.team.story') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <header class="sec-head center"><h2><?= e('v4.team.people') ?></h2></header>
    <ul class="team-grid">
      <?php foreach ($people as [$name, $role]): ?>
      <li><span class="team-av" aria-hidden="true"><?= h($initials($name)) ?></span><b><?= h($name) ?></b><span><?= e('v4.team.r.' . $role) ?></span></li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <header class="sec-head center"><h2><?= e('v4.team.infra_t') ?></h2><p class="sec-lead"><?= e('v4.team.infra_l') ?></p></header>
    <div class="infra-gallery">
      <?php foreach ($photos as $file => $n): ?>
      <figure>
        <img src="/assets/img/infra/<?= h($file) ?>.webp?v=<?= ASSET_VERSION ?>" alt="<?= e('v4.team.p' . $n) ?>" loading="lazy" decoding="async" width="600" height="800">
        <figcaption><?= e('v4.team.p' . $n) ?></figcaption>
      </figure>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <header class="sec-head center"><h2><?= e('v4.team.values_t') ?></h2></header>
    <div class="cards-3">
      <?php foreach ([1 => 'lock', 2 => 'chat', 3 => 'shieldok'] as $n => $ic): ?>
      <article class="card"><span class="card-ic"><?= icon($ic) ?></span><h3><?= e('v4.team.v' . $n) ?></h3><p><?= e('v4.team.v' . $n . 'd') ?></p></article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="cta2">
      <div>
        <h2><?= e('v4.team.cta') ?></h2>
        <p><?= e('v4.team.cta_l') ?></p>
        <div class="cta-actions">
          <a class="btn btn-light btn-lg" href="<?= h(url('contact')) ?>"><?= e('v4.cta.contact') ?></a>
          <a class="btn btn-outline-light btn-lg" href="<?= h(LINKS['discord']) ?>" rel="noopener">Discord</a>
        </div>
      </div>
      <span class="cta2-mark" aria-hidden="true"><?= icon('users') ?></span>
    </div>
  </div>
</section>

<?= jsonld(['@context' => 'https://schema.org', '@type' => 'AboutPage', 'name' => t('v4.team.title'), 'url' => SITE_URL . url('team'),
    'mainEntity' => ['@type' => 'Organization', 'name' => SITE_NAME, 'url' => SITE_URL, 'foundingDate' => '2026-04',
        'member' => array_map(fn($p) => ['@type' => 'OrganizationRole', 'roleName' => t('v4.team.r.' . $p[1]), 'member' => ['@type' => 'Person', 'name' => $p[0]]], $people)]]) ?>
