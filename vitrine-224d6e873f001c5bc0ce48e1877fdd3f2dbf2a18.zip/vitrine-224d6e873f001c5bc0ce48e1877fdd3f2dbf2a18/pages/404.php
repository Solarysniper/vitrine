<?php /** 404. */ ?>
<section class="page-head page-404">
  <div class="wrap wrap-narrow center">
    <p class="eyebrow">404</p>
    <h1><?= e('404.title') ?></h1>
    <p class="page-lead"><?= e('404.lead') ?></p>
    <div class="cta-actions center-actions">
      <a class="btn btn-primary btn-lg" href="<?= h(url('home')) ?>"><?= e('404.home') ?></a>
      <a class="btn btn-ghost btn-lg" href="<?= h(url('acces-rapide')) ?>"><?= e('404.quick') ?></a>
    </div>
  </div>
</section>
