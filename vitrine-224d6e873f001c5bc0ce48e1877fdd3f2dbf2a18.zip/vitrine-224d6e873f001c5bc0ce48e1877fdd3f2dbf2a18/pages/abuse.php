<?php /** Signalement de contenu illicite. */ ?>
<section class="page-hero">
  <div class="wrap">
    <h1><?= e('abuse.title') ?></h1>
    <p class="page-lead"><?= e('abuse.lead') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="cards-3">
      <?php foreach ([['shield', 'policy'], ['activity', 'process'], ['flag', 'legal']] as [$ic, $k]): ?>
      <article class="card">
        <span class="card-ic"><?= icon($ic) ?></span>
        <h2><?= e('abuse.' . $k . '.title') ?></h2>
        <p><?= e('abuse.' . $k . '.desc') ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap wrap-narrow">
    <header class="sec-head">
      <p class="eyebrow"><?= e('abuse.form.title') ?></p>
      <h2><?= e('abuse.title') ?></h2>
    </header>

    <form class="form card-form" id="abuse-form" novalidate data-msg-required="<?= e('contact.required') ?>" data-msg-sending="<?= e('contact.sending') ?>" data-msg-error="<?= e('contact.error') ?>">
      <div class="field-row">
        <div class="field">
          <label for="a-last"><?= e('abuse.lastname') ?> <span class="req">*</span></label>
          <input type="text" id="a-last" name="lastname" required autocomplete="family-name">
        </div>
        <div class="field">
          <label for="a-first"><?= e('abuse.firstname') ?> <span class="req">*</span></label>
          <input type="text" id="a-first" name="firstname" required autocomplete="given-name">
        </div>
      </div>
      <div class="field">
        <label for="a-email"><?= e('abuse.email') ?> <span class="req">*</span></label>
        <input type="email" id="a-email" name="email" required autocomplete="email">
      </div>

      <fieldset class="fieldset">
        <legend><?= e('abuse.targets') ?></legend>
        <div class="field-row">
          <div class="field">
            <label for="a-service"><?= e('abuse.service') ?></label>
            <input type="text" id="a-service" name="service">
          </div>
          <div class="field">
            <label for="a-ip"><?= e('abuse.ip') ?></label>
            <input type="text" id="a-ip" name="ip" inputmode="numeric">
          </div>
        </div>
        <div class="field">
          <label for="a-client"><?= e('abuse.client') ?></label>
          <input type="text" id="a-client" name="client">
        </div>
      </fieldset>

      <div class="field">
        <label for="a-type"><?= e('abuse.type') ?> <span class="req">*</span></label>
        <select id="a-type" name="type" required>
          <option value=""><?= e('abuse.type.pick') ?></option>
          <?php foreach (['phishing', 'malware', 'network', 'dmca', 'hate', 'other'] as $opt): ?>
          <option value="<?= h($opt) ?>"><?= e('abuse.type.' . $opt) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="a-url"><?= e('abuse.url') ?></label>
        <input type="url" id="a-url" name="url" placeholder="https://">
      </div>
      <div class="field">
        <label for="a-desc"><?= e('abuse.desc') ?> <span class="req">*</span></label>
        <textarea id="a-desc" name="description" rows="6" required></textarea>
      </div>
      <div class="field">
        <label for="a-notes"><?= e('abuse.notes') ?></label>
        <textarea id="a-notes" name="notes" rows="3"></textarea>
      </div>
      <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <button type="submit" class="btn btn-primary btn-block btn-lg"><?= e('abuse.send') ?></button>
      <p class="form-msg" data-form-msg role="status"></p>
    </form>
  </div>
</section>

<div class="form-done" id="abuse-done" hidden>
  <div class="done-card">
    <span class="done-ic"><?= icon('check') ?></span>
    <h2><?= e('abuse.sent') ?></h2>
    <p><?= e('abuse.sent_desc') ?></p>
    <a class="btn btn-ghost" href="<?= h(url('home')) ?>"><?= e('404.home') ?></a>
  </div>
</div>
