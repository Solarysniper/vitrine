<?php
/**
 * Accueil.
 *
 * Disposition : titre + fiche infrastructure → recherche de domaine →
 * bannières des jeux → autres services (onglets VPS / web / revente) →
 * offres vedettes → atouts → conseiller IA → avis → FAQ → appel à l'action.
 *
 * Tout le contenu produit vient du catalogue : ajouter une offre dans
 * inc/config.php la fait apparaître ici sans toucher à ce fichier.
 */

// Jeux mis en avant : les plus demandés d'abord ; les autres sont résumés
// dans la dernière carte, pour que la grille tombe toujours juste (12).
$allGames = array_keys(array_filter(CATALOG, fn($p) => $p['category'] === 'game'));
$order    = ['minecraft', 'fivem', 'rust', 'ark', 'palworld', 'garrys-mod', 'cs2', 'redm', 'seven-days', 'hytale', 'ets2', 'beammp', 'nova-life'];
$rank = fn($k) => ($i = array_search($k, $order, true)) === false ? 99 : $i;
usort($allGames, fn($a, $b) => $rank($a) <=> $rank($b));
$games    = array_slice($allGames, 0, 11);
$moreGames = array_map(fn($k) => product_text($k, 'name'), array_slice($allGames, 11));
if (isset(CATALOG['bots'])) $moreGames[] = product_text('bots', 'name');

$tabs = [
    'vps'        => ['icon' => 'server',  'label' => t('nav.vps')],
    'web'        => ['icon' => 'globe',   'label' => t('menu.web.title')],
    'revendeurs' => ['icon' => 'feather', 'label' => t('nav.revendeurs')],
];

// Offres mises en avant : [produit, index de l'offre, mise en avant]
$featured = [
    ['web-hosting', 0, false],
    ['vps-linux',   1, true],
    ['minecraft',   1, false],
];

$stack = ['WordPress', 'Plesk', 'Pterodactyl', 'Debian', 'Ubuntu', 'Windows Server', 'Docker', 'Node.js', 'Python', 'Intel Xeon Gold', 'DDR4 ECC', 'NVMe Entreprise'];

// Avis : les vrais avis publiés dans l'espace client (synchronisés avec le catalogue), jamais d'avis écrits à la main.
$allReviews = catalog_sync_data()['reviews'] ?? [];
$reviewAvg = $allReviews ? round(array_sum(array_column($allReviews, 'rating')) / count($allReviews), 1) : null;
$reviews = array_slice(array_values(array_filter($allReviews, fn($r) => $r['rating'] >= 4 && mb_strlen($r['text'] ?: $r['title']) >= 20)), 0, 3);

$facts = [
    ['dc', 'dc_v'], ['cpu', 'cpu_v'], ['disk', 'disk_v'],
    ['ddos', 'ddos_v'], ['support', 'support_v'], ['commit', 'commit_v'],
];
?>

<?php
// Mur de bannières des jeux en fond du titre (lignes qui défilent lentement ; immobiles si l'utilisateur
// demande moins d'animations). Seulement les jeux publiés du catalogue.
// Vignettes légères (assets/img/games/wall/, 400 px, ~8 Ko) : le mur n'affiche que des images floutées par le dégradé.
$wallArt = fn($k) => is_readable(__DIR__ . '/../assets/img/games/wall/' . $k . '.webp') ? '/assets/img/games/wall/' . rawurlencode($k) . '.webp?v=' . ASSET_VERSION : game_art($k);
$wall = array_values(array_filter(array_map(fn($k) => game_art($k) ? [$k, $wallArt($k)] : null, $allGames)));
$rows = [[], [], []];
foreach ($wall as $i => $w) $rows[$i % 3][] = $w;
?>
<section class="hero2">
  <div class="hero2-wall" aria-hidden="true" data-hero-wall>
    <?php foreach ($rows as $r => $row): if (!$row) continue; while (count($row) < 6) $row = array_merge($row, $row); ?>
    <div class="hero2-row hero2-row-<?= $r ?>">
      <?php foreach (array_merge($row, $row) as [$k, $src]): ?><img src="<?= h($src) ?>" alt="" width="400" height="225" decoding="async"><?php endforeach; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="wrap hero2-inner">
    <span class="pill"><?= icon('flag') ?><?= e('hero.badge') ?></span>
    <h1 class="hero2-title"><?= e('v2.hero.title_a') ?> <span><?= e('v2.hero.title_b') ?></span></h1>
    <p class="hero2-lead"><?= e('hero.lead') ?></p>
    <div class="hero2-cta">
      <a class="btn btn-primary btn-lg" href="#offres"><?= icon('gamepad') ?><?= e('v2.hero.cta_games') ?></a>
      <a class="btn btn-ghost btn-lg" href="#services"><?= e('v2.hero.cta_offers') ?></a>
    </div>
    <ul class="hero-micro">
      <li class="is-trial"><?= icon('gift') ?><?= e('trial.micro') ?></li>
      <li><?= icon('check') ?><?= e('hero.micro.1') ?></li>
      <li><?= icon('check') ?><?= e('hero.micro.2') ?></li>
      <li><?= icon('check') ?><?= e('hero.micro.3') ?></li>
    </ul>
  </div>
  <div class="wrap">
    <dl class="statband hero2-stats">
      <div><dt><?= h(INFRA['ddos']['capacity']) ?></dt><dd><?= e('v4.stat.ddos') ?></dd></div>
      <div><dt><?= h(infra_ghz(INFRA['cpu_game']['ghz'])) ?></dt><dd><?= e('v4.stat.cpu', 'Intel Xeon Gold') ?></dd></div>
      <div><dt><?= e('v4.stat.nvme_v') ?></dt><dd><?= e('v4.stat.nvme') ?></dd></div>
      <div><dt><?= e('v4.stat.paris_v') ?></dt><dd><?= e('v4.stat.paris') ?></dd></div>
    </dl>
  </div>
</section>

<section class="sec sec-tight">
  <div class="wrap">
    <div class="trial-band">
      <span class="trial-band-ic" aria-hidden="true"><?= icon('gift') ?></span>
      <div class="trial-band-txt">
        <p class="eyebrow"><?= e('trial.home.eyebrow') ?></p>
        <h2><?= e('trial.home.title') ?></h2>
        <p><?= e('trial.home.lead') ?></p>
        <ul class="trial-points">
          <?php for ($n = 1; $n <= 3; $n++): ?><li><?= icon('check') ?><?= e('trial.home.p' . $n) ?></li><?php endfor; ?>
        </ul>
      </div>
      <div class="trial-band-cta">
        <a class="btn btn-trial btn-lg" href="<?= h(url('games')) ?>"><?= icon('gamepad') ?><?= e('trial.home.cta') ?></a>
        <a class="btn-link" href="#services"><?= e('trial.home.cta2') ?> <span aria-hidden="true">›</span></a>
      </div>
    </div>
  </div>
</section>

<section class="sec sec-tight">
  <div class="wrap wrap-narrow">
    <?php $domainTitle = true; require __DIR__ . '/../inc/domain_search_bar.php'; ?>
  </div>
</section>

<section class="sec" id="offres">
  <div class="wrap">
    <div class="sec-head-row">
      <header class="sec-head">
        <p class="eyebrow"><?= e('v2.games.eyebrow') ?></p>
        <h2><?= e('v2.games.title') ?></h2>
        <p class="sec-lead"><?= e('v2.games.lead', count($allGames)) ?></p>
      </header>
      <a class="link-btn" href="<?= h(url('games')) ?>"><?= e('v2.games.all') ?><?= icon('arrow') ?></a>
    </div>

    <div class="games">
      <?php foreach ($games as $key): $art = game_art($key); ?>
      <a class="game" href="<?= h(url($key)) ?>">
        <span class="game-art">
          <?php if ($art): ?><img src="<?= h($art) ?>" alt="<?= h(product_text($key, 'name')) ?>" width="720" height="405" loading="lazy" decoding="async"><?php endif; ?>
          <?php if (has_free_trial($key, 0)): ?><span class="game-tag"><?= e('price.trial') ?></span><?php endif; ?>
        </span>
        <span class="game-body">
          <span class="game-logo"><?= brand($key, CATALOG[$key]['icon']) ?></span>
          <span class="game-txt">
            <strong><?= h(product_text($key, 'name')) ?></strong>
            <span><?= e('v2.from') ?> <b><?= money(product_from($key)) ?></b><?= e('v2.month') ?></span>
          </span>
          <?= icon('arrow', 'game-go') ?>
        </span>
      </a>
      <?php endforeach; ?>
      <a class="game game-more" href="<?= h(url('games')) ?>">
        <strong><?= e('v2.games.all') ?></strong>
        <p><?= h(implode(', ', $moreGames)) ?>…</p>
        <span class="link-btn"><?= e('v2.games.see', count($allGames)) ?><?= icon('arrow') ?></span>
      </a>
    </div>
  </div>
</section>

<section class="sec" id="services">
  <div class="wrap">
    <header class="sec-head">
      <p class="eyebrow"><?= e('v2.others.eyebrow') ?></p>
      <h2><?= e('v2.others.title') ?></h2>
      <p class="sec-lead"><?= e('home.explore.lead') ?></p>
    </header>

    <div class="tabs" data-tabs role="tablist">
      <?php foreach ($tabs as $key => $tab): ?>
      <button type="button" role="tab" data-tab="<?= h($key) ?>"<?= $key === 'vps' ? ' class="is-active" aria-selected="true"' : ' aria-selected="false"' ?>>
        <?= icon($tab['icon']) ?><?= h($tab['label']) ?>
      </button>
      <?php endforeach; ?>
    </div>

    <div class="tab-stack">
    <?php foreach ($tabs as $key => $tab):
        $items = array_map('menu_item', mega_menu()[$key]['items'] ?? []); ?>
    <div class="tab-panel" data-panel="<?= h($key) ?>" role="tabpanel"<?= $key === 'vps' ? '' : ' hidden' ?>>
      <div class="tiles">
        <?php foreach ($items as $item): ?>
        <a class="tile<?= $item['soon'] ? ' is-soon' : '' ?>" href="<?= h($item['href']) ?>">
          <span class="tile-ic"><?= $item['key'] ? brand($item['key'], $item['icon']) : icon($item['icon']) ?></span>
          <span class="tile-txt">
            <strong><?= h($item['label']) ?><?php if ($item['soon']): ?><em class="badge"><?= e('soon.badge') ?></em><?php endif; ?></strong>
            <span><?= h($item['desc']) ?></span>
          </span>
          <?php if ($item['from']): ?><span class="tile-price"><?= money((float) $item['from']) ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="sec" id="pricing">
  <div class="wrap">
    <header class="sec-head is-center">
      <p class="eyebrow"><?= e('home.pricing.eyebrow') ?></p>
      <h2><?= e('home.pricing.title') ?></h2>
      <p class="sec-lead"><?= e('home.pricing.lead') ?></p>
    </header>

    <div class="billing">
      <div class="toggle" data-billing role="group">
        <button type="button" class="is-active" data-period="monthly"><?= e('price.monthly') ?></button>
        <button type="button" data-period="quarterly"><?= e('price.quarterly') ?><em>-<?= billing_discount_pct('quarterly') ?>%</em></button>
        <button type="button" data-period="semiannual"><?= e('price.semiannual') ?><em>-<?= billing_discount_pct('semiannual') ?>%</em></button>
        <button type="button" data-period="annual"><?= e('price.annual') ?><em>-<?= billing_discount_pct('annual') ?>%</em></button>
      </div>
      <span class="billing-note"><?= e('price.ttc') ?></span>
    </div>

    <div class="plans">
      <?php foreach ($featured as [$prodKey, $idx, $pop]):
          $plan = CATALOG[$prodKey]['plans'][$idx]; $trial = has_free_trial($prodKey, $idx); ?>
      <article class="plan<?= $pop ? ' is-popular' : '' ?>">
        <?php if ($pop): ?><span class="plan-tag"><?= e('price.popular') ?></span>
        <?php elseif ($trial): ?><span class="plan-tag plan-tag-trial"><?= e('price.trial') ?></span>
        <?php endif; ?>
        <p class="plan-cat"><?= h(product_text($prodKey, 'name')) ?></p>
        <h3 class="plan-name"><?= h($plan['name']) ?></h3>
        <p class="plan-price">
          <span class="amount" data-eur="<?= number_format((float) $plan['price'], 2, '.', '') ?>"<?php foreach (array_keys(PERIOD_KEYS) as $per): if (plan_period_total($plan, $per) === null) continue; ?> data-eur-<?= $per ?>="<?= number_format(plan_month_price($plan, $per), 2, '.', '') ?>"<?php endforeach; ?>><?= h(price($plan['price'])) ?></span>
          <span class="per"><?= e('price.per') ?></span>
        </p>
        <ul class="plan-specs">
          <?php foreach (array_slice($plan['specs'], 0, 5) as $sp): ?>
          <li><?= icon('check', 'tick') ?><span><?= h(spec($sp)) ?></span></li>
          <?php endforeach; ?>
        </ul>
        <a class="btn <?= $pop ? 'btn-primary' : 'btn-ghost' ?> btn-block" href="<?= h(plan_url($plan['sku'])) ?>" rel="noopener"><?= e('price.order') ?></a>
        <?php if ($trial && !empty($plan['sku'])): ?><a class="plan-trial" href="<?= h(trial_url((int) $plan['sku'])) ?>" rel="nofollow noopener"><?= icon('gift') ?><?= e('trial.plan_cta') ?></a><?php endif; ?>
        <a class="link-btn" href="<?= h(url($prodKey)) ?>"><?= e('cat.discover') ?></a>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <header class="sec-head is-center">
      <p class="eyebrow"><?= e('home.why.eyebrow') ?></p>
      <h2><?= e('home.why.title') ?></h2>
    </header>

    <div class="bento">
      <?php foreach ([[6, 'flag'], [1, 'shield'], [2, 'chat'], [3, 'chart'], [4, 'bolt'], [5, 'terminal']] as [$n, $ic]): ?>
      <article>
        <span class="card-ic"><?= icon($ic) ?></span>
        <h3><?= e('why.' . $n . '.title') ?></h3>
        <p><?= e('why.' . $n . '.desc') ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php $hwBoth = true; require __DIR__ . '/../inc/ddos_section.php'; require __DIR__ . '/../inc/hw_section.php'; ?>

<?php if (chat_enabled()): ?>
<section class="sec">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('v2.ai.title') ?></h2>
        <p><?= e('v2.ai.lead') ?></p>
      </div>
      <div class="cta-actions">
        <button type="button" class="btn btn-primary btn-lg" data-chat-open><?= icon('chat') ?><?= e('v2.ai.cta') ?></button>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($reviews): ?>
<section class="sec">
  <div class="wrap">
    <header class="sec-head is-center">
      <p class="eyebrow"><?= e('home.testi.eyebrow') ?></p>
      <h2><?= e('home.testi.title') ?></h2>
      <p class="sec-lead"><?= e('v3.reviews.avg', number_format((float) $reviewAvg, 1, lang() === 'en' ? '.' : ',', ''), count($allReviews)) ?></p>
    </header>
    <div class="quotes">
      <?php foreach ($reviews as $r): $initials = mb_strtoupper(implode('', array_map(fn($w) => mb_substr($w, 0, 1), array_slice(preg_split('/\s+/', trim($r['name'])) ?: ['C'], 0, 2)))); ?>
      <figure class="quote">
        <div class="stars" aria-label="<?= (int) $r['rating'] ?>/5">
          <?php for ($s = 0; $s < 5; $s++): ?><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"<?= $s >= $r['rating'] ? ' class="star-off"' : '' ?>><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4.5L6 21l1.5-7.5L2 9h7z"/></svg><?php endfor; ?>
        </div>
        <?php if ($r['title'] !== ''): ?><p class="quote-title"><?= h(mb_strimwidth($r['title'], 0, 64, '…')) ?></p><?php endif; ?>
        <blockquote><?= h($r['text'] !== '' ? $r['text'] : $r['title']) ?></blockquote>
        <figcaption class="quote-who">
          <span class="avatar"><?= h($initials) ?></span>
          <span><strong><?= h($r['name']) ?></strong><em><?= e('v3.reviews.verified') ?></em></span>
        </figcaption>
      </figure>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="sec" id="faq">
  <div class="wrap wrap-narrow">
    <header class="sec-head is-center">
      <p class="eyebrow"><?= e('home.faq.eyebrow') ?></p>
      <h2><?= e('home.faq.title') ?></h2>
    </header>
    <div class="faq">
      <?php for ($n = 1; $n <= 6; $n++): ?>
      <details class="faq-item"<?= $n === 1 ? ' open' : '' ?>>
        <summary><?= e('faq.home.' . $n . '.q') ?><?= icon('chevron', 'chev') ?></summary>
        <div class="faq-a"><p><?= e('faq.home.' . $n . '.a') ?></p></div>
      </details>
      <?php endfor; ?>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('home.cta.title') ?></h2>
        <p><?= e('home.cta.lead') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary btn-lg" href="<?= h(url('home')) ?>#offres"><?= e('v3.cta.offers') ?></a>
        <a class="btn btn-ghost btn-lg" href="<?= h(url('contact')) ?>"><?= e('home.cta.2') ?></a>
      </div>
    </div>
  </div>
</section>

<?= jsonld([
    '@context'   => 'https://schema.org',
    '@type'      => 'FAQPage',
    'mainEntity' => array_map(fn($n) => [
        '@type'          => 'Question',
        'name'           => t('faq.home.' . $n . '.q'),
        'acceptedAnswer' => ['@type' => 'Answer', 'text' => t('faq.home.' . $n . '.a')],
    ], range(1, 6)),
]) ?>
