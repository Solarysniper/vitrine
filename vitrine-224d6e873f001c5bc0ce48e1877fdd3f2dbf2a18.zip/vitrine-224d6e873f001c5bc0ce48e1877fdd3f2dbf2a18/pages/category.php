<?php
/**
 * Page catégorie.
 *  · Jeux : grille de jeux avec recherche et filtre par genre.
 *  · VPS, Web, Revendeurs : chaque produit avec ses offres en lignes (caractéristiques, prix, commande).
 */

$block   = mega_menu()[$category] ?? ['items' => []];
$items   = array_map('menu_item', $block['items']);
$live    = array_values(array_filter($items, fn($i) => !$i['soon']));
$pending = array_filter($items, fn($i) => $i['soon']);
$featCat = ['games' => 'game', 'vps' => 'vps', 'web' => 'web', 'revendeurs' => 'reseller'][$category];
$isGames = $category === 'games';
$genres  = [];
if ($isGames) {
    foreach ($live as $it) {
        $sub = $it['key'] ? (CATALOG[$it['key']]['subcategory'] ?? '') : '';
        if ($sub !== '') $genres[$sub] = ($genres[$sub] ?? 0) + 1;
    }
    $genres = array_intersect_key(array_merge(array_fill_keys(array_keys(GAME_SUBCATS), 0), $genres), $genres);
}
?>

<section class="page-head">
  <div class="wrap">
    <h1><?= e(has('seo.cat.' . $category . '.h1') ? 'seo.cat.' . $category . '.h1' : 'cat.' . $category . '.title') ?></h1>
    <p class="page-lead"><?= e('cat.' . $category . '.lead') ?></p>
  </div>
</section>

<?php if ($isGames): ?>
<section class="sec sec-first" id="offres">
  <div class="wrap">
    <div class="cat-tools">
      <label class="cat-search"><?= icon('search') ?><input type="search" placeholder="<?= e('v3.cat.search') ?>" aria-label="<?= e('v3.cat.search') ?>" data-game-q autocomplete="off"></label>
      <div class="chips" role="group" aria-label="<?= e('v3.cat.genres') ?>" data-game-genres>
        <button type="button" class="chip is-active" data-genre=""><?= e('v3.cat.all') ?> <em><?= count($live) ?></em></button>
        <?php foreach ($genres as $g => $n): ?>
        <button type="button" class="chip" data-genre="<?= h($g) ?>"><?= e('subcat.' . $g) ?> <em><?= (int) $n ?></em></button>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="games-grid" data-games>
      <?php foreach ($live as $it): $art = $it['key'] ? game_art($it['key']) : null; $sub = $it['key'] ? (CATALOG[$it['key']]['subcategory'] ?? '') : ''; ?>
      <a class="game-card" href="<?= h($it['href']) ?>" data-genre="<?= h($sub) ?>" data-name="<?= h(mb_strtolower($it['label'] . ' ' . $it['desc'])) ?>">
        <span class="game-art<?= $art ? '' : ' is-empty' ?>"><?php if ($art): ?><img src="<?= h($art) ?>" alt="" width="720" height="405" loading="lazy" decoding="async"><?php else: ?><span class="game-art-logo"><?= $it['key'] ? brand($it['key'], $it['icon']) : icon($it['icon']) ?></span><?php endif; ?></span>
        <span class="game-card-body">
          <b><?= h($it['label']) ?></b>
          <?php if ($it['from']): ?><small><?= e('cat.starting') ?> <strong><?= money((float) $it['from']) ?></strong> <?= e('price.per') ?></small><?php endif; ?>
        </span>
      </a>
      <?php endforeach; ?>
    </div>
    <p class="cat-empty" data-games-empty hidden><?= e('v3.cat.none') ?></p>
  </div>
</section>
<?php else: ?>
<section class="sec sec-first" id="offres">
  <div class="wrap prod-blocks">
<?php foreach ($live as $it): if (!$it['key']) continue; $prod = CATALOG[$it['key']]; ?>
    <div class="prod-block">
      <header class="prod-block-head">
        <span class="prod-block-ic"><?= brand($it['key'], $prod['icon']) ?></span>
        <div>
          <h2><a href="<?= h($it['href']) ?>"><?= h($it['label']) ?></a></h2>
          <p><?= h($it['desc']) ?></p>
        </div>
        <a class="link-btn" href="<?= h($it['href']) ?>"><?= e('v3.cat.details') ?><?= icon('arrow') ?></a>
      </header>
      <div class="plan-rows">
        <?php foreach ($prod['plans'] as $plan): $pop = !empty($plan['popular']); ?>
        <div class="plan-row<?= $pop ? ' is-popular' : '' ?>">
          <span class="plan-row-name"><b><?= h($plan['name']) ?></b><?php if ($pop): ?><em class="badge badge-brand"><?= e('price.popular') ?></em><?php endif; ?></span>
          <span class="plan-row-specs"><?= h(implode(' · ', array_map('spec_short', array_slice(array_values(array_filter($plan['specs'], fn($s) => !in_array($s[0], ['ddos', 'geo', 'panel', 'ddosssl', 'webmail', 'mailsec'], true))), 0, 4)))) ?></span>
          <span class="plan-row-price"><b><?= money((float) $plan['price']) ?></b><small><?= e('price.per') ?></small></span>
          <?php if (!empty($plan['sku'])): ?>
          <a class="btn btn-sm <?= $pop ? 'btn-primary' : 'btn-ghost' ?>" href="<?= h(plan_url((int) $plan['sku'])) ?>" rel="nofollow noopener"><?= e('price.order') ?></a>
          <?php else: ?>
          <a class="btn btn-sm btn-ghost" href="<?= h($it['href']) ?>"><?= e('v3.cat.details') ?></a>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
<?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="sec">
  <div class="wrap">
    <div class="cards-3">
      <?php for ($n = 1; $n <= 3; $n++): ?>
      <article class="card card-flat">
        <span class="card-ic"><?= icon(['shield', 'bolt', 'chat'][$n - 1]) ?></span>
        <h2><?= e('feat.' . $featCat . '.' . $n . '.title') ?></h2>
        <p><?= e('feat.' . $featCat . '.' . $n . '.desc') ?></p>
      </article>
      <?php endfor; ?>
    </div>
  </div>
</section>

<?php if (has('seo.cat.' . $category . '.body')): ?>
<section class="sec">
  <div class="wrap wrap-narrow prose-block">
    <h2><?= e('seo.cat.' . $category . '.h2') ?></h2>
    <?php foreach (preg_split('/\n\s*\n/', t('seo.cat.' . $category . '.body')) as $para): ?>
    <p><?= h(trim($para)) ?></p>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if ($pending): ?>
<section class="sec">
  <div class="wrap">
    <header class="sec-head">
      <h2><?= e('cat.soon.title') ?></h2>
      <p class="sec-lead"><?= e('cat.soon.lead') ?></p>
    </header>
    <div class="cards-3">
      <?php foreach ($pending as $it): ?>
      <a class="card card-soon" href="<?= h($it['href']) ?>">
        <span class="card-ic"><?= $it['key'] ? brand($it['key'], $it['icon']) : icon($it['icon']) ?></span>
        <h3><?= h($it['label']) ?><em class="badge"><?= e('soon.badge') ?></em></h3>
        <p><?= h($it['desc']) ?></p>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="sec cta-band">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('home.cta.title') ?></h2>
        <p><?= e('home.cta.lead') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary btn-lg" href="#offres"><?= e('v3.cta.offers') ?></a>
        <a class="btn btn-ghost btn-lg" href="<?= h(url('contact')) ?>"><?= e('home.cta.2') ?></a>
      </div>
    </div>
  </div>
</section>
