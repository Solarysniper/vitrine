<?php
/** Catégorie de documentation : tous les guides de la rubrique. */

$articles   = content_list('docs', lang(), $docCat);
$categories = doc_categories(lang());

// Offre liée à la rubrique : un lecteur qui cherche « se connecter en SSH »
// est souvent à un pas de commander un VPS.
$relatedProduct = [
    'pterodactyl' => 'minecraft',
    'jeux'        => 'minecraft',
    'plesk'       => 'web-hosting',
    'vps-linux'   => 'vps-linux',
    'vps-windows' => 'vps-windows',
    'mail'        => 'mail-pro',
    'domaines'    => null,
][$docCat] ?? null;
?>

<section class="page-hero">
  <div class="wrap">
    <span class="page-hero-logo"><?= brand($docCat, DOC_CATEGORIES[$docCat]['icon'], 'page-hero-logo-img', true) ?></span>
    <h1><?= e('docs.cat.' . $docCat . '.title') ?></h1>
    <p class="page-lead"><?= e('docs.cat.' . $docCat . '.desc') ?></p>
    <p class="page-from"><?= e('docs.count', count($articles)) ?></p>
  </div>
</section>

<section class="sec sec-tight">
  <div class="wrap">
    <div class="docs-layout">
      <aside class="docs-side">
        <p class="docs-side-title"><?= e('docs.title') ?></p>
        <ul class="docs-side-nav">
          <?php foreach ($categories as $key => $cat): ?>
          <li>
            <a href="<?= h(doc_url($key)) ?>"<?= $key === $docCat ? ' class="is-current" aria-current="page"' : '' ?>>
              <?= brand($key, $cat['icon']) ?><span><?= e('docs.cat.' . $key . '.title') ?></span><em><?= (int) $cat['count'] ?></em>
            </a>
          </li>
          <?php endforeach; ?>
        </ul>
      </aside>

      <div class="docs-main">
        <ol class="docs-index">
          <?php foreach ($articles as $article): ?>
          <li>
            <a href="<?= h(doc_url($docCat, $article['slug'])) ?>">
              <span class="docs-index-txt">
                <strong><?= h($article['title']) ?></strong>
                <span><?= h($article['desc']) ?></span>
              </span>
              <?= icon('arrow', 'docs-index-go') ?>
            </a>
          </li>
          <?php endforeach; ?>
        </ol>

        <?php if ($relatedProduct && isset(CATALOG[$relatedProduct])): ?>
        <aside class="docs-promo">
          <span class="card-ic"><?= brand($relatedProduct, CATALOG[$relatedProduct]['icon']) ?></span>
          <div>
            <p class="eyebrow"><?= e('docs.related_product') ?></p>
            <h2><?= h(product_text($relatedProduct, 'title')) ?></h2>
            <p><?= h(product_text($relatedProduct, 'tagline')) ?></p>
          </div>
          <a class="btn btn-primary" href="<?= h(url($relatedProduct)) ?>">
            <?= e('cat.starting') ?> <?= money(product_from($relatedProduct)) ?>
          </a>
        </aside>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
