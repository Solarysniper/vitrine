<?php
/** Accueil de la documentation : toutes les rubriques, avec recherche locale. */

$categories = doc_categories(lang());
$total      = doc_total(lang());

// Les guides les plus utiles à quelqu'un qui arrive sans savoir où chercher.
$popular = [];
foreach ([['espace-client', 'creer-un-compte'], ['pterodactyl', 'se-connecter-au-panel'],
          ['plesk', 'installer-wordpress'], ['vps-linux', 'se-connecter-en-ssh'],
          ['vps-windows', 'se-connecter-en-rdp'], ['espace-client', 'ouvrir-un-ticket-support']] as [$cat, $key]) {
    $list = content_list('docs', lang(), $cat);
    if (isset($list[$key])) $popular[] = ['cat' => $cat, 'article' => $list[$key]];
}
?>

<section class="page-hero page-hero-center">
  <div class="wrap">
    <p class="eyebrow"><?= e('docs.eyebrow') ?></p>
    <h1><?= e('docs.title') ?></h1>
    <p class="page-lead"><?= e('docs.lead') ?></p>

    <form class="docs-search" role="search" data-docs-search>
      <span class="docs-search-ic"><?= icon('search') ?></span>
      <input type="search" placeholder="<?= e('docs.search') ?>" aria-label="<?= e('docs.search') ?>" autocomplete="off">
    </form>
    <p class="docs-count"><?= e('docs.count', $total) ?></p>
  </div>
</section>

<section class="sec sec-tight">
  <div class="wrap">
    <div class="docs-grid" data-docs-list>
      <?php foreach ($categories as $key => $cat): ?>
      <article class="docs-card" data-docs-group>
        <header class="docs-card-head">
          <span class="card-ic"><?= brand($key, $cat['icon']) ?></span>
          <div>
            <h2><a href="<?= h(doc_url($key)) ?>"><?= e('docs.cat.' . $key . '.title') ?></a></h2>
            <p><?= e('docs.cat.' . $key . '.desc') ?></p>
          </div>
          <span class="docs-card-count"><?= (int) $cat['count'] ?></span>
        </header>
        <ul class="docs-card-list">
          <?php foreach (array_slice($cat['articles'], 0, 5) as $article): ?>
          <li data-docs-item data-title="<?= h(mb_strtolower($article['title'] . ' ' . $article['desc'])) ?>">
            <a href="<?= h(doc_url($key, $article['slug'])) ?>"><?= icon('arrow', 'docs-arrow') ?><span><?= h($article['title']) ?></span></a>
          </li>
          <?php endforeach; ?>
        </ul>
        <?php if ($cat['count'] > 5): ?>
        <a class="docs-card-all" href="<?= h(doc_url($key)) ?>"><?= e('docs.all') ?><?= icon('arrow') ?></a>
        <?php endif; ?>
      </article>
      <?php endforeach; ?>
    </div>
    <p class="docs-empty" data-docs-empty hidden><?= e('docs.search_empty') ?></p>
  </div>
</section>

<?php if ($popular): ?>
<section class="sec">
  <div class="wrap">
    <header class="sec-head is-center">
      <p class="eyebrow"><?= e('docs.popular') ?></p>
      <h2><?= e('docs.popular') ?></h2>
    </header>
    <div class="cards-3">
      <?php foreach ($popular as $p): ?>
      <a class="card card-lift" href="<?= h(doc_url($p['cat'], $p['article']['slug'])) ?>">
        <span class="card-ic"><?= brand($p['cat'], DOC_CATEGORIES[$p['cat']]['icon']) ?></span>
        <h3><?= h($p['article']['title']) ?></h3>
        <p><?= h($p['article']['desc']) ?></p>
        <span class="card-from"><?= e('docs.cat.' . $p['cat'] . '.title') ?></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="sec cta-band">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('docs.help.title') ?></h2>
        <p><?= e('docs.help.lead') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary btn-lg" href="<?= h(LINKS['support']) ?>" rel="noopener"><?= e('footer.ticket') ?></a>
        <a class="btn btn-ghost btn-lg" href="<?= h(LINKS['discord']) ?>" rel="noopener">Discord</a>
      </div>
    </div>
  </div>
</section>
