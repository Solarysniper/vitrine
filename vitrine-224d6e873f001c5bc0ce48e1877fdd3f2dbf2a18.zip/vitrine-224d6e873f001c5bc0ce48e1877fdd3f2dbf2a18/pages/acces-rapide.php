<?php
/** Page « Accès rapide » : tous les points d'entrée Artaun. */
?>
<section class="page-hero">
  <div class="wrap">
    <h1><?= e('qa.title') ?></h1>
    <p class="page-lead"><?= e('qa.lead') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="qa-grid">
      <?php foreach (QUICK_ACCESS as $tile):
          $href = $tile['url'] ?? url('status');
          $ext  = (bool) $tile['url']; ?>
      <a class="qa-tile<?= !empty($tile['primary']) ? ' is-primary' : '' ?>" href="<?= h($href) ?>"<?= $ext ? ' rel="noopener"' : '' ?>>
        <span class="qa-ic"><?= icon($tile['icon']) ?></span>
        <span class="qa-txt">
          <strong><?= e('qa.' . $tile['key'] . '.title') ?></strong>
          <span><?= e('qa.' . $tile['key'] . '.desc') ?></span>
        </span>
        <span class="qa-go"><?= e('qa.open') ?><?= icon($ext ? 'external' : 'arrow') ?></span>
      </a>
      <?php endforeach; ?>
    </div>

    <div class="qa-help">
      <div>
        <h2><?= e('qa.help.title') ?></h2>
        <p><?= e('qa.help.desc') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary" href="<?= h(url('contact')) ?>"><?= e('nav.contact') ?></a>
        <a class="btn btn-ghost" href="<?= h(LINKS['discord']) ?>" rel="noopener">Discord</a>
      </div>
    </div>
  </div>
</section>
