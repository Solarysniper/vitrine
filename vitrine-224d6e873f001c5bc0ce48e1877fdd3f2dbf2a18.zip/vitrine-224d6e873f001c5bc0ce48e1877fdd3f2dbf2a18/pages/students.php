<?php
/** Offres Étudiants — packs à finaliser dans inc/config.php (STUDENT_PACKS). */
?>

<section class="page-hero page-hero-center">
  <div class="wrap">
    <h1><?= e('students.title') ?></h1>
    <p class="page-lead"><?= e('students.lead') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="plans">
      <?php foreach (STUDENT_PACKS as $i => $pack): $pop = $i === 1; ?>
      <article class="plan<?= $pop ? ' is-popular' : '' ?>">
        <?php if ($pop): ?><span class="plan-tag"><?= e('price.popular') ?></span><?php endif; ?>
        <p class="plan-cat"><?= e('students.title') ?></p>
        <h2 class="plan-name"><?= h($pack['name']) ?></h2>
        <p class="plan-price">
          <span class="amount"><?= money((float) $pack['price']) ?></span>
          <span class="per"><?= e('price.per') ?></span>
        </p>
        <ul class="plan-specs">
          <?php if ($pack['specs']): ?>
            <?php foreach ($pack['specs'] as $sp): ?>
            <li><?= icon('check', 'tick') ?><span><?= h(spec($sp)) ?></span></li>
            <?php endforeach; ?>
          <?php else: ?>
            <li class="is-soon"><?= e('students.tbd') ?></li>
          <?php endif; ?>
        </ul>
        <a class="btn <?= $pop ? 'btn-primary' : 'btn-ghost' ?> btn-block" href="<?= h($pack['url'] ?? LINKS['store']) ?>" rel="noopener"><?= e('price.order') ?></a>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="sec cta-band">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('students.cta.title') ?></h2>
        <p><?= e('students.cta.lead') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary btn-lg" href="<?= h(url('home')) ?>#offres"><?= e('v3.cta.offers') ?></a>
        <a class="btn btn-ghost btn-lg" href="<?= h(url('contact')) ?>"><?= e('home.cta.2') ?></a>
      </div>
    </div>
  </div>
</section>
