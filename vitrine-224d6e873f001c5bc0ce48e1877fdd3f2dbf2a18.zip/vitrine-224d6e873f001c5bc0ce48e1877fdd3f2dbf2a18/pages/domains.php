<?php
/**
 * Page /domaines/ — recherche/transfert de domaine (même composant que
 * l'accueil) + liste complète de toutes les extensions vendues avec leurs
 * prix. Accessible depuis le mega-menu "Web" et depuis le bouton "Voir
 * toutes les extensions" de l'accueil.
 */

$showAllLink = false; // on est déjà sur la page, pas la peine du lien
$featuredExts = ['com', 'fr', 'eu'];

require_once __DIR__ . '/../inc/domain_prices.php';
$prices = load_domain_prices();
$rows = [];
foreach ($prices as $ext => $p) {
    $rows[] = ['ext' => $ext, 'featured' => in_array($ext, $featuredExts, true)] + $p;
}
usort($rows, function ($a, $b) {
    if ($a['featured'] !== $b['featured']) return $b['featured'] <=> $a['featured'];
    return $a['ext'] <=> $b['ext'];
});
?>
<section class="sec domains-page-hero">
  <div class="wrap wrap-narrow">
    <h1><?= e('domains_page.title') ?></h1>
    <p class="page-lead"><?= e('domains_page.lead') ?></p>

    <?php require __DIR__ . '/../inc/domain_search_bar.php'; ?>
  </div>
</section>

<section class="sec domains-list-sec">
  <div class="wrap wrap-narrow">
    <h2 class="domains-list-title"><?= e('domains_page.list_title') ?></h2>
    <div class="domains-list">
      <?php foreach ($rows as $row): ?>
        <div class="domains-row<?= $row['featured'] ? ' is-featured' : '' ?>">
          <span class="domains-row-ext">.<?= h($row['ext']) ?></span>
          <span class="domains-row-price">
            <strong><?= money((float) $row['register']) ?></strong> <?= e('domain.per_year_first') ?>
            <span class="domains-row-renew"><?= e('domain.renew_label') ?> <?= money((float) $row['renew']) ?></span>
          </span>
          <button type="button" class="btn btn-ghost btn-sm domains-row-btn" data-domain-quick-ext="<?= h($row['ext']) ?>" aria-label="<?= e('domains_page.check_btn') ?> .<?= h($row['ext']) ?>">
            <?= icon('search') ?><span class="domains-row-btn-t"><?= e('domains_page.check_btn') ?></span>
          </button>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

