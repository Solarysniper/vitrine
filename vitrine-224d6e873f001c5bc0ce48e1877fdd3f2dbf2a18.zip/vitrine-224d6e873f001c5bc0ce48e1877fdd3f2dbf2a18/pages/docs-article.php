<?php
/** Article de documentation : sommaire, corps, navigation entre guides. */

$parsed     = content_parse($docArticle['file']);
$rendered   = content_render($parsed['body']);
$articles   = content_list('docs', lang(), $docCat);
$categories = doc_categories(lang());
$adjacent   = doc_adjacent(lang(), $docCat, $docArticle['key']);
$updated    = $docArticle['meta']['updated'] ?? null;
?>

<section class="page-hero page-hero-doc">
  <div class="wrap">
    <h1><?= h($docArticle['title']) ?></h1>
    <p class="page-lead"><?= h($docArticle['desc']) ?></p>
    <?php if ($updated): ?>
    <p class="page-from"><?= e('docs.updated') ?> <time datetime="<?= h($updated) ?>"><?= h($updated) ?></time></p>
    <?php endif; ?>
    <?php if (!empty($docArticle['fallback'])): ?>
    <aside class="callout callout-warn doc-fallback"><?= icon('flag') ?><p><?= e('docs.fallback') ?></p></aside>
    <?php endif; ?>
  </div>
</section>

<section class="sec sec-tight">
  <div class="wrap">
    <div class="docs-layout docs-layout-article">

      <aside class="docs-side">
        <p class="docs-side-title"><?= e('docs.in_category') ?></p>
        <ul class="docs-side-nav">
          <?php foreach ($articles as $article): ?>
          <li>
            <a href="<?= h(doc_url($docCat, $article['slug'])) ?>"<?= $article['key'] === $docArticle['key'] ? ' class="is-current" aria-current="page"' : '' ?>>
              <span><?= h($article['title']) ?></span>
            </a>
          </li>
          <?php endforeach; ?>
        </ul>
        <a class="docs-side-back" href="<?= h(url('docs')) ?>"><?= icon('arrow', 'rot') ?><?= e('docs.back') ?></a>
      </aside>

      <article class="prose" data-doc-body>
        <?= $rendered['html'] ?>
      </article>

      <?php if (count($rendered['toc']) > 1): ?>
      <aside class="docs-toc">
        <p class="docs-side-title"><?= e('docs.toc') ?></p>
        <ol data-toc>
          <?php foreach ($rendered['toc'] as $item): ?>
          <li class="toc-l<?= (int) $item['level'] ?>"><a href="#<?= h($item['id']) ?>"><?= h($item['text']) ?></a></li>
          <?php endforeach; ?>
        </ol>
      </aside>
      <?php endif; ?>
    </div>

    <nav class="docs-pager" aria-label="<?= e('docs.title') ?>">
      <?php if ($adjacent['prev']): ?>
      <a class="docs-pager-link" href="<?= h(doc_url($adjacent['prev']['category'], $adjacent['prev']['slug'])) ?>">
        <?= icon('arrow', 'rot') ?>
        <span><em><?= e('docs.prev') ?></em><strong><?= h($adjacent['prev']['title']) ?></strong></span>
      </a>
      <?php else: ?><span></span><?php endif; ?>

      <?php if ($adjacent['next']): ?>
      <a class="docs-pager-link is-next" href="<?= h(doc_url($adjacent['next']['category'], $adjacent['next']['slug'])) ?>">
        <span><em><?= e('docs.next') ?></em><strong><?= h($adjacent['next']['title']) ?></strong></span>
        <?= icon('arrow') ?>
      </a>
      <?php endif; ?>
    </nav>
  </div>
</section>

<section class="sec cta-band">
  <div class="wrap">
    <div class="cta-card">
      <div>
        <h2><?= e('docs.help.title') ?></h2>
        <p><?= e('docs.help.lead') ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-primary btn-lg" href="<?= h(LINKS['support']) ?>" rel="noopener"><?= e('footer.ticket') ?></a>
        <a class="btn btn-ghost btn-lg" href="<?= h(LINKS['discord']) ?>" rel="noopener">Discord</a>
      </div>
    </div>
  </div>
</section>

<?php
// Un guide est un TechArticle : c'est ce type que Google attend pour une
// procédure technique, et il autorise l'affichage enrichi du fil d'Ariane
// et de la date de mise à jour.
echo jsonld([
    '@context'         => 'https://schema.org',
    '@type'            => 'TechArticle',
    'headline'         => $docArticle['title'],
    'description'      => $docArticle['desc'],
    'inLanguage'       => LANGS[lang()]['hreflang'],
    'mainEntityOfPage' => ['@type' => 'WebPage', '@id' => SITE_URL . seo_path(lang())],
    'author'           => ['@type' => 'Organization', 'name' => SITE_NAME],
    'publisher'        => seo_publisher(),
    'keywords'         => $docArticle['meta']['keywords'] ?? '',
    'articleSection'   => t('docs.cat.' . $docCat . '.title'),
] + ($updated ? ['dateModified' => $updated] : []));
?>
