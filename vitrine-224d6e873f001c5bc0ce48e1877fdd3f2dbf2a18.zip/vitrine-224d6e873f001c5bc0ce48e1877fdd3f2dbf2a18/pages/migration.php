<?php
/** Page « Migration » : changer d'hébergeur vers Artaun (copie automatique depuis l'espace client). */
$migUrl = LINKS['clients'] . '/client/migration';
$faq = [];
for ($n = 1; $n <= 5; $n++) $faq[] = [t('v4.mig.faq.' . $n . '.q'), t('v4.mig.faq.' . $n . '.a')];
?>
<section class="hero2 mig-hero">
  <div class="wrap hero2-inner">
    <span class="pill"><?= icon('migrate') ?><?= e('v4.mig.eyebrow') ?></span>
    <h1 class="hero2-title"><?= e('v4.mig.h1a') ?> <span><?= e('v4.mig.h1b') ?></span></h1>
    <p class="hero2-lead"><?= e('v4.mig.lead') ?></p>
    <div class="hero2-cta">
      <a class="btn btn-primary btn-lg" href="<?= h($migUrl) ?>" rel="noopener"><?= icon('migrate') ?><?= e('v4.mig.cta') ?></a>
      <a class="btn btn-ghost btn-lg" href="<?= h(url('home')) ?>#offres"><?= e('v4.mig.cta2') ?></a>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <header class="sec-head center"><h2><?= e('v4.mig.steps') ?></h2></header>
    <ol class="mig-steps">
      <?php foreach ([1 => 'gamepad', 2 => 'lock', 3 => 'migrate'] as $n => $ic): ?>
      <li><span class="hw-ic"><?= icon($ic) ?></span><b><?= e('v4.mig.s' . $n) ?></b><p><?= e('v4.mig.s' . $n . 'd') ?></p></li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <header class="sec-head center"><h2><?= e('v4.mig.what') ?></h2></header>
    <div class="hw-grid mig-what">
      <?php foreach ([1 => 'gamepad', 2 => 'globe', 3 => 'server'] as $n => $ic): ?>
      <article class="hw-card"><span class="hw-ic"><?= icon($ic) ?></span><h3><?= e('v4.mig.w' . $n) ?></h3><p><?= e('v4.mig.w' . $n . 'd') ?></p></article>
      <?php endforeach; ?>
      <article class="hw-card mig-sec"><span class="hw-ic"><?= icon('shieldok') ?></span><h3><?= e('v4.mig.sec') ?></h3>
        <ul><?php for ($n = 1; $n <= 3; $n++): ?><li><?= icon('check', 'tick') ?><span><?= e('v4.mig.sec' . $n) ?></span></li><?php endfor; ?></ul>
      </article>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap faq2">
    <header class="faq2-head">
      <h2><?= e('home.faq.title') ?></h2>
      <p><?= e('v4.mig.faq_lead') ?></p>
      <a class="btn btn-ghost" href="<?= h(url('contact')) ?>"><?= e('v4.faq.contact') ?></a>
    </header>
    <div class="faq">
      <?php foreach ($faq as $i => [$q, $a]): ?>
      <details class="faq-item"<?= $i === 0 ? ' open' : '' ?>>
        <summary><?= h($q) ?><?= icon('chevron', 'chev') ?></summary>
        <div class="faq-a"><p><?= h($a) ?></p></div>
      </details>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="cta2">
      <div>
        <h2><?= e('v4.mig.h1a') ?> <?= e('v4.mig.h1b') ?></h2>
        <p><?= e('v4.mig.lead') ?></p>
        <div class="cta-actions">
          <a class="btn btn-light btn-lg" href="<?= h($migUrl) ?>" rel="noopener"><?= e('v4.mig.cta') ?></a>
          <a class="btn btn-outline-light btn-lg" href="<?= h(url('contact')) ?>"><?= e('v4.cta.contact') ?></a>
        </div>
      </div>
      <span class="cta2-mark" aria-hidden="true"><?= icon('migrate') ?></span>
    </div>
  </div>
</section>

<?= jsonld(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(fn($qa) => ['@type' => 'Question', 'name' => $qa[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $qa[1]]], $faq)]) ?>
