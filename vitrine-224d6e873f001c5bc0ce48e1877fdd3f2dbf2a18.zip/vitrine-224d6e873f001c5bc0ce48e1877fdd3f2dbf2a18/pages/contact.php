<?php /** Contact. */ ?>
<section class="page-hero">
  <div class="wrap">
    <h1><?= e('contact.title') ?></h1>
    <p class="page-lead"><?= e('contact.lead') ?></p>
  </div>
</section>

<section class="sec">
  <div class="wrap form-layout">
    <form class="form card-form" id="contact-form" novalidate data-msg-required="<?= e('contact.required') ?>" data-msg-sending="<?= e('contact.sending') ?>" data-msg-error="<?= e('contact.error') ?>">
      <div class="field">
        <label for="c-name"><?= e('contact.name') ?> <span class="req">*</span></label>
        <input type="text" id="c-name" name="name" required autocomplete="name">
      </div>
      <div class="field">
        <label for="c-email"><?= e('contact.email') ?> <span class="req">*</span></label>
        <input type="email" id="c-email" name="email" required autocomplete="email">
      </div>
      <div class="field">
        <label for="c-subject"><?= e('contact.subject') ?> <span class="req">*</span></label>
        <input type="text" id="c-subject" name="subject" required>
      </div>
      <div class="field">
        <label for="c-message"><?= e('contact.message') ?> <span class="req">*</span></label>
        <textarea id="c-message" name="message" rows="7" required></textarea>
      </div>
      <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <button type="submit" class="btn btn-primary btn-block btn-lg"><?= e('contact.send') ?></button>
      <p class="form-msg" data-form-msg role="status"></p>
    </form>

    <aside class="form-side">
      <h2><?= e('contact.other') ?></h2>
      <a class="side-card" href="<?= h(LINKS['discord']) ?>" rel="noopener">
        <span class="card-ic"><?= icon('discord') ?></span>
        <span><strong><?= e('contact.discord_title') ?></strong><em><?= e('contact.discord_desc') ?></em></span>
      </a>
      <a class="side-card" href="<?= h(LINKS['support']) ?>" rel="noopener">
        <span class="card-ic"><?= icon('lifebuoy') ?></span>
        <span><strong><?= e('contact.ticket_title') ?></strong><em><?= e('contact.ticket_desc') ?></em></span>
      </a>
      <a class="side-card" href="<?= h(url('abuse')) ?>">
        <span class="card-ic"><?= icon('shield') ?></span>
        <span><strong><?= e('contact.abuse_title') ?></strong><em><?= e('contact.abuse_desc') ?></em></span>
      </a>
      <p class="side-mail"><?= icon('mail') ?><a href="mailto:<?= SITE_EMAIL ?>"><?= SITE_EMAIL ?></a></p>
    </aside>
  </div>
</section>

<div class="form-done" id="contact-done" hidden>
  <div class="done-card">
    <span class="done-ic"><?= icon('check') ?></span>
    <h2><?= e('contact.sent') ?></h2>
    <p><?= e('contact.sent_desc') ?></p>
    <a class="btn btn-ghost" href="<?= h(url('home')) ?>"><?= e('404.home') ?></a>
  </div>
</div>
