<?php
/**
 * Documents juridiques — français (version faisant foi).
 * Structure : doc.<page> => [title, eyebrow, updated, sections[]]
 * Pages : legal-notice, terms, sales, privacy, cookies, aup, dpa.
 */
return [

'doc.legal-notice' => [
    'title'   => 'Mentions légales',
    'eyebrow' => 'Informations légales',
    'updated' => 'Dernière modification : 24 octobre 2026',
    'sections' => [
        ['title' => 'Éditeur du site', 'body' => '
            <p>En application de l’article 6 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l’économie numérique :</p>
            <dl class="def">
              <div><dt>Nom</dt><dd>Artaun Hosting</dd></div>
              <div><dt>Forme juridique</dt><dd>Association déclarée (loi du 1<sup>er</sup> juillet 1901)</dd></div>
              <div><dt>SIRET</dt><dd>104 908 496 00011</dd></div>
              <div><dt>RNA</dt><dd>W523005685</dd></div>
              <div><dt>Siège social</dt><dd>1 rue des Aziaux, 52410 Eurville-Bienville, France</dd></div>
              <div><dt>TVA</dt><dd>Non applicable, article 293 B du Code général des impôts</dd></div>
              <div><dt>Directeur de la publication</dt><dd>M. Nolhan Lefevre-Menu, président</dd></div>
              <div><dt>Contact</dt><dd>support@artaun.fr · abus : abuse@artaun.fr</dd></div>
            </dl>'],
        ['title' => 'Hébergement', 'body' => '
            <p>Ce site et l’espace client sont hébergés par Artaun Hosting (coordonnées ci-dessus), sur sa propre infrastructure installée au datacenter Equinix PA5 (Aubervilliers, France), avec le concours de son partenaire datacenter Qoriz Hosting. Le trafic est filtré contre les attaques par déni de service (couches 3, 4 et 7) par notre partenaire de mitigation Netrix, avant d’atteindre nos serveurs.</p>'],
        ['title' => 'Propriété intellectuelle', 'body' => '
            <p>Le code, les textes, les logotypes et les éléments graphiques de ce site sont protégés par le Code de la propriété intellectuelle. Les noms et visuels des jeux cités appartiennent à leurs éditeurs respectifs et ne sont utilisés que pour désigner la compatibilité de nos offres.</p>'],
        ['title' => 'Cookies', 'body' => '
            <p>Ce site ne dépose que des cookies nécessaires à son fonctionnement (langue, thème, choix relatif au bandeau). Le détail figure dans notre <a href="{url:cookies}">politique cookies</a>.</p>'],
        ['title' => 'Documents contractuels', 'body' => '
            <p>L’utilisation de nos services est régie par les <a href="{url:terms}">conditions générales d’utilisation</a>, les <a href="{url:sales}">conditions générales de vente</a>, la <a href="{url:aup}">politique d’utilisation acceptable</a>, la <a href="{url:privacy}">politique de confidentialité</a> et, pour les données que vous hébergez, l’<a href="{url:dpa}">accord de traitement des données</a>.</p>'],
    ],
],

'doc.terms' => [
    'title'   => 'Conditions générales d’utilisation',
    'eyebrow' => 'Règles d’utilisation des services',
    'updated' => 'Réf. CGU-2026-V3 · Mise à jour le 23 octobre 2026',
    'sections' => [
        ['title' => 'Objet et acceptation', 'body' => '
            <p>Les présentes conditions régissent l’accès et l’utilisation du site artaun.fr, de l’espace client (clients.artaun.fr) et de l’ensemble des services fournis par Artaun Hosting (ci-après « Artaun »). La création d’un compte vaut acceptation des présentes conditions, des <a href="{url:sales}">conditions générales de vente</a> et de la <a href="{url:aup}">politique d’utilisation acceptable</a>.</p>'],
        ['title' => 'Compte client', 'body' => '
            <p>Vous devez être majeur, ou disposer de l’accord de votre représentant légal, et fournir des informations exactes. Vous êtes responsable de la confidentialité de vos identifiants ; nous vous recommandons d’activer la double authentification. Signalez sans délai toute utilisation non autorisée à support@artaun.fr.</p>
            <p>Un même compte ne peut être partagé que par la fonction « sous-utilisateurs » prévue à cet effet. La création de comptes multiples pour contourner une suspension ou bénéficier plusieurs fois d’une offre d’essai est interdite.</p>'],
        ['title' => 'Statut d’hébergeur', 'body' => '
            <p>Artaun agit en qualité d’hébergeur au sens de l’article 6 de la loi n° 2004-575 du 21 juin 2004. Nous n’exerçons aucun contrôle a priori sur les contenus et programmes que vous déployez, dont vous assumez seul la responsabilité. Nous agissons promptement pour retirer ou rendre inaccessible un contenu manifestement illicite qui nous est signalé (page <a href="{url:abuse}">signalement d’abus</a>).</p>'],
        ['title' => 'Usage des ressources', 'body' => '
            <p>Les usages interdits sont détaillés dans la <a href="{url:aup}">politique d’utilisation acceptable</a>. En particulier : contenus illicites, attaques et scans, envoi de courriers non sollicités, minage de cryptomonnaies sans accord écrit, usage saturant anormalement des ressources partagées.</p>'],
        ['title' => 'Disponibilité et sauvegardes', 'body' => '
            <p>Nous mettons en œuvre les moyens raisonnables pour assurer la continuité du service (surveillance permanente, page de statut publique status.artaun.fr), sans pouvoir garantir une disponibilité ininterrompue. Des maintenances peuvent être nécessaires ; elles sont annoncées à l’avance lorsque c’est possible.</p>
            <p>Des sauvegardes sont proposées selon les offres (sauvegardes planifiées dans l’espace client). Il vous appartient de conserver vos propres copies des données importantes.</p>'],
        ['title' => 'Suspension', 'body' => '
            <p>Nous pouvons suspendre un service, après vous en avoir informé sauf urgence, en cas de violation des présentes conditions, de risque pour la sécurité de l’infrastructure ou d’autres clients, ou sur réquisition d’une autorité. Lorsque c’est possible, la suspension est limitée au service concerné et levée dès que la cause a disparu.</p>'],
        ['title' => 'Assistants automatiques', 'body' => '
            <p>Le site et l’espace client proposent un assistant conversationnel reposant sur un modèle d’intelligence artificielle. Ses réponses sont indicatives : seules nos conditions et les informations de votre espace client font foi. Les actions sensibles proposées par l’assistant de l’espace client (redémarrage, modification de fichiers…) ne sont exécutées qu’après votre confirmation explicite.</p>'],
        ['title' => 'Évolution et droit applicable', 'body' => '
            <p>Nous pouvons faire évoluer les présentes conditions ; toute modification substantielle vous est notifiée par e-mail au moins quinze jours avant son entrée en vigueur. Les présentes conditions sont régies par le droit français.</p>'],
    ],
],

'doc.sales' => [
    'title'   => 'Conditions générales de vente',
    'eyebrow' => 'Contrat de vente',
    'updated' => 'Réf. CGV-2026-V2 · Mise à jour le 27 octobre 2026',
    'sections' => [
        ['title' => 'Vendeur et champ d’application', 'body' => '
            <p>Les présentes conditions s’appliquent à toute commande passée auprès d’Artaun Hosting, association déclarée, SIRET 104 908 496 00011, 1 rue des Aziaux, 52410 Eurville-Bienville, France, support@artaun.fr (ci-après « Artaun »), par un client consommateur ou professionnel (ci-après « le Client »). Les dispositions propres aux consommateurs ne s’appliquent pas aux professionnels.</p>'],
        ['title' => 'Offres et caractéristiques', 'body' => '
            <p>Les caractéristiques essentielles de chaque offre (processeur, mémoire, stockage, limites, options) sont présentées sur artaun.fr et rappelées sur la page de commande de l’espace client avant le paiement. Les offres sont proposées dans la limite des capacités disponibles.</p>'],
        ['title' => 'Prix', 'body' => '
            <p>Les prix sont indiqués en euros, toutes taxes comprises (TVA non applicable, article 293 B du CGI). Le prix d’une durée longue (3, 6 ou 12 mois) intègre la remise affichée. Le prix applicable est celui affiché au moment de la commande ; en cas d’évolution de nos tarifs, le prix d’un service en cours n’est modifié qu’à son renouvellement, après information préalable d’au moins un mois.</p>'],
        ['title' => 'Commande', 'body' => '
            <p>La commande se passe depuis la page « Commander » de l’espace client : choix de l’offre et de la durée, récapitulatif complet (prix, frais éventuels, réduction, total), acceptation des présentes conditions, puis paiement. La commande est ferme à la confirmation du paiement ; une facture est disponible immédiatement dans l’espace client.</p>'],
        ['title' => 'Paiement', 'body' => '
            <p>Le paiement s’effectue par carte bancaire (Stripe), PayPal, solde du compte ou cryptomonnaie selon les moyens proposés. Les paiements par carte sont traités par le prestataire de paiement : Artaun ne reçoit ni ne conserve les numéros de carte. Une carte enregistrée par le Client peut être utilisée pour régler ses factures de renouvellement s’il l’a choisi.</p>'],
        ['title' => 'Livraison', 'body' => '
            <p>Les services sont mis à disposition automatiquement après le paiement, en général en quelques minutes, une fois les éventuels choix de configuration effectués. En cas d’impossibilité de livrer dans un délai de 72 heures, le Client peut annuler sa commande et être intégralement remboursé.</p>'],
        ['title' => 'Durée, renouvellement et résiliation', 'body' => '
            <p>Chaque service est souscrit pour la durée choisie (1, 3, 6 ou 12 mois) et n’est pas renouvelé sans paiement : une facture de renouvellement est émise avant l’échéance et un rappel est envoyé. Le Client peut demander à tout moment la résiliation d’un service depuis son espace client ; elle prend effet à la fin de la période payée, sans frais.</p>
            <p>À défaut de paiement à l’échéance, le service est suspendu, puis supprimé avec ses données passé un délai de grâce communiqué dans l’espace client. Nous vous conseillons de récupérer vos données avant l’échéance.</p>'],
        ['title' => 'Droit de rétractation (consommateurs)', 'body' => '
            <p>En cochant la case dédiée et en validant sa commande avant l\'achat, le Client demande expressément l\'exécution immédiate du service et <strong>reconnaît renoncer expressément à son droit de rétractation</strong>. Par conséquent, <strong>aucun remboursement n\'est possible</strong> après la validation de l\'achat, sauf dans de rares cas exceptionnels évalués et décidés directement par la Direction d\'Artaun Hosting.</p>'],
        ['title' => 'Responsabilité', 'body' => '
            <p>Artaun est tenue d’une obligation de moyens. Elle n’est pas responsable des dommages résultant d’une faute du Client, d’un tiers ou d’un cas de force majeure. Pour les clients professionnels, la responsabilité d’Artaun est limitée au montant payé pour le service concerné au cours des trois derniers mois et exclut les dommages indirects. Ces limitations ne s’appliquent pas aux consommateurs en cas de faute lourde ou de dommage corporel.</p>'],
        ['title' => 'Garanties légales', 'body' => '
            <p>Le Client consommateur bénéficie de la garantie légale de conformité des contenus et services numériques (articles L224-25-12 et suivants du Code de la consommation) : en cas de défaut de conformité, il peut obtenir la mise en conformité du service ou, à défaut, une réduction du prix ou la résolution du contrat.</p>'],
        ['title' => 'Réclamations et médiation', 'body' => '
            <p>Toute réclamation peut être adressée au support (ticket ou support@artaun.fr) ; nous répondons dans un délai de quinze jours. En cas de désaccord persistant, le Client consommateur peut recourir gratuitement à un médiateur de la consommation (article L612-1 du Code de la consommation) ainsi qu’à la plateforme européenne de règlement des litiges.</p>'],
        ['title' => 'Droit applicable', 'body' => '
            <p>Les présentes conditions sont soumises au droit français. À défaut de résolution amiable, le litige est porté devant les juridictions compétentes ; le consommateur peut saisir celle de son domicile.</p>'],
    ],
],

'doc.privacy' => [
    'title'   => 'Politique de confidentialité',
    'eyebrow' => 'Protection des données',
    'updated' => 'Version 2.0 · Mise à jour le 24 octobre 2026',
    'sections' => [
        ['title' => 'Responsable du traitement', 'body' => '
            <p>Artaun Hosting, association déclarée, 1 rue des Aziaux, 52410 Eurville-Bienville, France, est responsable des traitements décrits ici. Contact pour toute question relative à vos données : support@artaun.fr.</p>
            <p>Pour les données que vous hébergez sur nos services, vous êtes responsable de traitement et Artaun agit comme sous-traitant (voir l’<a href="{url:dpa}">accord de traitement des données</a>).</p>'],
        ['title' => 'Données traitées', 'body' => '
            <ul>
              <li><strong>Compte</strong> : nom, prénom, e-mail, adresse postale, téléphone (facultatif), langue ;</li>
              <li><strong>Facturation</strong> : commandes, factures, moyen de paiement utilisé (jamais le numéro complet de carte) ;</li>
              <li><strong>Sécurité</strong> : adresses IP et journaux de connexion, appareils, tentatives échouées, double authentification ;</li>
              <li><strong>Support</strong> : tickets, échanges avec l’assistant ou un conseiller ;</li>
              <li><strong>Services</strong> : informations techniques nécessaires au fonctionnement (adresses IP des serveurs, mesures de ressources, journaux techniques).</li>
            </ul>'],
        ['title' => 'Finalités et bases légales', 'body' => '
            <ul>
              <li>fournir les services commandés, la facturation et le support — <em>exécution du contrat</em> ;</li>
              <li>conserver les factures — <em>obligation légale</em> ;</li>
              <li>sécuriser les comptes et l’infrastructure, prévenir la fraude, les comptes multiples et les abus — <em>intérêt légitime</em> ;</li>
              <li>vous informer des incidents et des échéances — <em>exécution du contrat</em> ;</li>
              <li>répondre via l’assistant conversationnel — <em>intérêt légitime</em>, vous pouvez à tout moment demander un conseiller humain.</li>
            </ul>'],
        ['title' => 'Destinataires et prestataires', 'body' => '
            <p>Vos données ne sont jamais vendues. Elles ne sont communiquées qu’aux prestataires nécessaires, chacun pour sa seule mission :</p>
            <ul>
              <li><strong>Stripe</strong> et <strong>PayPal</strong> : paiement en ligne ;</li>
              <li><strong>Netrix</strong> : filtrage anti-DDoS du trafic réseau (adresses IP, en-têtes des requêtes, sans conservation au-delà de l’analyse) ;</li>
              <li><strong>Google</strong> (modèle Gemini) : génération des réponses de l’assistant, à partir des messages que vous lui envoyez ; connexion avec un compte Google si vous la choisissez ;</li>
              <li><strong>Discord</strong> : transmission à notre équipe de vos messages lorsque vous demandez un conseiller humain, et connexion avec Discord si vous la choisissez ;</li>
              <li><strong>Amazon Web Services</strong> (région de Stockholm) : relais d’envoi de certains e-mails ;</li>
              <li><strong>proxycheck.io</strong> : vérification de l’adresse IP de connexion pour lutter contre la fraude ;</li>
              <li><strong>OpenProvider</strong> : enregistrement des noms de domaine (données transmises aux registres et à l’annuaire WHOIS selon leurs règles) ;</li>
              <li>notre partenaire datacenter, pour l’hébergement physique des serveurs en France.</li>
            </ul>
            <p>Certains de ces prestataires sont établis hors de l’Union européenne (notamment aux États-Unis) ; les transferts sont encadrés par les clauses contractuelles types de la Commission européenne ou le cadre de protection des données UE–États-Unis.</p>'],
        ['title' => 'Durées de conservation', 'body' => '
            <ul>
              <li>compte et services : pendant la relation contractuelle, puis trois ans après le dernier contact pour la prospection, sauf opposition ;</li>
              <li>factures et pièces comptables : dix ans ;</li>
              <li>journaux de connexion et de sécurité : un an ;</li>
              <li>conversations avec l’assistant du site : trente jours ; tickets : trois ans après leur clôture ;</li>
              <li>données d’un service supprimé : effacées à l’issue du délai de grâce, sauvegardes comprises dans les jours qui suivent.</li>
            </ul>'],
        ['title' => 'Sécurité', 'body' => '
            <p>Chiffrement des échanges (HTTPS), mots de passe stockés sous forme d’empreinte, double authentification proposée, secrets techniques chiffrés, accès d’administration limités et journalisés, surveillance permanente de l’infrastructure. Artaun n’accède au contenu de vos serveurs que sur votre demande (ticket) ou pour une raison de sécurité.</p>'],
        ['title' => 'Vos droits', 'body' => '
            <p>Vous disposez des droits d’accès, de rectification, d’effacement, de limitation, d’opposition et de portabilité de vos données. Une copie de vos données peut être téléchargée depuis l’onglet « Données » des paramètres de l’espace client. Pour exercer vos droits : support@artaun.fr. Vous pouvez introduire une réclamation auprès de la CNIL (www.cnil.fr).</p>'],
        ['title' => 'Mineurs', 'body' => '
            <p>Nos services sont destinés aux personnes majeures ou aux mineurs disposant de l’accord de leur représentant légal. Les mineurs de moins de quinze ans ne peuvent créer de compte sans cet accord.</p>'],
        ['title' => 'Modifications', 'body' => '
            <p>Cette politique peut évoluer ; la date de mise à jour figure en tête de page. En cas de changement important, vous en êtes informé par e-mail.</p>'],
    ],
],

'doc.cookies' => [
    'title'   => 'Politique cookies',
    'eyebrow' => 'Traceurs',
    'updated' => 'Mise à jour le 24 octobre 2026',
    'sections' => [
        ['title' => 'Principe', 'body' => '
            <p>Nous n’utilisons ni mesure d’audience tierce, ni publicité, ni réseau social intégré. Seuls des cookies nécessaires au fonctionnement sont déposés ; ils sont dispensés de consentement (article 82 de la loi Informatique et Libertés).</p>'],
        ['title' => 'Site artaun.fr', 'body' => '
            <dl class="def">
              <div><dt>artaun_lang</dt><dd>langue choisie — 1 an</dd></div>
              <div><dt>artaun_theme</dt><dd>thème clair ou sombre — 1 an</dd></div>
              <div><dt>artaun_cookies</dt><dd>votre choix concernant le bandeau d’information — 6 mois</dd></div>
              <div><dt>Session de l’assistant</dt><dd>stockage local du navigateur pour poursuivre une conversation — jusqu’à sa fermeture</dd></div>
            </dl>'],
        ['title' => 'Espace client', 'body' => '
            <dl class="def">
              <div><dt>Session</dt><dd>maintien de votre connexion et protection des formulaires (CSRF) — durée de la session</dd></div>
              <div><dt>Se souvenir de moi</dt><dd>reconnexion automatique si vous l’avez demandée — jusqu’à votre déconnexion (400 jours au plus)</dd></div>
              <div><dt>Préférences</dt><dd>langue, monnaie d’affichage, thème — 1 an</dd></div>
              <div><dt>Parrainage</dt><dd>code de parrainage suivi lors d’une inscription — 30 jours</dd></div>
            </dl>'],
        ['title' => 'Vos choix', 'body' => '
            <p>Vous pouvez supprimer ou bloquer les cookies depuis les réglages de votre navigateur ; le site restera utilisable mais vos préférences ne seront plus mémorisées, et la connexion à l’espace client nécessite le cookie de session.</p>'],
    ],
],

'doc.aup' => [
    'title'   => 'Politique d’utilisation acceptable',
    'eyebrow' => 'Usages autorisés et interdits',
    'updated' => 'Mise à jour le 23 octobre 2026',
    'sections' => [
        ['title' => 'Objet', 'body' => '
            <p>Cette politique précise les usages interdits sur l’ensemble de nos services (serveurs de jeux, VPS, hébergement web, messagerie, bases de données, noms de domaine). Elle complète les <a href="{url:terms}">conditions générales d’utilisation</a>.</p>'],
        ['title' => 'Contenus interdits', 'body' => '
            <ul>
              <li>contenus illicites : pédocriminalité, apologie du terrorisme, incitation à la haine, atteintes à la vie privée, contrefaçon et diffusion d’œuvres sans droits ;</li>
              <li>hameçonnage, faux sites, logiciels malveillants et leur distribution ;</li>
              <li>vente de comptes, de données personnelles ou de moyens de paiement volés.</li>
            </ul>'],
        ['title' => 'Réseau et sécurité', 'body' => '
            <ul>
              <li>attaques par déni de service, « booters » et « stressers », y compris à titre de test sans accord écrit de la cible ;</li>
              <li>scans de ports ou de vulnérabilités, tentatives d’intrusion, force brute ;</li>
              <li>usurpation d’adresses IP, relais ouverts, proxys ou VPN publics utilisés pour masquer des activités interdites.</li>
            </ul>'],
        ['title' => 'Messagerie', 'body' => '
            <ul>
              <li>envoi de courriers non sollicités, achat ou location de listes d’adresses ;</li>
              <li>newsletters sans consentement préalable ni lien de désinscription fonctionnel ;</li>
              <li>dépassement volontaire des limites d’envoi de l’offre.</li>
            </ul>'],
        ['title' => 'Ressources', 'body' => '
            <ul>
              <li>minage de cryptomonnaies sans accord écrit préalable ;</li>
              <li>usage saturant durablement les ressources partagées au détriment des autres clients ;</li>
              <li>sur les serveurs de jeux : logiciels sans rapport avec le jeu ou le bot hébergé, revente non autorisée.</li>
            </ul>'],
        ['title' => 'Jeux en ligne', 'body' => '
            <p>Les règles des éditeurs (conditions d’utilisation des jeux, licences comme celle de Minecraft ou de FiveM) s’appliquent aux serveurs hébergés. La distribution de triches ou de contenus extraits illégalement est interdite.</p>'],
        ['title' => 'Signalement et mesures', 'body' => '
            <p>Tout abus peut être signalé sur la page <a href="{url:abuse}">signalement d’abus</a> ou à abuse@artaun.fr. Selon la gravité, nous pouvons demander une correction, limiter ou suspendre le service concerné, ou résilier le compte, et transmettre les informations requises aux autorités.</p>'],
    ],
],

'doc.dpa' => [
    'title'   => 'Accord de traitement des données',
    'eyebrow' => 'RGPD — article 28',
    'updated' => 'Mise à jour le 24 octobre 2026',
    'sections' => [
        ['title' => 'Parties et objet', 'body' => '
            <p>Lorsque le Client héberge sur nos services des données personnelles (sites web, boîtes e-mail, bases de données, serveurs), il agit comme responsable de traitement et Artaun Hosting comme sous-traitant. Cet accord fait partie du contrat et s’applique automatiquement à tout service.</p>'],
        ['title' => 'Instructions', 'body' => '
            <p>Artaun ne traite ces données que pour fournir le service commandé (stockage, sauvegarde, transmission, sécurité) et selon les instructions du Client données par l’espace client ou par écrit. Artaun ne consulte pas le contenu hébergé, sauf demande du Client ou nécessité de sécurité.</p>'],
        ['title' => 'Confidentialité et sécurité', 'body' => '
            <p>Les personnes autorisées à intervenir sont soumises à une obligation de confidentialité. Artaun met en œuvre des mesures adaptées : isolation des services, chiffrement des échanges et des secrets, contrôle et journalisation des accès d’administration, mises à jour de sécurité, surveillance permanente, sauvegardes selon les offres.</p>'],
        ['title' => 'Sous-traitants ultérieurs', 'body' => '
            <p>Le Client autorise le recours aux sous-traitants ultérieurs nécessaires au service : partenaire datacenter (France), Netrix (filtrage anti-DDoS du trafic réseau), Amazon Web Services (relais d’envoi de certains e-mails, Union européenne). Toute modification de cette liste est publiée sur cette page ; le Client peut s’y opposer en résiliant le service concerné.</p>'],
        ['title' => 'Assistance au Client', 'body' => '
            <p>Artaun aide le Client, dans la mesure du possible, à répondre aux demandes d’exercice des droits des personnes et à réaliser ses analyses d’impact, notamment via les outils de l’espace client (exports, suppression, journaux).</p>'],
        ['title' => 'Violation de données', 'body' => '
            <p>Artaun notifie au Client toute violation de données personnelles le concernant dans les meilleurs délais et au plus tard 48 heures après en avoir pris connaissance, avec les informations disponibles.</p>'],
        ['title' => 'Fin du service', 'body' => '
            <p>À la fin du service, le Client récupère ses données pendant la période payée ; passé le délai de grâce, les données sont supprimées, sauvegardes comprises, sauf obligation légale de conservation.</p>'],
        ['title' => 'Audit', 'body' => '
            <p>Artaun met à disposition du Client les informations nécessaires pour démontrer le respect de ces obligations. Toute demande d’audit est adressée à support@artaun.fr.</p>'],
    ],
],

];
