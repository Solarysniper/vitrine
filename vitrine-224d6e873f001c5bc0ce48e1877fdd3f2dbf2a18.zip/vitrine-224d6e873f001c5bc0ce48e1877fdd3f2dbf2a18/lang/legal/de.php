<?php
/** Rechtliche Dokumente — deutsche Übersetzung. Die französische Fassung ist maßgeblich. */
$note = 'Diese Übersetzung dient nur der Information. Bei Abweichungen ist die französische Fassung dieses Dokuments maßgeblich.';
return [

'doc.legal-notice' => [
    'title'   => 'Impressum',
    'eyebrow' => 'Rechtliche Hinweise',
    'updated' => 'Zuletzt geändert: 24. Oktober 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Herausgeber der Website', 'body' => '
            <p>Gemäß Artikel 6 des französischen Gesetzes Nr. 2004-575 vom 21. Juni 2004 über das Vertrauen in die digitale Wirtschaft:</p>
            <dl class="def">
              <div><dt>Name</dt><dd>Artaun Hosting</dd></div>
              <div><dt>Rechtsform</dt><dd>Eingetragener gemeinnütziger Verein (französisches Gesetz vom 1. Juli 1901)</dd></div>
              <div><dt>SIRET</dt><dd>104 908 496 00011</dd></div>
              <div><dt>RNA</dt><dd>W523005685</dd></div>
              <div><dt>Sitz</dt><dd>1 rue des Aziaux, 52410 Eurville-Bienville, Frankreich</dd></div>
              <div><dt>MwSt.</dt><dd>Nicht anwendbar, Artikel 293 B des französischen Steuergesetzbuchs</dd></div>
              <div><dt>Verantwortlich für den Inhalt</dt><dd>Herr Nolhan Lefevre-Menu, Präsident</dd></div>
              <div><dt>Kontakt</dt><dd>support@artaun.fr · Missbrauch: abuse@artaun.fr</dd></div>
            </dl>'],
        ['title' => 'Hosting', 'body' => '
            <p>Diese Website und der Kundenbereich werden von Artaun Hosting (Angaben oben) auf der eigenen Infrastruktur im Rechenzentrum Equinix PA5 (Aubervilliers, Frankreich) mit Unterstützung des Rechenzentrumspartners Qoriz Hosting betrieben. Der Datenverkehr wird von unserem Mitigationspartner Netrix gegen Denial-of-Service-Angriffe (Schichten 3, 4 und 7) gefiltert, bevor er unsere Server erreicht.</p>'],
        ['title' => 'Geistiges Eigentum', 'body' => '
            <p>Code, Texte, Logos und Grafiken dieser Website sind durch das französische Gesetzbuch über geistiges Eigentum geschützt. Namen und Bilder der genannten Spiele gehören ihren jeweiligen Herausgebern und dienen nur zur Angabe der Kompatibilität unserer Angebote.</p>'],
        ['title' => 'Cookies', 'body' => '
            <p>Diese Website setzt nur für den Betrieb notwendige Cookies (Sprache, Design, Bannerauswahl). Einzelheiten finden Sie in unserer <a href="{url:cookies}">Cookie-Richtlinie</a>.</p>'],
        ['title' => 'Vertragsunterlagen', 'body' => '
            <p>Für die Nutzung unserer Dienste gelten die <a href="{url:terms}">Nutzungsbedingungen</a>, die <a href="{url:sales}">Verkaufsbedingungen</a>, die <a href="{url:aup}">Nutzungsrichtlinie</a>, die <a href="{url:privacy}">Datenschutzerklärung</a> und für die von Ihnen gehosteten Daten der <a href="{url:dpa}">Auftragsverarbeitungsvertrag</a>.</p>'],
    ],
],

'doc.terms' => [
    'title'   => 'Nutzungsbedingungen',
    'eyebrow' => 'Regeln für die Nutzung unserer Dienste',
    'updated' => 'Ref. CGU-2026-V3 · Aktualisiert am 23. Oktober 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Gegenstand und Annahme', 'body' => '
            <p>Diese Bedingungen regeln den Zugang zu und die Nutzung von artaun.fr, des Kundenbereichs (clients.artaun.fr) und aller von Artaun Hosting („Artaun“) erbrachten Dienste. Mit der Kontoerstellung akzeptieren Sie diese Bedingungen, die <a href="{url:sales}">Verkaufsbedingungen</a> und die <a href="{url:aup}">Nutzungsrichtlinie</a>.</p>'],
        ['title' => 'Kundenkonto', 'body' => '
            <p>Sie müssen volljährig sein oder die Zustimmung Ihres gesetzlichen Vertreters haben und zutreffende Angaben machen. Sie sind für die Vertraulichkeit Ihrer Zugangsdaten verantwortlich; wir empfehlen die Zwei-Faktor-Authentifizierung. Melden Sie jede unbefugte Nutzung unverzüglich an support@artaun.fr.</p>
            <p>Ein Konto darf nur über die Funktion „Unterbenutzer“ geteilt werden. Mehrere Konten zur Umgehung einer Sperre oder zur mehrfachen Nutzung eines Testangebots sind verboten.</p>'],
        ['title' => 'Stellung als Hoster', 'body' => '
            <p>Artaun handelt als Hosting-Anbieter im Sinne von Artikel 6 des französischen Gesetzes Nr. 2004-575. Wir prüfen die von Ihnen bereitgestellten Inhalte und Programme nicht im Voraus; Sie allein sind dafür verantwortlich. Offensichtlich rechtswidrige Inhalte, die uns gemeldet werden (Seite <a href="{url:abuse}">Missbrauch melden</a>), entfernen oder sperren wir umgehend.</p>'],
        ['title' => 'Nutzung der Ressourcen', 'body' => '
            <p>Verbotene Nutzungen sind in der <a href="{url:aup}">Nutzungsrichtlinie</a> beschrieben, insbesondere: rechtswidrige Inhalte, Angriffe und Scans, unerwünschte E-Mails, Krypto-Mining ohne schriftliche Zustimmung sowie eine Nutzung, die gemeinsame Ressourcen übermäßig auslastet.</p>'],
        ['title' => 'Verfügbarkeit und Sicherungen', 'body' => '
            <p>Wir setzen angemessene Mittel für einen unterbrechungsfreien Betrieb ein (Überwachung rund um die Uhr, öffentliche Statusseite status.artaun.fr), können eine ununterbrochene Verfügbarkeit jedoch nicht garantieren. Wartungen werden nach Möglichkeit im Voraus angekündigt.</p>
            <p>Je nach Angebot werden Sicherungen angeboten (geplante Sicherungen im Kundenbereich). Sie bleiben verantwortlich, eigene Kopien wichtiger Daten aufzubewahren.</p>'],
        ['title' => 'Sperrung', 'body' => '
            <p>Wir können einen Dienst – außer in dringenden Fällen nach vorheriger Information – sperren bei Verstoß gegen diese Bedingungen, bei Gefahr für die Sicherheit der Infrastruktur oder anderer Kunden oder auf behördliche Anordnung. Nach Möglichkeit beschränkt sich die Sperrung auf den betroffenen Dienst und wird aufgehoben, sobald der Grund entfallen ist.</p>'],
        ['title' => 'Automatische Assistenten', 'body' => '
            <p>Website und Kundenbereich bieten einen Chat-Assistenten auf Basis eines KI-Modells. Seine Antworten sind unverbindlich: maßgeblich sind unsere Bedingungen und die Angaben in Ihrem Kundenbereich. Vom Assistenten des Kundenbereichs vorgeschlagene sensible Aktionen (Neustart, Dateiänderungen …) werden nur nach Ihrer ausdrücklichen Bestätigung ausgeführt.</p>'],
        ['title' => 'Änderungen und anwendbares Recht', 'body' => '
            <p>Wir können diese Bedingungen ändern; wesentliche Änderungen werden Ihnen mindestens fünfzehn Tage vor Inkrafttreten per E-Mail mitgeteilt. Es gilt französisches Recht.</p>'],
    ],
],

'doc.sales' => [
    'title'   => 'Verkaufsbedingungen',
    'eyebrow' => 'Kaufvertrag',
    'updated' => 'Ref. CGV-2026-V2 · Aktualisiert am 23. Oktober 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Verkäufer und Geltungsbereich', 'body' => '
            <p>Diese Bedingungen gelten für alle Bestellungen bei Artaun Hosting, eingetragener Verein, SIRET 104 908 496 00011, 1 rue des Aziaux, 52410 Eurville-Bienville, Frankreich, support@artaun.fr („Artaun“), durch Verbraucher oder Unternehmer („der Kunde“). Verbraucherspezifische Bestimmungen gelten nicht für Unternehmer.</p>'],
        ['title' => 'Angebote und Merkmale', 'body' => '
            <p>Die wesentlichen Merkmale jedes Angebots (Prozessor, Arbeitsspeicher, Speicher, Limits, Optionen) werden auf artaun.fr dargestellt und vor der Zahlung auf der Bestellseite des Kundenbereichs wiederholt. Angebote gelten im Rahmen der verfügbaren Kapazität.</p>'],
        ['title' => 'Preise', 'body' => '
            <p>Die Preise verstehen sich in Euro inklusive aller Steuern (MwSt. nicht anwendbar, Artikel 293 B des französischen Steuergesetzbuchs). Der Preis längerer Laufzeiten (3, 6 oder 12 Monate) enthält den angezeigten Rabatt. Maßgeblich ist der bei Bestellung angezeigte Preis; bei Preisänderungen ändert sich der Preis eines laufenden Dienstes erst bei der Verlängerung und nach mindestens einem Monat Vorankündigung.</p>'],
        ['title' => 'Bestellung', 'body' => '
            <p>Bestellungen erfolgen über die Seite „Bestellen“ des Kundenbereichs: Auswahl von Angebot und Laufzeit, vollständige Übersicht (Preis, etwaige Gebühren, Rabatt, Gesamtbetrag), Annahme dieser Bedingungen und Zahlung. Die Bestellung ist mit Bestätigung der Zahlung verbindlich; die Rechnung steht sofort im Kundenbereich bereit.</p>'],
        ['title' => 'Zahlung', 'body' => '
            <p>Die Zahlung erfolgt je nach Angebot per Karte (Stripe), PayPal, Kontoguthaben oder Kryptowährung. Kartenzahlungen werden vom Zahlungsdienstleister abgewickelt: Artaun erhält und speichert keine Kartennummern. Eine vom Kunden gespeicherte Karte kann auf seinen Wunsch für Verlängerungsrechnungen verwendet werden.</p>'],
        ['title' => 'Bereitstellung', 'body' => '
            <p>Die Dienste werden nach der Zahlung automatisch bereitgestellt, in der Regel innerhalb weniger Minuten, sobald etwaige Konfigurationsentscheidungen getroffen sind. Ist eine Bereitstellung innerhalb von 72 Stunden nicht möglich, kann der Kunde die Bestellung stornieren und erhält eine vollständige Erstattung.</p>'],
        ['title' => 'Laufzeit, Verlängerung und Kündigung', 'body' => '
            <p>Jeder Dienst wird für die gewählte Laufzeit (1, 3, 6 oder 12 Monate) abgeschlossen und ohne Zahlung nicht verlängert: Vor Fälligkeit wird eine Verlängerungsrechnung erstellt und eine Erinnerung gesendet. Der Kunde kann die Kündigung jederzeit im Kundenbereich beantragen; sie wird zum Ende des bezahlten Zeitraums kostenfrei wirksam.</p>
            <p>Erfolgt bis zur Fälligkeit keine Zahlung, wird der Dienst gesperrt und nach der im Kundenbereich angegebenen Kulanzfrist mit seinen Daten gelöscht. Sichern Sie Ihre Daten vor der Fälligkeit.</p>'],
        ['title' => 'Widerrufsrecht (Verbraucher)', 'body' => '
            <p>Verbraucher können innerhalb von vierzehn Tagen ab Vertragsschluss ohne Angabe von Gründen widerrufen, per E-Mail an support@artaun.fr oder per Ticket (Artikel L221-18 ff. des französischen Verbrauchergesetzbuchs). Die Erstattung erfolgt binnen vierzehn Tagen über dasselbe Zahlungsmittel.</p>
            <p>Hat der Kunde verlangt, dass der Dienst vor Ablauf dieser Frist beginnt – wie bei sofortiger Bereitstellung –, schuldet er einen Betrag anteilig zur bis zum Widerruf erbrachten Leistung (Artikel L221-25). Domainnamen, die bei der Bestellung sofort bei einer Registry registriert werden, sind nach der Registrierung vom Widerruf ausgeschlossen (Artikel L221-28).</p>'],
        ['title' => 'Haftung', 'body' => '
            <p>Artaun schuldet eine Leistung nach besten Kräften. Für Schäden durch Verschulden des Kunden, Dritter oder höhere Gewalt haftet Artaun nicht. Gegenüber Unternehmern ist die Haftung auf den in den letzten drei Monaten für den betroffenen Dienst gezahlten Betrag begrenzt und schließt mittelbare Schäden aus. Diese Beschränkungen gelten nicht gegenüber Verbrauchern bei grober Fahrlässigkeit oder Personenschäden.</p>'],
        ['title' => 'Gesetzliche Gewährleistung', 'body' => '
            <p>Verbraucher genießen die gesetzliche Gewährleistung für digitale Inhalte und Dienste (Artikel L224-25-12 ff. des französischen Verbrauchergesetzbuchs): Bei Vertragswidrigkeit können sie die Herstellung des vertragsgemäßen Zustands oder andernfalls eine Preisminderung oder Vertragsauflösung verlangen.</p>'],
        ['title' => 'Beschwerden und Schlichtung', 'body' => '
            <p>Beschwerden richten Sie an den Support (Ticket oder support@artaun.fr); wir antworten innerhalb von fünfzehn Tagen. Bei fortbestehender Uneinigkeit können Verbraucher kostenlos eine Verbraucherschlichtungsstelle (Artikel L612-1 des französischen Verbrauchergesetzbuchs) sowie die europäische Plattform zur Online-Streitbeilegung anrufen.</p>'],
        ['title' => 'Anwendbares Recht', 'body' => '
            <p>Diese Bedingungen unterliegen französischem Recht. Kommt keine gütliche Einigung zustande, sind die zuständigen Gerichte anzurufen; Verbraucher können das Gericht ihres Wohnsitzes anrufen.</p>'],
    ],
],

'doc.privacy' => [
    'title'   => 'Datenschutzerklärung',
    'eyebrow' => 'Datenschutz',
    'updated' => 'Version 2.0 · Aktualisiert am 24. Oktober 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Verantwortlicher', 'body' => '
            <p>Artaun Hosting, eingetragener Verein, 1 rue des Aziaux, 52410 Eurville-Bienville, Frankreich, ist für die hier beschriebenen Verarbeitungen verantwortlich. Kontakt für Fragen zu Ihren Daten: support@artaun.fr.</p>
            <p>Für die von Ihnen auf unseren Diensten gehosteten Daten sind Sie Verantwortlicher und Artaun Auftragsverarbeiter (siehe <a href="{url:dpa}">Auftragsverarbeitungsvertrag</a>).</p>'],
        ['title' => 'Verarbeitete Daten', 'body' => '
            <ul>
              <li><strong>Konto</strong>: Vor- und Nachname, E-Mail, Postanschrift, Telefon (optional), Sprache;</li>
              <li><strong>Abrechnung</strong>: Bestellungen, Rechnungen, verwendetes Zahlungsmittel (nie die vollständige Kartennummer);</li>
              <li><strong>Sicherheit</strong>: IP-Adressen und Anmeldeprotokolle, Geräte, Fehlversuche, Zwei-Faktor-Authentifizierung;</li>
              <li><strong>Support</strong>: Tickets, Gespräche mit dem Assistenten oder einem Berater;</li>
              <li><strong>Dienste</strong>: für den Betrieb notwendige technische Daten (Server-IP-Adressen, Ressourcenmessungen, technische Protokolle).</li>
            </ul>'],
        ['title' => 'Zwecke und Rechtsgrundlagen', 'body' => '
            <ul>
              <li>Erbringung der bestellten Dienste, Abrechnung und Support — <em>Vertragserfüllung</em>;</li>
              <li>Aufbewahrung von Rechnungen — <em>rechtliche Verpflichtung</em>;</li>
              <li>Sicherung von Konten und Infrastruktur, Vorbeugung von Betrug, Mehrfachkonten und Missbrauch — <em>berechtigtes Interesse</em>;</li>
              <li>Information über Störungen und Fälligkeiten — <em>Vertragserfüllung</em>;</li>
              <li>Antworten über den Chat-Assistenten — <em>berechtigtes Interesse</em>; Sie können jederzeit einen menschlichen Berater verlangen.</li>
            </ul>'],
        ['title' => 'Empfänger und Dienstleister', 'body' => '
            <p>Ihre Daten werden nie verkauft. Sie gehen nur an die notwendigen Dienstleister, jeweils für deren Aufgabe:</p>
            <ul>
              <li><strong>Stripe</strong> und <strong>PayPal</strong>: Online-Zahlung;</li>
              <li><strong>Netrix</strong>: Anti-DDoS-Filterung des Netzwerkverkehrs (IP-Adressen, Anfrage-Header, keine Speicherung über die Analyse hinaus);</li>
              <li><strong>Google</strong> (Modell Gemini): Erzeugung der Antworten des Assistenten aus Ihren Nachrichten; Anmeldung mit Google, wenn Sie diese wählen;</li>
              <li><strong>Discord</strong>: Weiterleitung Ihrer Nachrichten an unser Team, wenn Sie einen Berater verlangen, und Anmeldung mit Discord, wenn Sie diese wählen;</li>
              <li><strong>Amazon Web Services</strong> (Region Stockholm): Versandrelais für einige E-Mails;</li>
              <li><strong>proxycheck.io</strong>: Prüfung der Anmelde-IP zur Betrugsbekämpfung;</li>
              <li><strong>OpenProvider</strong>: Registrierung von Domainnamen (Übermittlung an Registries und WHOIS nach deren Regeln);</li>
              <li>unser Rechenzentrumspartner für das physische Hosting der Server in Frankreich.</li>
            </ul>
            <p>Einige Dienstleister sind außerhalb der Europäischen Union ansässig (insbesondere in den USA); Übermittlungen erfolgen auf Grundlage der Standardvertragsklauseln der EU-Kommission oder des EU-US-Datenschutzrahmens.</p>'],
        ['title' => 'Speicherdauer', 'body' => '
            <ul>
              <li>Konto und Dienste: für die Dauer der Vertragsbeziehung, danach drei Jahre ab dem letzten Kontakt, sofern Sie nicht widersprechen;</li>
              <li>Rechnungen und Buchungsbelege: zehn Jahre;</li>
              <li>Anmelde- und Sicherheitsprotokolle: ein Jahr;</li>
              <li>Gespräche mit dem Website-Assistenten: dreißig Tage; Tickets: drei Jahre nach Abschluss;</li>
              <li>Daten eines gelöschten Dienstes: nach der Kulanzfrist gelöscht, Sicherungen in den folgenden Tagen.</li>
            </ul>'],
        ['title' => 'Sicherheit', 'body' => '
            <p>Verschlüsselte Verbindungen (HTTPS), gehashte Passwörter, Zwei-Faktor-Authentifizierung, verschlüsselte technische Geheimnisse, beschränkter und protokollierter Administratorzugang, ständige Überwachung der Infrastruktur. Artaun greift nur auf Ihre Anfrage (Ticket) oder aus Sicherheitsgründen auf Inhalte Ihrer Server zu.</p>'],
        ['title' => 'Ihre Rechte', 'body' => '
            <p>Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch und Datenübertragbarkeit. Eine Kopie Ihrer Daten können Sie im Reiter „Daten“ der Einstellungen des Kundenbereichs herunterladen. Ausübung Ihrer Rechte: support@artaun.fr. Sie können Beschwerde bei der CNIL (www.cnil.fr) einlegen.</p>'],
        ['title' => 'Minderjährige', 'body' => '
            <p>Unsere Dienste richten sich an Volljährige oder Minderjährige mit Zustimmung ihres gesetzlichen Vertreters. Unter Fünfzehnjährige können ohne diese Zustimmung kein Konto erstellen.</p>'],
        ['title' => 'Änderungen', 'body' => '
            <p>Diese Erklärung kann sich ändern; das Aktualisierungsdatum steht oben. Über wesentliche Änderungen informieren wir Sie per E-Mail.</p>'],
    ],
],

'doc.cookies' => [
    'title'   => 'Cookie-Richtlinie',
    'eyebrow' => 'Tracker',
    'updated' => 'Aktualisiert am 24. Oktober 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Grundsatz', 'body' => '
            <p>Wir verwenden keine Analyse-Dienste Dritter, keine Werbung und keine eingebetteten sozialen Netzwerke. Es werden nur für den Betrieb notwendige Cookies gesetzt; sie sind einwilligungsfrei (Artikel 82 des französischen Datenschutzgesetzes).</p>'],
        ['title' => 'Website artaun.fr', 'body' => '
            <dl class="def">
              <div><dt>artaun_lang</dt><dd>gewählte Sprache — 1 Jahr</dd></div>
              <div><dt>artaun_theme</dt><dd>helles oder dunkles Design — 1 Jahr</dd></div>
              <div><dt>artaun_cookies</dt><dd>Ihre Entscheidung zum Hinweisbanner — 6 Monate</dd></div>
              <div><dt>Assistenten-Sitzung</dt><dd>lokaler Browserspeicher zum Fortsetzen eines Gesprächs — bis zum Schließen</dd></div>
            </dl>'],
        ['title' => 'Kundenbereich', 'body' => '
            <dl class="def">
              <div><dt>Sitzung</dt><dd>hält Sie angemeldet und schützt Formulare (CSRF) — Dauer der Sitzung</dd></div>
              <div><dt>Angemeldet bleiben</dt><dd>automatische Anmeldung, wenn gewünscht — bis zur Abmeldung (höchstens 400 Tage)</dd></div>
              <div><dt>Einstellungen</dt><dd>Sprache, Anzeigewährung, Design — 1 Jahr</dd></div>
              <div><dt>Empfehlung</dt><dd>bei der Registrierung verfolgter Empfehlungscode — 30 Tage</dd></div>
            </dl>'],
        ['title' => 'Ihre Wahl', 'body' => '
            <p>Sie können Cookies in Ihren Browsereinstellungen löschen oder blockieren; die Website bleibt nutzbar, Ihre Einstellungen werden jedoch nicht mehr gespeichert, und die Anmeldung im Kundenbereich erfordert das Sitzungscookie.</p>'],
    ],
],

'doc.aup' => [
    'title'   => 'Nutzungsrichtlinie',
    'eyebrow' => 'Erlaubte und verbotene Nutzungen',
    'updated' => 'Aktualisiert am 23. Oktober 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Gegenstand', 'body' => '
            <p>Diese Richtlinie legt die verbotenen Nutzungen aller unserer Dienste fest (Gameserver, VPS, Webhosting, E-Mail, Datenbanken, Domainnamen). Sie ergänzt die <a href="{url:terms}">Nutzungsbedingungen</a>.</p>'],
        ['title' => 'Verbotene Inhalte', 'body' => '
            <ul>
              <li>rechtswidrige Inhalte: Darstellungen sexuellen Kindesmissbrauchs, Terrorverherrlichung, Volksverhetzung, Verletzung der Privatsphäre, Produktpiraterie und Verbreitung von Werken ohne Rechte;</li>
              <li>Phishing, gefälschte Websites, Schadsoftware und deren Verbreitung;</li>
              <li>Verkauf gestohlener Konten, personenbezogener Daten oder Zahlungsmittel.</li>
            </ul>'],
        ['title' => 'Netzwerk und Sicherheit', 'body' => '
            <ul>
              <li>Denial-of-Service-Angriffe, „Booter“ und „Stresser“, auch als Test ohne schriftliche Zustimmung des Ziels;</li>
              <li>Port- oder Schwachstellenscans, Einbruchsversuche, Brute-Force;</li>
              <li>IP-Spoofing, offene Relays, öffentliche Proxys oder VPNs zur Verschleierung verbotener Tätigkeiten.</li>
            </ul>'],
        ['title' => 'E-Mail', 'body' => '
            <ul>
              <li>Versand unerwünschter E-Mails, Kauf oder Miete von Adresslisten;</li>
              <li>Newsletter ohne vorherige Einwilligung oder funktionierenden Abmeldelink;</li>
              <li>absichtliches Überschreiten der Versandlimits des Angebots.</li>
            </ul>'],
        ['title' => 'Ressourcen', 'body' => '
            <ul>
              <li>Krypto-Mining ohne vorherige schriftliche Zustimmung;</li>
              <li>Nutzung, die gemeinsame Ressourcen dauerhaft zulasten anderer Kunden auslastet;</li>
              <li>auf Gameservern: Software ohne Bezug zum gehosteten Spiel oder Bot, unerlaubter Weiterverkauf.</li>
            </ul>'],
        ['title' => 'Online-Spiele', 'body' => '
            <p>Die Regeln der Herausgeber (Nutzungsbedingungen der Spiele, Lizenzen wie die von Minecraft oder FiveM) gelten für gehostete Server. Die Verbreitung von Cheats oder rechtswidrig extrahierten Inhalten ist verboten.</p>'],
        ['title' => 'Meldung und Maßnahmen', 'body' => '
            <p>Missbrauch kann über die Seite <a href="{url:abuse}">Missbrauch melden</a> oder an abuse@artaun.fr gemeldet werden. Je nach Schwere können wir eine Korrektur verlangen, den betroffenen Dienst einschränken oder sperren oder das Konto kündigen und erforderliche Informationen an Behörden übermitteln.</p>'],
    ],
],

'doc.dpa' => [
    'title'   => 'Auftragsverarbeitungsvertrag',
    'eyebrow' => 'DSGVO — Artikel 28',
    'updated' => 'Aktualisiert am 24. Oktober 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Parteien und Gegenstand', 'body' => '
            <p>Hostet der Kunde personenbezogene Daten auf unseren Diensten (Websites, Postfächer, Datenbanken, Server), ist er Verantwortlicher und Artaun Hosting Auftragsverarbeiter. Dieser Vertrag ist Bestandteil des Vertrags und gilt automatisch für jeden Dienst.</p>'],
        ['title' => 'Weisungen', 'body' => '
            <p>Artaun verarbeitet diese Daten nur zur Erbringung des bestellten Dienstes (Speicherung, Sicherung, Übertragung, Sicherheit) und nach den Weisungen des Kunden über den Kundenbereich oder in Schriftform. Artaun sieht gehostete Inhalte nicht ein, außer auf Wunsch des Kunden oder aus Sicherheitsgründen.</p>'],
        ['title' => 'Vertraulichkeit und Sicherheit', 'body' => '
            <p>Befugte Personen sind zur Vertraulichkeit verpflichtet. Artaun trifft geeignete Maßnahmen: Isolierung der Dienste, Verschlüsselung von Verbindungen und Geheimnissen, Kontrolle und Protokollierung administrativer Zugriffe, Sicherheitsupdates, ständige Überwachung, Sicherungen je nach Angebot.</p>'],
        ['title' => 'Unterauftragsverarbeiter', 'body' => '
            <p>Der Kunde genehmigt die für den Dienst notwendigen Unterauftragsverarbeiter: Rechenzentrumspartner (Frankreich), Netrix (Anti-DDoS-Filterung des Netzwerkverkehrs), Amazon Web Services (Versandrelais einiger E-Mails, Europäische Union). Änderungen dieser Liste werden auf dieser Seite veröffentlicht; der Kunde kann durch Kündigung des betroffenen Dienstes widersprechen.</p>'],
        ['title' => 'Unterstützung des Kunden', 'body' => '
            <p>Artaun unterstützt den Kunden nach Möglichkeit bei Anfragen betroffener Personen und bei Datenschutz-Folgenabschätzungen, insbesondere über die Werkzeuge des Kundenbereichs (Exporte, Löschung, Protokolle).</p>'],
        ['title' => 'Datenschutzverletzung', 'body' => '
            <p>Artaun meldet dem Kunden jede ihn betreffende Verletzung des Schutzes personenbezogener Daten unverzüglich, spätestens 48 Stunden nach Kenntnisnahme, mit den verfügbaren Informationen.</p>'],
        ['title' => 'Ende des Dienstes', 'body' => '
            <p>Am Ende des Dienstes kann der Kunde seine Daten während des bezahlten Zeitraums abrufen; nach der Kulanzfrist werden die Daten einschließlich Sicherungen gelöscht, sofern keine gesetzliche Aufbewahrungspflicht besteht.</p>'],
        ['title' => 'Audit', 'body' => '
            <p>Artaun stellt dem Kunden die zum Nachweis der Einhaltung dieser Pflichten erforderlichen Informationen zur Verfügung. Audit-Anfragen richten Sie an support@artaun.fr.</p>'],
    ],
],

];
