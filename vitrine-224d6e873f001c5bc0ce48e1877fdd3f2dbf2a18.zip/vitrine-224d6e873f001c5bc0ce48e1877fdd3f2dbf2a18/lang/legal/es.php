<?php
/** Documentos jurídicos — traducción al español. Prevalece la versión francesa. */
$note = 'Esta traducción se ofrece a título informativo. En caso de discrepancia, prevalece la versión francesa de este documento.';
return [

'doc.legal-notice' => [
    'title'   => 'Aviso legal',
    'eyebrow' => 'Información legal',
    'updated' => 'Última modificación: 24 de octubre de 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Editor del sitio', 'body' => '
            <p>En aplicación del artículo 6 de la ley francesa n.º 2004-575 de 21 de junio de 2004 sobre la confianza en la economía digital:</p>
            <dl class="def">
              <div><dt>Nombre</dt><dd>Artaun Hosting</dd></div>
              <div><dt>Forma jurídica</dt><dd>Asociación declarada sin ánimo de lucro (ley francesa de 1 de julio de 1901)</dd></div>
              <div><dt>SIRET</dt><dd>104 908 496 00011</dd></div>
              <div><dt>RNA</dt><dd>W523005685</dd></div>
              <div><dt>Domicilio social</dt><dd>1 rue des Aziaux, 52410 Eurville-Bienville, Francia</dd></div>
              <div><dt>IVA</dt><dd>No aplicable, artículo 293 B del Código General de Impuestos francés</dd></div>
              <div><dt>Director de la publicación</dt><dd>D. Nolhan Lefevre-Menu, presidente</dd></div>
              <div><dt>Contacto</dt><dd>support@artaun.fr · abusos: abuse@artaun.fr</dd></div>
            </dl>'],
        ['title' => 'Alojamiento', 'body' => '
            <p>Este sitio y el área de cliente están alojados por Artaun Hosting (datos arriba) en su propia infraestructura del centro de datos Equinix PA5 (Aubervilliers, Francia), con el apoyo de su socio de centro de datos Qoriz Hosting. El tráfico es filtrado contra ataques de denegación de servicio (capas 3, 4 y 7) por nuestro socio de mitigación Netrix antes de llegar a nuestros servidores.</p>'],
        ['title' => 'Propiedad intelectual', 'body' => '
            <p>El código, los textos, los logotipos y los elementos gráficos de este sitio están protegidos por el Código de la Propiedad Intelectual francés. Los nombres e imágenes de los juegos citados pertenecen a sus editores y solo se usan para indicar la compatibilidad de nuestras ofertas.</p>'],
        ['title' => 'Cookies', 'body' => '
            <p>Este sitio solo deposita cookies necesarias para su funcionamiento (idioma, tema, elección sobre el banner). Los detalles figuran en nuestra <a href="{url:cookies}">política de cookies</a>.</p>'],
        ['title' => 'Documentos contractuales', 'body' => '
            <p>El uso de nuestros servicios se rige por las <a href="{url:terms}">condiciones de uso</a>, las <a href="{url:sales}">condiciones de venta</a>, la <a href="{url:aup}">política de uso aceptable</a>, la <a href="{url:privacy}">política de privacidad</a> y, para los datos que aloja, el <a href="{url:dpa}">acuerdo de tratamiento de datos</a>.</p>'],
    ],
],

'doc.terms' => [
    'title'   => 'Condiciones de uso',
    'eyebrow' => 'Normas de uso de los servicios',
    'updated' => 'Ref. CGU-2026-V3 · Actualizado el 23 de octubre de 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Objeto y aceptación', 'body' => '
            <p>Estas condiciones regulan el acceso y uso de artaun.fr, del área de cliente (clients.artaun.fr) y de todos los servicios prestados por Artaun Hosting («Artaun»). Crear una cuenta implica aceptar estas condiciones, las <a href="{url:sales}">condiciones de venta</a> y la <a href="{url:aup}">política de uso aceptable</a>.</p>'],
        ['title' => 'Cuenta de cliente', 'body' => '
            <p>Debe ser mayor de edad, o contar con el consentimiento de su representante legal, y facilitar información exacta. Es responsable de la confidencialidad de sus credenciales; recomendamos activar la autenticación en dos pasos. Comunique sin demora cualquier uso no autorizado a support@artaun.fr.</p>
            <p>Una cuenta solo puede compartirse mediante la función «subusuarios». Está prohibido crear varias cuentas para eludir una suspensión o aprovechar varias veces una oferta de prueba.</p>'],
        ['title' => 'Condición de proveedor de alojamiento', 'body' => '
            <p>Artaun actúa como proveedor de alojamiento en el sentido del artículo 6 de la ley francesa n.º 2004-575. No controlamos de antemano los contenidos y programas que despliega, de los que usted es el único responsable. Retiramos o bloqueamos con rapidez los contenidos manifiestamente ilícitos que se nos notifican (página <a href="{url:abuse}">denunciar abuso</a>).</p>'],
        ['title' => 'Uso de los recursos', 'body' => '
            <p>Los usos prohibidos se detallan en la <a href="{url:aup}">política de uso aceptable</a>, en particular: contenidos ilícitos, ataques y escaneos, correo no solicitado, minería de criptomonedas sin acuerdo escrito y uso que sature anormalmente los recursos compartidos.</p>'],
        ['title' => 'Disponibilidad y copias de seguridad', 'body' => '
            <p>Empleamos medios razonables para garantizar la continuidad del servicio (supervisión permanente, página de estado pública status.artaun.fr), sin poder garantizar una disponibilidad ininterrumpida. Los mantenimientos se anuncian con antelación siempre que sea posible.</p>
            <p>Según la oferta se proponen copias de seguridad (copias programadas en el área de cliente). Usted sigue siendo responsable de conservar sus propias copias de los datos importantes.</p>'],
        ['title' => 'Suspensión', 'body' => '
            <p>Podemos suspender un servicio, tras informarle salvo urgencia, en caso de incumplimiento de estas condiciones, de riesgo para la seguridad de la infraestructura o de otros clientes, o a petición de una autoridad. Siempre que sea posible, la suspensión se limita al servicio afectado y se levanta en cuanto desaparece la causa.</p>'],
        ['title' => 'Asistentes automáticos', 'body' => '
            <p>El sitio y el área de cliente ofrecen un asistente conversacional basado en un modelo de inteligencia artificial. Sus respuestas son orientativas: prevalecen nuestras condiciones y la información de su área de cliente. Las acciones sensibles propuestas por el asistente del área de cliente (reinicio, modificación de archivos…) solo se ejecutan tras su confirmación expresa.</p>'],
        ['title' => 'Cambios y ley aplicable', 'body' => '
            <p>Podemos modificar estas condiciones; cualquier cambio sustancial se le notifica por correo electrónico al menos quince días antes de su entrada en vigor. Estas condiciones se rigen por el derecho francés.</p>'],
    ],
],

'doc.sales' => [
    'title'   => 'Condiciones de venta',
    'eyebrow' => 'Contrato de venta',
    'updated' => 'Ref. CGV-2026-V2 · Actualizado el 23 de octubre de 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Vendedor y ámbito de aplicación', 'body' => '
            <p>Estas condiciones se aplican a todo pedido realizado a Artaun Hosting, asociación declarada, SIRET 104 908 496 00011, 1 rue des Aziaux, 52410 Eurville-Bienville, Francia, support@artaun.fr («Artaun»), por un cliente consumidor o profesional («el Cliente»). Las disposiciones propias de los consumidores no se aplican a los profesionales.</p>'],
        ['title' => 'Ofertas y características', 'body' => '
            <p>Las características esenciales de cada oferta (procesador, memoria, almacenamiento, límites, opciones) se presentan en artaun.fr y se recuerdan en la página de pedido del área de cliente antes del pago. Las ofertas están sujetas a la capacidad disponible.</p>'],
        ['title' => 'Precios', 'body' => '
            <p>Los precios se indican en euros, impuestos incluidos (IVA no aplicable, artículo 293 B del Código General de Impuestos francés). El precio de una duración larga (3, 6 o 12 meses) incluye el descuento mostrado. Se aplica el precio mostrado en el momento del pedido; si nuestras tarifas cambian, el precio de un servicio activo solo cambia en su renovación, con al menos un mes de preaviso.</p>'],
        ['title' => 'Pedido', 'body' => '
            <p>El pedido se realiza desde la página «Pedir» del área de cliente: elección de la oferta y la duración, resumen completo (precio, posibles gastos, descuento, total), aceptación de estas condiciones y pago. El pedido es firme al confirmarse el pago; la factura está disponible de inmediato en el área de cliente.</p>'],
        ['title' => 'Pago', 'body' => '
            <p>El pago se realiza con tarjeta (Stripe), PayPal, saldo de la cuenta o criptomoneda según los medios ofrecidos. Los pagos con tarjeta los procesa el proveedor de pagos: Artaun nunca recibe ni conserva números de tarjeta. Una tarjeta guardada por el Cliente puede usarse para pagar las facturas de renovación si así lo ha elegido.</p>'],
        ['title' => 'Entrega', 'body' => '
            <p>Los servicios se ponen a disposición automáticamente tras el pago, normalmente en pocos minutos, una vez realizadas las posibles elecciones de configuración. Si la entrega es imposible en 72 horas, el Cliente puede cancelar el pedido y obtener el reembolso íntegro.</p>'],
        ['title' => 'Duración, renovación y rescisión', 'body' => '
            <p>Cada servicio se contrata por la duración elegida (1, 3, 6 o 12 meses) y no se renueva sin pago: antes del vencimiento se emite una factura de renovación y se envía un recordatorio. El Cliente puede solicitar en cualquier momento la rescisión de un servicio desde su área de cliente; surte efecto al final del periodo pagado, sin gastos.</p>
            <p>A falta de pago al vencimiento, el servicio se suspende y luego se elimina con sus datos tras el periodo de gracia indicado en el área de cliente. Le aconsejamos recuperar sus datos antes del vencimiento.</p>'],
        ['title' => 'Derecho de desistimiento (consumidores)', 'body' => '
            <p>El Cliente consumidor dispone de catorce días desde la contratación para desistir, sin indicar motivo, escribiendo a support@artaun.fr o mediante un ticket (artículos L221-18 y siguientes del Código de Consumo francés). El reembolso se efectúa en catorce días por el mismo medio de pago.</p>
            <p>Si el Cliente ha solicitado que el servicio comience antes del fin de ese plazo, como ocurre con la entrega inmediata, deberá un importe proporcional al servicio prestado hasta el desistimiento (artículo L221-25). Los nombres de dominio, registrados ante un registro desde el pedido, no admiten desistimiento una vez registrados (artículo L221-28).</p>'],
        ['title' => 'Responsabilidad', 'body' => '
            <p>Artaun asume una obligación de medios. No es responsable de los daños causados por culpa del Cliente, de un tercero o por fuerza mayor. Para los clientes profesionales, la responsabilidad de Artaun se limita al importe pagado por el servicio afectado en los tres últimos meses y excluye los daños indirectos. Estas limitaciones no se aplican a los consumidores en caso de culpa grave o daños corporales.</p>'],
        ['title' => 'Garantías legales', 'body' => '
            <p>El Cliente consumidor goza de la garantía legal de conformidad de los contenidos y servicios digitales (artículos L224-25-12 y siguientes del Código de Consumo francés): en caso de falta de conformidad, puede obtener la puesta en conformidad del servicio o, en su defecto, una reducción del precio o la resolución del contrato.</p>'],
        ['title' => 'Reclamaciones y mediación', 'body' => '
            <p>Toda reclamación puede dirigirse al soporte (ticket o support@artaun.fr); respondemos en un plazo de quince días. En caso de desacuerdo persistente, el Cliente consumidor puede recurrir gratuitamente a un mediador de consumo (artículo L612-1 del Código de Consumo francés) y a la plataforma europea de resolución de litigios en línea.</p>'],
        ['title' => 'Ley aplicable', 'body' => '
            <p>Estas condiciones se rigen por el derecho francés. A falta de acuerdo amistoso, el litigio se somete a los tribunales competentes; el consumidor puede acudir al de su domicilio.</p>'],
    ],
],

'doc.privacy' => [
    'title'   => 'Política de privacidad',
    'eyebrow' => 'Protección de datos',
    'updated' => 'Versión 2.0 · Actualizado el 24 de octubre de 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Responsable del tratamiento', 'body' => '
            <p>Artaun Hosting, asociación declarada, 1 rue des Aziaux, 52410 Eurville-Bienville, Francia, es responsable de los tratamientos descritos aquí. Contacto para cualquier pregunta sobre sus datos: support@artaun.fr.</p>
            <p>Para los datos que aloja en nuestros servicios, usted es el responsable y Artaun actúa como encargado (véase el <a href="{url:dpa}">acuerdo de tratamiento de datos</a>).</p>'],
        ['title' => 'Datos tratados', 'body' => '
            <ul>
              <li><strong>Cuenta</strong>: nombre y apellidos, correo electrónico, dirección postal, teléfono (opcional), idioma;</li>
              <li><strong>Facturación</strong>: pedidos, facturas, medio de pago utilizado (nunca el número completo de la tarjeta);</li>
              <li><strong>Seguridad</strong>: direcciones IP y registros de conexión, dispositivos, intentos fallidos, autenticación en dos pasos;</li>
              <li><strong>Soporte</strong>: tickets, conversaciones con el asistente o un asesor;</li>
              <li><strong>Servicios</strong>: información técnica necesaria para el funcionamiento (IP de los servidores, mediciones de recursos, registros técnicos).</li>
            </ul>'],
        ['title' => 'Finalidades y bases jurídicas', 'body' => '
            <ul>
              <li>prestar los servicios contratados, facturación y soporte — <em>ejecución del contrato</em>;</li>
              <li>conservar las facturas — <em>obligación legal</em>;</li>
              <li>proteger las cuentas y la infraestructura, prevenir el fraude, las cuentas múltiples y los abusos — <em>interés legítimo</em>;</li>
              <li>informarle de incidencias y vencimientos — <em>ejecución del contrato</em>;</li>
              <li>responder mediante el asistente conversacional — <em>interés legítimo</em>; puede pedir un asesor humano en cualquier momento.</li>
            </ul>'],
        ['title' => 'Destinatarios y proveedores', 'body' => '
            <p>Sus datos nunca se venden. Solo se comunican a los proveedores necesarios, cada uno para su cometido:</p>
            <ul>
              <li><strong>Stripe</strong> y <strong>PayPal</strong>: pago en línea;</li>
              <li><strong>Netrix</strong>: filtrado anti-DDoS del tráfico de red (direcciones IP, cabeceras de las solicitudes, sin conservación más allá del análisis);</li>
              <li><strong>Google</strong> (modelo Gemini): generación de las respuestas del asistente a partir de los mensajes que le envía; acceso con una cuenta de Google si lo elige;</li>
              <li><strong>Discord</strong>: transmisión de sus mensajes a nuestro equipo cuando pide un asesor humano, y acceso con Discord si lo elige;</li>
              <li><strong>Amazon Web Services</strong> (región de Estocolmo): relé de envío de algunos correos;</li>
              <li><strong>proxycheck.io</strong>: verificación de la IP de conexión para luchar contra el fraude;</li>
              <li><strong>OpenProvider</strong>: registro de nombres de dominio (datos transmitidos a los registros y al directorio WHOIS según sus normas);</li>
              <li>nuestro socio de centro de datos, para el alojamiento físico de los servidores en Francia.</li>
            </ul>
            <p>Algunos de estos proveedores están establecidos fuera de la Unión Europea (en particular en Estados Unidos); las transferencias se rigen por las cláusulas contractuales tipo de la Comisión Europea o el Marco de Privacidad de Datos UE-EE. UU.</p>'],
        ['title' => 'Plazos de conservación', 'body' => '
            <ul>
              <li>cuenta y servicios: mientras dure la relación contractual y tres años después del último contacto, salvo oposición;</li>
              <li>facturas y documentos contables: diez años;</li>
              <li>registros de conexión y seguridad: un año;</li>
              <li>conversaciones con el asistente del sitio: treinta días; tickets: tres años tras su cierre;</li>
              <li>datos de un servicio eliminado: borrados al término del periodo de gracia, copias de seguridad incluidas en los días siguientes.</li>
            </ul>'],
        ['title' => 'Seguridad', 'body' => '
            <p>Conexiones cifradas (HTTPS), contraseñas almacenadas como huella, autenticación en dos pasos disponible, secretos técnicos cifrados, accesos de administración limitados y registrados, supervisión permanente de la infraestructura. Artaun solo accede al contenido de sus servidores a petición suya (ticket) o por motivos de seguridad.</p>'],
        ['title' => 'Sus derechos', 'body' => '
            <p>Tiene derecho de acceso, rectificación, supresión, limitación, oposición y portabilidad. Puede descargar una copia de sus datos desde la pestaña «Datos» de los ajustes del área de cliente. Para ejercer sus derechos: support@artaun.fr. Puede presentar una reclamación ante la CNIL (www.cnil.fr).</p>'],
        ['title' => 'Menores', 'body' => '
            <p>Nuestros servicios se dirigen a mayores de edad o a menores con el consentimiento de su representante legal. Los menores de quince años no pueden crear una cuenta sin dicho consentimiento.</p>'],
        ['title' => 'Cambios', 'body' => '
            <p>Esta política puede evolucionar; la fecha de actualización figura al principio de la página. Le informaremos por correo de cualquier cambio importante.</p>'],
    ],
],

'doc.cookies' => [
    'title'   => 'Política de cookies',
    'eyebrow' => 'Rastreadores',
    'updated' => 'Actualizado el 24 de octubre de 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Principio', 'body' => '
            <p>No usamos analítica de terceros, publicidad ni redes sociales integradas. Solo se depositan cookies necesarias para el funcionamiento; están exentas de consentimiento (artículo 82 de la ley francesa de protección de datos).</p>'],
        ['title' => 'Sitio artaun.fr', 'body' => '
            <dl class="def">
              <div><dt>artaun_lang</dt><dd>idioma elegido — 1 año</dd></div>
              <div><dt>artaun_theme</dt><dd>tema claro u oscuro — 1 año</dd></div>
              <div><dt>artaun_cookies</dt><dd>su elección sobre el banner informativo — 6 meses</dd></div>
              <div><dt>Sesión del asistente</dt><dd>almacenamiento local del navegador para continuar una conversación — hasta que se cierra</dd></div>
            </dl>'],
        ['title' => 'Área de cliente', 'body' => '
            <dl class="def">
              <div><dt>Sesión</dt><dd>mantiene su conexión y protege los formularios (CSRF) — duración de la sesión</dd></div>
              <div><dt>Recordarme</dt><dd>reconexión automática si la ha pedido — hasta que cierre sesión (400 días como máximo)</dd></div>
              <div><dt>Preferencias</dt><dd>idioma, moneda de visualización, tema — 1 año</dd></div>
              <div><dt>Patrocinio</dt><dd>código de patrocinio seguido durante el registro — 30 días</dd></div>
            </dl>'],
        ['title' => 'Sus opciones', 'body' => '
            <p>Puede eliminar o bloquear las cookies desde los ajustes de su navegador; el sitio sigue siendo utilizable, pero sus preferencias ya no se recordarán, y el acceso al área de cliente requiere la cookie de sesión.</p>'],
    ],
],

'doc.aup' => [
    'title'   => 'Política de uso aceptable',
    'eyebrow' => 'Usos permitidos y prohibidos',
    'updated' => 'Actualizado el 23 de octubre de 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Objeto', 'body' => '
            <p>Esta política precisa los usos prohibidos en todos nuestros servicios (servidores de juegos, VPS, alojamiento web, correo, bases de datos, nombres de dominio). Completa las <a href="{url:terms}">condiciones de uso</a>.</p>'],
        ['title' => 'Contenidos prohibidos', 'body' => '
            <ul>
              <li>contenidos ilícitos: abuso sexual infantil, apología del terrorismo, incitación al odio, vulneración de la intimidad, falsificación y difusión de obras sin derechos;</li>
              <li>phishing, sitios falsos, programas maliciosos y su distribución;</li>
              <li>venta de cuentas, datos personales o medios de pago robados.</li>
            </ul>'],
        ['title' => 'Red y seguridad', 'body' => '
            <ul>
              <li>ataques de denegación de servicio, «booters» y «stressers», incluso como prueba sin el acuerdo escrito del objetivo;</li>
              <li>escaneo de puertos o vulnerabilidades, intentos de intrusión, fuerza bruta;</li>
              <li>suplantación de IP, relés abiertos, proxys o VPN públicos usados para ocultar actividades prohibidas.</li>
            </ul>'],
        ['title' => 'Correo', 'body' => '
            <ul>
              <li>envío de correos no solicitados, compra o alquiler de listas de direcciones;</li>
              <li>boletines sin consentimiento previo ni enlace de baja operativo;</li>
              <li>superar deliberadamente los límites de envío de la oferta.</li>
            </ul>'],
        ['title' => 'Recursos', 'body' => '
            <ul>
              <li>minería de criptomonedas sin acuerdo escrito previo;</li>
              <li>uso que sature de forma duradera los recursos compartidos en perjuicio de otros clientes;</li>
              <li>en los servidores de juegos: software ajeno al juego o bot alojado, reventa no autorizada.</li>
            </ul>'],
        ['title' => 'Juegos en línea', 'body' => '
            <p>Las normas de los editores (condiciones de uso de los juegos, licencias como las de Minecraft o FiveM) se aplican a los servidores alojados. Está prohibido distribuir trampas o contenidos extraídos ilegalmente.</p>'],
        ['title' => 'Notificación y medidas', 'body' => '
            <p>Cualquier abuso puede notificarse en la página <a href="{url:abuse}">denunciar abuso</a> o a abuse@artaun.fr. Según su gravedad, podemos pedir una corrección, limitar o suspender el servicio afectado o cerrar la cuenta, y transmitir la información requerida a las autoridades.</p>'],
    ],
],

'doc.dpa' => [
    'title'   => 'Acuerdo de tratamiento de datos',
    'eyebrow' => 'RGPD — artículo 28',
    'updated' => 'Actualizado el 24 de octubre de 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Partes y objeto', 'body' => '
            <p>Cuando el Cliente aloja datos personales en nuestros servicios (sitios web, buzones, bases de datos, servidores), actúa como responsable y Artaun Hosting como encargado del tratamiento. Este acuerdo forma parte del contrato y se aplica automáticamente a todo servicio.</p>'],
        ['title' => 'Instrucciones', 'body' => '
            <p>Artaun solo trata estos datos para prestar el servicio contratado (almacenamiento, copia de seguridad, transmisión, seguridad) y según las instrucciones del Cliente dadas desde el área de cliente o por escrito. Artaun no consulta el contenido alojado, salvo petición del Cliente o necesidad de seguridad.</p>'],
        ['title' => 'Confidencialidad y seguridad', 'body' => '
            <p>Las personas autorizadas a intervenir están sujetas a confidencialidad. Artaun aplica medidas adecuadas: aislamiento de los servicios, cifrado de conexiones y secretos, control y registro de los accesos de administración, actualizaciones de seguridad, supervisión permanente, copias de seguridad según la oferta.</p>'],
        ['title' => 'Subencargados', 'body' => '
            <p>El Cliente autoriza los subencargados necesarios para el servicio: socio de centro de datos (Francia), Netrix (filtrado anti-DDoS del tráfico de red), Amazon Web Services (relé de algunos correos, Unión Europea). Cualquier cambio de esta lista se publica en esta página; el Cliente puede oponerse rescindiendo el servicio afectado.</p>'],
        ['title' => 'Asistencia al Cliente', 'body' => '
            <p>Artaun ayuda al Cliente, en la medida de lo posible, a responder a las solicitudes de los interesados y a realizar sus evaluaciones de impacto, en particular mediante las herramientas del área de cliente (exportaciones, supresión, registros).</p>'],
        ['title' => 'Violación de datos', 'body' => '
            <p>Artaun notifica al Cliente cualquier violación de datos personales que le afecte sin dilación indebida y, a más tardar, 48 horas después de tener conocimiento de ella, con la información disponible.</p>'],
        ['title' => 'Fin del servicio', 'body' => '
            <p>Al finalizar el servicio, el Cliente recupera sus datos durante el periodo pagado; tras el periodo de gracia, los datos se eliminan, copias de seguridad incluidas, salvo obligación legal de conservación.</p>'],
        ['title' => 'Auditoría', 'body' => '
            <p>Artaun pone a disposición del Cliente la información necesaria para demostrar el cumplimiento de estas obligaciones. Las solicitudes de auditoría se dirigen a support@artaun.fr.</p>'],
    ],
],

];
