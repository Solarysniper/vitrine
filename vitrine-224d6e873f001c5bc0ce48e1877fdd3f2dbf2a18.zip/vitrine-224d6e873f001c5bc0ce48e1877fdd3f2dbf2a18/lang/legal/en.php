<?php
/** Legal documents — English translation. The French version prevails. */
$note = 'This translation is provided for convenience. In the event of any discrepancy, the French version of this document prevails.';
return [

'doc.legal-notice' => [
    'title'   => 'Legal notice',
    'eyebrow' => 'Legal information',
    'updated' => 'Last modified: 24 October 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Site publisher', 'body' => '
            <p>Pursuant to article 6 of French act no. 2004-575 of 21 June 2004 on confidence in the digital economy:</p>
            <dl class="def">
              <div><dt>Name</dt><dd>Artaun Hosting</dd></div>
              <div><dt>Legal form</dt><dd>Registered non-profit association (French act of 1 July 1901)</dd></div>
              <div><dt>SIRET</dt><dd>104 908 496 00011</dd></div>
              <div><dt>RNA</dt><dd>W523005685</dd></div>
              <div><dt>Registered office</dt><dd>1 rue des Aziaux, 52410 Eurville-Bienville, France</dd></div>
              <div><dt>VAT</dt><dd>Not applicable, article 293 B of the French General Tax Code</dd></div>
              <div><dt>Publication director</dt><dd>Mr Nolhan Lefevre-Menu, president</dd></div>
              <div><dt>Contact</dt><dd>support@artaun.fr · abuse: abuse@artaun.fr</dd></div>
            </dl>'],
        ['title' => 'Hosting', 'body' => '
            <p>This website and the client area are hosted by Artaun Hosting (details above) on its own infrastructure at the Equinix PA5 datacenter (Aubervilliers, France), with the support of its datacenter partner Qoriz Hosting. Traffic is filtered against denial-of-service attacks (layers 3, 4 and 7) by our mitigation partner Netrix before it reaches our servers.</p>'],
        ['title' => 'Intellectual property', 'body' => '
            <p>The code, texts, logos and graphics of this site are protected by the French Intellectual Property Code. Game names and artwork belong to their respective publishers and are only used to indicate the compatibility of our offers.</p>'],
        ['title' => 'Cookies', 'body' => '
            <p>This site only sets cookies required for it to work (language, theme, banner choice). Details are given in our <a href="{url:cookies}">cookie policy</a>.</p>'],
        ['title' => 'Contractual documents', 'body' => '
            <p>Use of our services is governed by the <a href="{url:terms}">terms of use</a>, the <a href="{url:sales}">terms of sale</a>, the <a href="{url:aup}">acceptable use policy</a>, the <a href="{url:privacy}">privacy policy</a> and, for the data you host, the <a href="{url:dpa}">data processing agreement</a>.</p>'],
    ],
],

'doc.terms' => [
    'title'   => 'Terms of use',
    'eyebrow' => 'Rules for using our services',
    'updated' => 'Ref. CGU-2026-V3 · Updated 23 October 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Purpose and acceptance', 'body' => '
            <p>These terms govern access to and use of artaun.fr, the client area (clients.artaun.fr) and all services provided by Artaun Hosting ("Artaun"). Creating an account means you accept these terms, the <a href="{url:sales}">terms of sale</a> and the <a href="{url:aup}">acceptable use policy</a>.</p>'],
        ['title' => 'Client account', 'body' => '
            <p>You must be an adult, or have the consent of your legal guardian, and provide accurate information. You are responsible for keeping your credentials confidential; we recommend enabling two-factor authentication. Report any unauthorised use to support@artaun.fr without delay.</p>
            <p>An account may only be shared through the "sub-users" feature. Creating multiple accounts to circumvent a suspension or to use a trial offer several times is forbidden.</p>'],
        ['title' => 'Hosting provider status', 'body' => '
            <p>Artaun acts as a hosting provider within the meaning of article 6 of French act no. 2004-575. We do not check in advance the content and programs you deploy, for which you are solely responsible. We promptly remove or disable access to manifestly unlawful content reported to us (<a href="{url:abuse}">abuse report</a> page).</p>'],
        ['title' => 'Use of resources', 'body' => '
            <p>Forbidden uses are detailed in the <a href="{url:aup}">acceptable use policy</a>, in particular: unlawful content, attacks and scans, unsolicited email, cryptocurrency mining without written consent, and use that abnormally saturates shared resources.</p>'],
        ['title' => 'Availability and backups', 'body' => '
            <p>We use reasonable means to ensure continuity of service (24/7 monitoring, public status page status.artaun.fr) but cannot guarantee uninterrupted availability. Maintenance may be necessary and is announced in advance whenever possible.</p>
            <p>Backups are offered depending on the plan (scheduled backups in the client area). You remain responsible for keeping your own copies of important data.</p>'],
        ['title' => 'Suspension', 'body' => '
            <p>We may suspend a service, after informing you except in an emergency, in the event of a breach of these terms, a risk to the security of the infrastructure or of other clients, or at the request of an authority. Where possible, the suspension is limited to the service concerned and lifted as soon as the cause has disappeared.</p>'],
        ['title' => 'Automated assistants', 'body' => '
            <p>The site and the client area offer a conversational assistant based on an artificial intelligence model. Its answers are indicative only: our terms and the information in your client area prevail. Sensitive actions suggested by the client-area assistant (restart, file changes…) are only carried out after your explicit confirmation.</p>'],
        ['title' => 'Changes and governing law', 'body' => '
            <p>We may amend these terms; any substantial change is notified to you by email at least fifteen days before it takes effect. These terms are governed by French law.</p>'],
    ],
],

'doc.sales' => [
    'title'   => 'Terms of sale',
    'eyebrow' => 'Sales contract',
    'updated' => 'Ref. CGV-2026-V2 · Updated 23 October 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Seller and scope', 'body' => '
            <p>These terms apply to any order placed with Artaun Hosting, registered association, SIRET 104 908 496 00011, 1 rue des Aziaux, 52410 Eurville-Bienville, France, support@artaun.fr ("Artaun"), by a consumer or business client ("the Client"). Provisions specific to consumers do not apply to business clients.</p>'],
        ['title' => 'Offers and features', 'body' => '
            <p>The essential features of each offer (processor, memory, storage, limits, options) are presented on artaun.fr and repeated on the order page of the client area before payment. Offers are available within the limits of available capacity.</p>'],
        ['title' => 'Prices', 'body' => '
            <p>Prices are shown in euros, all taxes included (VAT not applicable, article 293 B of the French General Tax Code). The price of a longer term (3, 6 or 12 months) includes the displayed discount. The applicable price is the one displayed when ordering; if our prices change, the price of an active service only changes at renewal, after at least one month\'s notice.</p>'],
        ['title' => 'Order', 'body' => '
            <p>Orders are placed from the "Order" page of the client area: choice of plan and term, full summary (price, possible fees, discount, total), acceptance of these terms, then payment. The order is final once payment is confirmed; an invoice is immediately available in the client area.</p>'],
        ['title' => 'Payment', 'body' => '
            <p>Payment is made by card (Stripe), PayPal, account balance or cryptocurrency depending on the methods offered. Card payments are processed by the payment provider: Artaun never receives or stores card numbers. A card saved by the Client may be used to pay renewal invoices if the Client has chosen so.</p>'],
        ['title' => 'Delivery', 'body' => '
            <p>Services are made available automatically after payment, usually within minutes, once any configuration choices have been made. If delivery is impossible within 72 hours, the Client may cancel the order and receive a full refund.</p>'],
        ['title' => 'Term, renewal and termination', 'body' => '
            <p>Each service is subscribed for the chosen term (1, 3, 6 or 12 months) and is not renewed without payment: a renewal invoice is issued before the due date and a reminder is sent. The Client may request termination of a service at any time from the client area; it takes effect at the end of the paid period, free of charge.</p>
            <p>If payment is not made by the due date, the service is suspended, then deleted with its data after the grace period shown in the client area. We advise you to retrieve your data before the due date.</p>'],
        ['title' => 'Right of withdrawal (consumers)', 'body' => '
            <p>Consumer Clients have fourteen days from subscription to withdraw, without giving any reason, by writing to support@artaun.fr or through a ticket (articles L221-18 et seq. of the French Consumer Code). The refund is made within fourteen days using the same means of payment.</p>
            <p>When the Client has requested that the service start before the end of this period, as is the case with immediate delivery, the Client owes an amount proportional to the service provided until withdrawal (article L221-25). Domain names, registered with a registry as soon as they are ordered, cannot be withdrawn once registered (article L221-28).</p>'],
        ['title' => 'Liability', 'body' => '
            <p>Artaun has an obligation of means. It is not liable for damage caused by the Client, a third party or force majeure. For business clients, Artaun\'s liability is limited to the amount paid for the service concerned during the last three months and excludes indirect damage. These limitations do not apply to consumers in the event of gross negligence or personal injury.</p>'],
        ['title' => 'Legal warranties', 'body' => '
            <p>Consumer Clients benefit from the legal warranty of conformity for digital content and services (articles L224-25-12 et seq. of the French Consumer Code): in the event of a lack of conformity, they may obtain that the service be brought into conformity or, failing that, a price reduction or termination of the contract.</p>'],
        ['title' => 'Complaints and mediation', 'body' => '
            <p>Any complaint can be sent to support (ticket or support@artaun.fr); we reply within fifteen days. In the event of a persistent disagreement, consumer Clients may use a consumer mediator free of charge (article L612-1 of the French Consumer Code) as well as the European online dispute resolution platform.</p>'],
        ['title' => 'Governing law', 'body' => '
            <p>These terms are governed by French law. Failing an amicable settlement, disputes are brought before the competent courts; consumers may refer to the court of their place of residence.</p>'],
    ],
],

'doc.privacy' => [
    'title'   => 'Privacy policy',
    'eyebrow' => 'Data protection',
    'updated' => 'Version 2.0 · Updated 24 October 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Data controller', 'body' => '
            <p>Artaun Hosting, registered association, 1 rue des Aziaux, 52410 Eurville-Bienville, France, is the controller of the processing described here. Contact for any question about your data: support@artaun.fr.</p>
            <p>For the data you host on our services, you are the controller and Artaun acts as processor (see the <a href="{url:dpa}">data processing agreement</a>).</p>'],
        ['title' => 'Data processed', 'body' => '
            <ul>
              <li><strong>Account</strong>: first and last name, email, postal address, phone (optional), language;</li>
              <li><strong>Billing</strong>: orders, invoices, payment method used (never the full card number);</li>
              <li><strong>Security</strong>: IP addresses and login logs, devices, failed attempts, two-factor authentication;</li>
              <li><strong>Support</strong>: tickets, exchanges with the assistant or an advisor;</li>
              <li><strong>Services</strong>: technical information required for operation (server IP addresses, resource metrics, technical logs).</li>
            </ul>'],
        ['title' => 'Purposes and legal bases', 'body' => '
            <ul>
              <li>providing the services ordered, billing and support — <em>performance of the contract</em>;</li>
              <li>keeping invoices — <em>legal obligation</em>;</li>
              <li>securing accounts and infrastructure, preventing fraud, multiple accounts and abuse — <em>legitimate interest</em>;</li>
              <li>informing you of incidents and due dates — <em>performance of the contract</em>;</li>
              <li>answering through the conversational assistant — <em>legitimate interest</em>; you can ask for a human advisor at any time.</li>
            </ul>'],
        ['title' => 'Recipients and providers', 'body' => '
            <p>Your data is never sold. It is only shared with the providers we need, each for its own task:</p>
            <ul>
              <li><strong>Stripe</strong> and <strong>PayPal</strong>: online payment;</li>
              <li><strong>Netrix</strong>: anti-DDoS filtering of network traffic (IP addresses, request headers, not kept beyond analysis);</li>
              <li><strong>Google</strong> (Gemini model): generating the assistant\'s answers from the messages you send it; sign-in with a Google account if you choose it;</li>
              <li><strong>Discord</strong>: forwarding your messages to our team when you ask for a human advisor, and sign-in with Discord if you choose it;</li>
              <li><strong>Amazon Web Services</strong> (Stockholm region): relay for sending some emails;</li>
              <li><strong>proxycheck.io</strong>: checking the login IP address to fight fraud;</li>
              <li><strong>OpenProvider</strong>: domain name registration (data sent to registries and the WHOIS directory according to their rules);</li>
              <li>our datacenter partner, for the physical hosting of the servers in France.</li>
            </ul>
            <p>Some of these providers are established outside the European Union (notably in the United States); transfers are governed by the European Commission\'s standard contractual clauses or the EU–US Data Privacy Framework.</p>'],
        ['title' => 'Retention periods', 'body' => '
            <ul>
              <li>account and services: for the duration of the contractual relationship, then three years after the last contact, unless you object;</li>
              <li>invoices and accounting records: ten years;</li>
              <li>login and security logs: one year;</li>
              <li>conversations with the website assistant: thirty days; tickets: three years after closure;</li>
              <li>data of a deleted service: erased at the end of the grace period, backups included within the following days.</li>
            </ul>'],
        ['title' => 'Security', 'body' => '
            <p>Encrypted connections (HTTPS), hashed passwords, two-factor authentication available, encrypted technical secrets, limited and logged administrative access, continuous monitoring of the infrastructure. Artaun only accesses the content of your servers at your request (ticket) or for security reasons.</p>'],
        ['title' => 'Your rights', 'body' => '
            <p>You have the rights of access, rectification, erasure, restriction, objection and portability. A copy of your data can be downloaded from the "Data" tab of the client-area settings. To exercise your rights: support@artaun.fr. You may lodge a complaint with the CNIL (www.cnil.fr).</p>'],
        ['title' => 'Minors', 'body' => '
            <p>Our services are intended for adults or minors with the consent of their legal guardian. Minors under fifteen cannot create an account without such consent.</p>'],
        ['title' => 'Changes', 'body' => '
            <p>This policy may change; the update date is shown at the top of the page. You are informed by email of any significant change.</p>'],
    ],
],

'doc.cookies' => [
    'title'   => 'Cookie policy',
    'eyebrow' => 'Trackers',
    'updated' => 'Updated 24 October 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Principle', 'body' => '
            <p>We use no third-party analytics, no advertising and no embedded social networks. Only cookies required for operation are set; they are exempt from consent (article 82 of the French Data Protection Act).</p>'],
        ['title' => 'artaun.fr website', 'body' => '
            <dl class="def">
              <div><dt>artaun_lang</dt><dd>chosen language — 1 year</dd></div>
              <div><dt>artaun_theme</dt><dd>light or dark theme — 1 year</dd></div>
              <div><dt>artaun_cookies</dt><dd>your choice regarding the information banner — 6 months</dd></div>
              <div><dt>Assistant session</dt><dd>browser local storage used to continue a conversation — until it is closed</dd></div>
            </dl>'],
        ['title' => 'Client area', 'body' => '
            <dl class="def">
              <div><dt>Session</dt><dd>keeps you signed in and protects forms (CSRF) — session duration</dd></div>
              <div><dt>Remember me</dt><dd>automatic sign-in if you asked for it — until you sign out (400 days at most)</dd></div>
              <div><dt>Preferences</dt><dd>language, display currency, theme — 1 year</dd></div>
              <div><dt>Referral</dt><dd>referral code tracked during sign-up — 30 days</dd></div>
            </dl>'],
        ['title' => 'Your choices', 'body' => '
            <p>You can delete or block cookies in your browser settings; the site remains usable but your preferences will no longer be remembered, and signing in to the client area requires the session cookie.</p>'],
    ],
],

'doc.aup' => [
    'title'   => 'Acceptable use policy',
    'eyebrow' => 'Allowed and forbidden uses',
    'updated' => 'Updated 23 October 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Purpose', 'body' => '
            <p>This policy sets out the forbidden uses on all our services (game servers, VPS, web hosting, email, databases, domain names). It supplements the <a href="{url:terms}">terms of use</a>.</p>'],
        ['title' => 'Forbidden content', 'body' => '
            <ul>
              <li>unlawful content: child sexual abuse material, terrorism advocacy, incitement to hatred, invasion of privacy, counterfeiting and distribution of works without rights;</li>
              <li>phishing, fake websites, malware and its distribution;</li>
              <li>sale of stolen accounts, personal data or means of payment.</li>
            </ul>'],
        ['title' => 'Network and security', 'body' => '
            <ul>
              <li>denial-of-service attacks, "booters" and "stressers", including as tests without the written consent of the target;</li>
              <li>port or vulnerability scanning, intrusion attempts, brute force;</li>
              <li>IP spoofing, open relays, public proxies or VPNs used to hide forbidden activities.</li>
            </ul>'],
        ['title' => 'Email', 'body' => '
            <ul>
              <li>sending unsolicited email, buying or renting address lists;</li>
              <li>newsletters without prior consent or a working unsubscribe link;</li>
              <li>deliberately exceeding the sending limits of the plan.</li>
            </ul>'],
        ['title' => 'Resources', 'body' => '
            <ul>
              <li>cryptocurrency mining without prior written consent;</li>
              <li>use that durably saturates shared resources to the detriment of other clients;</li>
              <li>on game servers: software unrelated to the hosted game or bot, unauthorised resale.</li>
            </ul>'],
        ['title' => 'Online games', 'body' => '
            <p>Publishers\' rules (game terms of use, licences such as those of Minecraft or FiveM) apply to hosted servers. Distributing cheats or illegally extracted content is forbidden.</p>'],
        ['title' => 'Reporting and measures', 'body' => '
            <p>Any abuse can be reported on the <a href="{url:abuse}">abuse report</a> page or to abuse@artaun.fr. Depending on its severity, we may ask for a correction, restrict or suspend the service concerned, or close the account, and pass the required information on to the authorities.</p>'],
    ],
],

'doc.dpa' => [
    'title'   => 'Data processing agreement',
    'eyebrow' => 'GDPR — article 28',
    'updated' => 'Updated 24 October 2026',
    'note'    => $note,
    'sections' => [
        ['title' => 'Parties and purpose', 'body' => '
            <p>When the Client hosts personal data on our services (websites, mailboxes, databases, servers), the Client acts as controller and Artaun Hosting as processor. This agreement is part of the contract and applies automatically to every service.</p>'],
        ['title' => 'Instructions', 'body' => '
            <p>Artaun only processes this data to provide the service ordered (storage, backup, transmission, security) and according to the Client\'s instructions given through the client area or in writing. Artaun does not look at hosted content, except at the Client\'s request or for security reasons.</p>'],
        ['title' => 'Confidentiality and security', 'body' => '
            <p>Persons authorised to intervene are bound by confidentiality. Artaun implements appropriate measures: isolation of services, encryption of connections and secrets, control and logging of administrative access, security updates, continuous monitoring, backups depending on the plan.</p>'],
        ['title' => 'Sub-processors', 'body' => '
            <p>The Client authorises the sub-processors required for the service: datacenter partner (France), Netrix (anti-DDoS filtering of network traffic), Amazon Web Services (relay for some emails, European Union). Any change to this list is published on this page; the Client may object by terminating the service concerned.</p>'],
        ['title' => 'Assistance to the Client', 'body' => '
            <p>Artaun helps the Client, as far as possible, to respond to data subject requests and to carry out impact assessments, in particular through the client-area tools (exports, deletion, logs).</p>'],
        ['title' => 'Data breach', 'body' => '
            <p>Artaun notifies the Client of any personal data breach concerning it without undue delay and at the latest 48 hours after becoming aware of it, with the information available.</p>'],
        ['title' => 'End of service', 'body' => '
            <p>At the end of the service, the Client retrieves its data during the paid period; after the grace period, the data is deleted, backups included, unless the law requires it to be kept.</p>'],
        ['title' => 'Audit', 'body' => '
            <p>Artaun makes available to the Client the information needed to demonstrate compliance with these obligations. Audit requests are sent to support@artaun.fr.</p>'],
    ],
],

];
