<?php
/**
 * Artaun Hosting — slugs d'URL (es).
 * Les TEXTES du site vivent désormais dans lang/content/*.json (un fichier
 * par page, les 4 langues dans chaque clé) : c'est là qu'il faut éditer un
 * texte, jamais ici. Ce fichier ne garde que le routage (slug par langue
 * pour chaque produit / page), qui doit rester en PHP pour l'aiguillage.
 */
return [

'_slugs' => [
    'web-hosting'     => 'alojamiento-web',
    'mail-pro'        => 'mail-pro',
    'web-reseller'    => 'alojamiento-revendedor',
    'vps-linux'       => 'vps-linux',
    'vps-kvm'         => 'vps-kvm',
    'vps-windows'     => 'vps-windows',
    'vps-pterodactyl' => 'vps-pterodactyl',
    'reseller-vps'    => 'revendedor-vps',
    'ip-addon'        => 'ip-adicional',
    'minecraft'       => 'servidor-minecraft',
    'fivem'           => 'servidor-fivem',
    'redm'            => 'servidor-redm',
    'nova-life'       => 'servidor-nova-life',
    'garrys-mod'      => 'servidor-garrys-mod',
    'hytale'          => 'servidor-hytale',
    'beammp'          => 'servidor-beammp',
    'ets2'            => 'servidor-euro-truck-simulator-2',
    'cs2'             => 'servidor-counter-strike-2',
    'rust'            => 'servidor-rust',
    'ark'             => 'servidor-ark',
    'palworld'        => 'servidor-palworld',
    'seven-days'      => 'servidor-7-days-to-die',
    'bots'            => 'bots-discord',
    'games'           => 'servidores-de-juegos',
    'vps'             => 'vps',
    'web'             => 'alojamiento',
    'revendeurs'      => 'revendedores',
    'acces-rapide'    => 'acceso-rapido',
    'status'          => 'estado',
    'contact'         => 'contacto',
    'legal-notice'    => 'aviso-legal',
    'terms'           => 'condiciones-de-uso',
    'sales'           => 'condiciones-de-venta',
    'privacy'         => 'privacidad',
    'cookies'         => 'cookies',
    'aup'             => 'uso-aceptable',
    'dpa'             => 'tratamiento-de-datos',
    'abuse'           => 'denunciar-abuso',
    'students'        => 'ofertas-estudiantes',
    'domains'         => 'dominios',
    'docs'            => 'docs',
    'blog'            => 'blog',
    'team'            => 'equipo',
    'migration'       => 'migracion',
    'soon'            => 'proximamente',
],

];
