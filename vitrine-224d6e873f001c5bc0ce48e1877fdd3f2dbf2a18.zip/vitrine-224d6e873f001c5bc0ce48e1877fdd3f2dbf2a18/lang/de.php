<?php
/**
 * Artaun Hosting — slugs d'URL (de).
 * Les TEXTES du site vivent désormais dans lang/content/*.json (un fichier
 * par page, les 4 langues dans chaque clé) : c'est là qu'il faut éditer un
 * texte, jamais ici. Ce fichier ne garde que le routage (slug par langue
 * pour chaque produit / page), qui doit rester en PHP pour l'aiguillage.
 */
return [

'_slugs' => [
    'web-hosting'     => 'webhosting',
    'mail-pro'        => 'mail-pro',
    'web-reseller'    => 'reseller-hosting',
    'vps-linux'       => 'linux-vps',
    'vps-kvm'         => 'kvm-vps',
    'vps-windows'     => 'windows-vps',
    'vps-pterodactyl' => 'pterodactyl-vps',
    'reseller-vps'    => 'vps-reseller',
    'ip-addon'        => 'zusatz-ip',
    'minecraft'       => 'minecraft-server',
    'fivem'           => 'fivem-server',
    'redm'            => 'redm-server',
    'nova-life'       => 'nova-life-server',
    'garrys-mod'      => 'garrys-mod-server',
    'hytale'          => 'hytale-server',
    'beammp'          => 'beammp-server',
    'ets2'            => 'euro-truck-simulator-2-server',
    'cs2'             => 'counter-strike-2-server',
    'rust'            => 'rust-server',
    'ark'             => 'ark-server',
    'palworld'        => 'palworld-server',
    'seven-days'      => '7-days-to-die-server',
    'bots'            => 'discord-bots',
    'games'           => 'gameserver',
    'vps'             => 'vps',
    'web'             => 'hosting',
    'revendeurs'      => 'reseller',
    'acces-rapide'    => 'schnellzugriff',
    'status'          => 'status',
    'contact'         => 'kontakt',
    'legal-notice'    => 'impressum',
    'terms'           => 'nutzungsbedingungen',
    'sales'           => 'verkaufsbedingungen',
    'privacy'         => 'datenschutz',
    'cookies'         => 'cookies',
    'aup'             => 'nutzungsrichtlinie',
    'dpa'             => 'auftragsverarbeitung',
    'abuse'           => 'missbrauch-melden',
    'students'        => 'studentenangebote',
    'domains'         => 'domains',
    'docs'            => 'docs',
    'blog'            => 'blog',
    'team'            => 'team',
    'migration'       => 'umzug',
    'soon'            => 'demnaechst',
],

];
