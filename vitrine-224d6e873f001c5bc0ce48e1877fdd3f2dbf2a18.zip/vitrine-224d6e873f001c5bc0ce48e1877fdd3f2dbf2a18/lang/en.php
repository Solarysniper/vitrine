<?php
/**
 * Artaun Hosting — slugs d'URL (en).
 * Les TEXTES du site vivent désormais dans lang/content/*.json (un fichier
 * par page, les 4 langues dans chaque clé) : c'est là qu'il faut éditer un
 * texte, jamais ici. Ce fichier ne garde que le routage (slug par langue
 * pour chaque produit / page), qui doit rester en PHP pour l'aiguillage.
 */
return [

'_slugs' => [
    'web-hosting'     => 'web-hosting',
    'mail-pro'        => 'mail-pro',
    'web-reseller'    => 'reseller-hosting',
    'vps-linux'       => 'linux-vps',
    'vps-kvm'         => 'kvm-vps',
    'vps-windows'     => 'windows-vps',
    'vps-pterodactyl' => 'pterodactyl-vps',
    'reseller-vps'    => 'vps-reseller',
    'ip-addon'        => 'extra-ip',
    'minecraft'       => 'minecraft-server',
    'fivem'           => 'fivem-server',
    'redm'            => 'redm-server',
    'nova-life'       => 'nova-life-server',
    'garrys-mod'      => 'garrys-mod-server',
    'hytale'          => 'hytale-server',
    'beammp'          => 'beammp-server',
    'ets2'            => 'euro-truck-simulator-2-server',
    'cs2'             => 'counter-strike-2-server',
    'rust'            => 'rust-server',
    'ark'             => 'ark-server',
    'palworld'        => 'palworld-server',
    'seven-days'      => '7-days-to-die-server',
    'bots'            => 'discord-bots',
    'games'           => 'game-servers',
    'vps'             => 'vps',
    'web'             => 'hosting',
    'revendeurs'      => 'resellers',
    'acces-rapide'    => 'quick-access',
    'status'          => 'status',
    'contact'         => 'contact',
    'legal-notice'    => 'legal-notice',
    'terms'           => 'terms-of-use',
    'sales'           => 'terms-of-sale',
    'privacy'         => 'privacy',
    'cookies'         => 'cookies',
    'aup'             => 'acceptable-use',
    'dpa'             => 'data-processing',
    'abuse'           => 'report-abuse',
    'students'        => 'student-offers',
    'domains'         => 'domains',
    'docs'            => 'docs',
    'blog'            => 'blog',
    'team'            => 'team',
    'migration'       => 'migration',
    'soon'            => 'coming-soon',
],

];
