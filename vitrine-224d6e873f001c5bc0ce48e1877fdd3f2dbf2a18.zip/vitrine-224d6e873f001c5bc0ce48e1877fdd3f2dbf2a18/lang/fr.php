<?php
/**
 * Artaun Hosting — slugs d'URL (fr).
 * Les TEXTES du site vivent désormais dans lang/content/*.json (un fichier
 * par page, les 4 langues dans chaque clé) : c'est là qu'il faut éditer un
 * texte, jamais ici. Ce fichier ne garde que le routage (slug par langue
 * pour chaque produit / page), qui doit rester en PHP pour l'aiguillage.
 */
return [

'_slugs' => [
    'web-hosting'     => 'hebergement-web',
    'mail-pro'        => 'mail-pro',
    'web-reseller'    => 'hebergement-revendeur',
    'vps-linux'       => 'vps-linux',
    'vps-kvm'         => 'vps-kvm',
    'vps-windows'     => 'vps-windows',
    'vps-pterodactyl' => 'vps-pterodactyl',
    'reseller-vps'    => 'revendeur-vps',
    'ip-addon'        => 'ip-supplementaire',
    'minecraft'       => 'serveur-minecraft',
    'fivem'           => 'serveur-fivem',
    'redm'            => 'serveur-redm',
    'nova-life'       => 'serveur-nova-life',
    'garrys-mod'      => 'serveur-garrys-mod',
    'hytale'          => 'serveur-hytale',
    'beammp'          => 'serveur-beammp',
    'ets2'            => 'serveur-euro-truck-simulator-2',
    'cs2'             => 'serveur-counter-strike-2',
    'rust'            => 'serveur-rust',
    'ark'             => 'serveur-ark',
    'palworld'        => 'serveur-palworld',
    'seven-days'      => 'serveur-7-days-to-die',
    'bots'            => 'bots-discord',
    'games'           => 'serveurs-de-jeux',
    'vps'             => 'vps',
    'web'             => 'hebergement',
    'revendeurs'      => 'revendeurs',
    'acces-rapide'    => 'acces-rapide',
    'status'          => 'statut',
    'contact'         => 'contact',
    'legal-notice'    => 'mentions-legales',
    'terms'           => 'conditions-utilisation',
    'sales'           => 'conditions-de-vente',
    'privacy'         => 'confidentialite',
    'cookies'         => 'cookies',
    'aup'             => 'utilisation-acceptable',
    'dpa'             => 'traitement-des-donnees',
    'abuse'           => 'signalement',
    'students'        => 'offres-etudiants',
    'domains'         => 'domaines',
    'docs'            => 'docs',
    'blog'            => 'blog',
    'team'            => 'equipe',
    'migration'       => 'migration',
    'soon'            => 'bientot',
],

];
