# Artaun Hosting — site web

Site multilingue (FR / EN / DE / ES) en PHP, sans framework ni dépendance
externe. Mode clair par défaut, mode sombre au choix du visiteur.

---

## Mise en ligne sur Plesk — 3 étapes

**1. Déposer les fichiers**

Sites web et domaines → **Gestionnaire de fichiers** → ouvrir `httpdocs` →
*Charger* l'archive → clic droit dessus → **Extraire les fichiers**.

Videz `httpdocs` de l'ancien site au préalable, ou déposez d'abord le nouveau
dans un sous-dossier pour comparer.

**2. Vérifier la version de PHP**

Sites web et domaines → **PHP** → version **8.1 minimum** (8.2 ou 8.3 de
préférence). L'extension `curl` doit être active : elle l'est par défaut sur
Plesk.

**3. Ouvrir le site**

`https://votre-domaine.fr/` doit basculer sur `/fr/` et afficher l'accueil.

C'est tout. Le site fonctionne sans configuration : les 156 pages, les quatre
langues, le mode sombre, le mega-menu, la page de statut et les pages juridiques
sont opérationnels dès le premier chargement.

### Si quelque chose cloche

| Symptôme | Cause | Correction |
|---|---|---|
| Erreur 500 | `.htaccess` non pris en compte | Plesk → Apache → cocher « Autoriser les fichiers .htaccess » |
| Page blanche | version de PHP trop ancienne | passer en PHP 8.1+ |
| L'accueil s'affiche mais les autres pages font 404 | `mod_rewrite` inactif | Plesk → Apache → activer `mod_rewrite` |
| Boucle de redirection | règle HTTPS activée sans certificat | vérifier que le bloc « À ACTIVER » du `.htaccess` est bien commenté |

---

## Une fois le site en ligne

### Certificat SSL

Plesk → SSL/TLS → **Let's Encrypt** (gratuit). Une fois le certificat posé,
ouvrez `.htaccess` et retirez les `#` du bloc « À ACTIVER » tout en bas : HTTPS
forcé, suppression du `www`, en-tête HSTS.

### Droits d'écriture

Le dossier `var/` sert de cache à la page de statut. S'il n'est pas accessible en
écriture, la page fonctionne quand même, simplement sans cache. Pour l'activer :

```bash
chmod 755 var var/chat
```

### Formulaires de contact et de signalement

Ils fonctionnent immédiatement : sans webhook configuré, les messages partent par
courriel à `support@artaun.fr`. Pour les recevoir sur Discord à la place, voir la
section « Secrets ».

### Thème

Le site s'ouvre **toujours en mode clair**, quels que soient les réglages du
système du visiteur. À la première visite, une petite carte en bas à gauche
propose de basculer en sombre ; sans réponse, elle s'efface au bout de quatorze
secondes. Le choix est ensuite mémorisé et le bouton de l'en-tête permet de
changer à tout moment.

### Assistant

Le bouton de chat **n'apparaît que si une clé Gemini est configurée**. Sans clé,
pas de widget : mieux vaut aucun assistant qu'un assistant qui ne répond pas.
Si la bulle est absente en bas à droite, c'est donc normal tant que
`ARTAUN_GEMINI_KEY` (ou `gemini_key` dans les secrets) est vide. Elle apparaît
d'elle-même dès que la clé est renseignée, sans rien d'autre à faire.

---

## Secrets

Trois façons de les fournir, de la meilleure à la moins bonne :

1. **Variables d'environnement** — Plesk → PHP → *Paramètres additionnels* :
   `ARTAUN_WEBHOOK_CONTACT`, `ARTAUN_WEBHOOK_ABUSE`, `ARTAUN_GEMINI_KEY`,
   `ARTAUN_BOT_URL`, `ARTAUN_BOT_SECRET`.
2. **Fichier hors racine web** — copier `config/secrets.example.php` en
   `artaun-secrets.php` et le placer **à côté** de `httpdocs`, pas dedans.
3. **`config/secrets.php`** — protégé par `.htaccess`, mais toujours dans
   l'arborescence web. Dépannage uniquement.

> **À faire avant tout.** Les clés de l'ancien site étaient lisibles en clair
> (dossier `notif/` et code source de `chat_ai.php`). Les trois webhooks Discord,
> la clé Gemini et la clé du bot `X7k#mP2@qL9vN4w` doivent être **révoqués et
> régénérés**, pas recopiés. L'ancien `notif/sessions/` contenait des
> conversations clients : ne pas le remettre en ligne.

---

## Organisation des fichiers

```
index.php              Front controller : langue, routage, rendu
sitemap.php            Plan du site généré depuis le catalogue
.htaccess              Réécriture, en-têtes de sécurité, cache

inc/config.php         ► LE FICHIER À MODIFIER : prix, offres, menus, sondes
inc/i18n.php           Traduction, URLs, formats de prix, icônes SVG
inc/secrets.php        Lecture des secrets
inc/head.php           <head>, méta, hreflang, données structurées
inc/header.php         Mega-menu, tiroir mobile, thème, langue
inc/footer.php         Pied de page, bandeau cookies, scripts
inc/chat.php           Widget de l'assistant

lang/fr|en|de|es.php   Textes de l'interface (442 clés, identiques partout)
lang/legal/*.php       Mentions légales, CGU, CGV, confidentialité

pages/                 Gabarits : home, product, category, status, contact…
assets/css/style.css   Toute la mise en forme
assets/js/             theme (anti-flash), app, status, forms, chat
api/                   JSON : statut, contact, signalement, assistant
config/                Secrets (accès HTTP bloqué)
var/                   Cache et sessions de chat (accès HTTP bloqué)
bot/                   Passerelle Discord — À DÉPLOYER AILLEURS, pas dans httpdocs
```

Les pages ne sont pas des fichiers `.html` : dix gabarits produisent les 39 URL
de chaque langue, soit 156 pages. C'est ce qui permet de changer un prix à un
seul endroit.

---

## Modifier le contenu

**Un prix, une offre, une caractéristique** → `inc/config.php`, tableau
`CATALOG`. La modification se propage seule aux quatre langues, aux pages
produits, aux pages catégories, à l'accueil, aux données structurées, au sitemap
et au prompt de l'assistant.

**Créer une offre sans traduire quatre fois** → la clé facultative `'text'` d'un
produit porte ses textes directement dans `inc/config.php` :

```php
'text' => [
    '*'  => [
        'name'    => 'Rust',
        'tagline' => 'Wipe automatisé, plugins Oxide',
        'title'   => 'Hébergement de serveurs Rust',
        'lead'    => 'Des machines taillées pour les gros wipes.',
    ],
    'en' => ['lead' => 'Machines sized for heavy wipes.'],  // facultatif
],
```

`'*'` sert à toutes les langues. Une langue nommée l'emporte sur `'*'` si vous
voulez affiner plus tard. Sans `'text'`, les textes sont cherchés dans
`lang/*.php` comme avant. **Ajouter une offre ne demande donc plus qu'un seul
fichier.** Un exemple complet est en commentaire au-dessus de `CATALOG`.

**Ouvrir un service annoncé « bientôt »** → ajouter le produit dans `CATALOG`
avec sa clé `'text'`, puis dans `MEGA_MENU` remplacer la clé `soon` de l'entrée
par la clé `page`, en gardant le même identifiant.

**Un texte** → `lang/<langue>.php`. Une clé oubliée retombe automatiquement sur
le français : le site ne casse jamais pour une traduction manquante.

**Une langue supplémentaire** → créer `lang/xx.php` et `lang/legal/xx.php`, puis
déclarer la langue dans `LANGS` (`inc/config.php`).

---

## Assistant Artaun

Bouton flottant en bas à droite, dans les quatre langues. Deux points d'entrée :

- `api/chat.php` — relais vers Gemini. **Le prompt système est généré depuis le
  catalogue** : tarifs, caractéristiques, liens et services à venir viennent de
  `inc/config.php`. Un prix modifié est connu de l'assistant à la requête
  suivante. L'ancienne version recopiait tout le catalogue à la main dans une
  chaîne de 4 000 caractères, déjà partiellement périmée.
- `api/chat-session.php` — reprise par un membre de l'équipe : ouverture de
  session, réponses du staff, fermeture.

Quand l'assistant ne peut pas répondre, il renvoie `__ESCALATE__` et le widget
propose de passer à un humain.

### Trois corrections de sécurité par rapport à l'ancienne version

1. **`staff_reply` était ouvert à tous.** Quiconque devinait un identifiant de
   session pouvait injecter un faux message « Support » dans la conversation d'un
   visiteur — donc lui réclamer un mot de passe ou un paiement. L'endpoint exige
   maintenant l'en-tête `x-api-key`, comparé en temps constant.
2. **La clé du bot était en clair dans le code.** Elle passe dans les secrets et
   doit être régénérée des deux côtés.
3. **Les sessions vivaient dans l'arborescence web** avec nom et adresse e-mail
   des visiteurs. Elles sont dans `var/chat/`, hors de portée HTTP, et purgées
   au bout de 30 jours.

La clé Gemini passe par l'en-tête `x-goog-api-key` plutôt que dans l'URL : elle
n'apparaît plus dans les journaux ni dans les en-têtes `Referer`.

### Un changement de comportement

L'ancien prompt demandait à l'assistant de nier être une IA. Le nouveau garde le
white-label — il se présente comme « l'assistant Artaun » et ne détaille pas la
technologie — mais **s'il lui est demandé franchement s'il est une IA, il répond
oui**. Le reste du white-label est intact.

---

## Passerelle Discord (`bot/`)

Service séparé qui relie l'assistant à votre équipe. **Ne pas le laisser dans
`httpdocs`** : le déployer ailleurs, par exemple `/opt/artaun-chat`. Son accès
HTTP est bloqué par précaution s'il y reste.

```bash
cd bot && cp .env.example .env && npm install && npm start
```

`API_KEY` (bot) et `bot_secret` (site) doivent être **la même valeur**, générée
avec `openssl rand -hex 32`. Détails et service systemd dans `bot/README.md`.

Sans cette passerelle, l'assistant fonctionne : il répond simplement qu'il passe
la main, sans ouvrir de conversation avec l'équipe.
