/**
 * Passerelle Discord ↔ site Artaun.
 *
 * Rôle : quand l'assistant du site passe la main, ce service ouvre un fil de
 * discussion Discord. Ce que l'équipe y écrit est renvoyé au site, qui le sert
 * au visiteur.
 *
 * Deux sens de circulation :
 *   site  → bot   POST /notify          (ouverture d'une conversation)
 *   bot   → site  POST /api/chat-session.php   action=staff_reply
 *
 * L'en-tête x-api-key est exigé dans les deux sens. C'est ce qui manquait dans
 * l'ancienne version : l'endpoint staff_reply du site était ouvert, donc
 * n'importe qui pouvait se faire passer pour le support auprès d'un visiteur.
 */

import 'dotenv/config';
import express from 'express';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import {
  Client, GatewayIntentBits, Events, EmbedBuilder, ChannelType,
} from 'discord.js';

const {
  DISCORD_TOKEN,
  DISCORD_CHANNEL_ID,
  SITE_URL = 'https://artaun.fr',
  API_KEY,
  PORT = 25594,
  STAFF_ROLE_ID = '',
} = process.env;

for (const [name, value] of Object.entries({ DISCORD_TOKEN, DISCORD_CHANNEL_ID, API_KEY })) {
  if (!value) {
    console.error(`Variable manquante : ${name}. Copiez .env.example vers .env.`);
    process.exit(1);
  }
}

// --------------------------------------------------------------------------
// Correspondance session ↔ fil Discord, conservée sur disque pour survivre
// à un redémarrage.
// --------------------------------------------------------------------------
const STORE = new URL('./sessions.json', import.meta.url);
let sessions = existsSync(STORE) ? JSON.parse(readFileSync(STORE, 'utf8')) : {};

const save = () => writeFileSync(STORE, JSON.stringify(sessions, null, 2));
const threadOf = (session) => sessions[session]?.thread;
const sessionOf = (threadId) =>
  Object.keys(sessions).find((key) => sessions[key].thread === threadId);

// Une conversation abandonnée n'a pas à rester en mémoire indéfiniment.
setInterval(() => {
  const cutoff = Date.now() - 7 * 864e5;
  let changed = false;
  for (const [key, value] of Object.entries(sessions)) {
    if (value.createdAt < cutoff) { delete sessions[key]; changed = true; }
  }
  if (changed) save();
}, 3600e3);

// --------------------------------------------------------------------------
// Discord
// --------------------------------------------------------------------------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once(Events.ClientReady, (c) => {
  console.log(`Passerelle connectée : ${c.user.tag}`);
});

/** Renvoie un message de l'équipe vers le site. */
async function pushToSite(session, payload) {
  const res = await fetch(`${SITE_URL}/api/chat-session.php`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
    body: JSON.stringify({ action: 'staff_reply', session, ...payload }),
  });
  if (!res.ok) {
    console.error(`Le site a refusé le message (HTTP ${res.status}) — vérifiez bot_secret.`);
  }
  return res.ok;
}

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;
  if (message.channel.type !== ChannelType.PublicThread &&
      message.channel.type !== ChannelType.PrivateThread) return;

  const session = sessionOf(message.channel.id);
  if (!session) return;

  // « close » (ou /close) met fin à la conversation côté visiteur.
  const text = message.content.trim();
  const closing = /^\/?close$/i.test(text);

  const ok = await pushToSite(session, {
    message: closing ? 'close' : text,
    username: message.member?.displayName || message.author.username,
    avatar: message.author.displayAvatarURL({ size: 64 }),
  });

  if (closing && ok) {
    await message.channel.send('Conversation fermée côté visiteur.');
    delete sessions[session];
    save();
    await message.channel.setArchived(true).catch(() => {});
  } else {
    await message.react(ok ? '✅' : '⚠️').catch(() => {});
  }
});

// --------------------------------------------------------------------------
// API appelée par le site
// --------------------------------------------------------------------------
const app = express();
app.use(express.json({ limit: '64kb' }));

app.use((req, res, next) => {
  if (req.get('x-api-key') !== API_KEY) {
    return res.status(401).json({ ok: false, error: 'unauthorized' });
  }
  next();
});

app.post('/notify', async (req, res) => {
  const { session, name = '', email = '', summary = '', type = 'escalade' } = req.body || {};
  if (!session || !/^[\w-]{1,64}$/.test(session)) {
    return res.status(400).json({ ok: false, error: 'invalid_session' });
  }

  try {
    if (threadOf(session)) return res.json({ ok: true, existing: true });

    const channel = await client.channels.fetch(DISCORD_CHANNEL_ID);
    const thread = await channel.threads.create({
      name: `Chat · ${name || 'Visiteur'} · ${session.slice(-6)}`,
      autoArchiveDuration: 1440,
      type: ChannelType.PublicThread,
      reason: `Escalade depuis le site (${type})`,
    });

    const embed = new EmbedBuilder()
      .setTitle('Un visiteur demande un humain')
      .setColor(0x2b46c9)
      .addFields(
        { name: 'Nom', value: name || '—', inline: true },
        { name: 'E-mail', value: email || '—', inline: true },
        { name: 'Session', value: `\`${session}\``, inline: false },
        { name: 'Contexte', value: (summary || '—').slice(0, 1000) },
      )
      .setFooter({ text: 'Écrivez dans ce fil : le visiteur vous lit. « close » termine.' })
      .setTimestamp();

    await thread.send({
      content: STAFF_ROLE_ID ? `<@&${STAFF_ROLE_ID}>` : undefined,
      embeds: [embed],
    });

    sessions[session] = { thread: thread.id, name, email, createdAt: Date.now() };
    save();

    res.json({ ok: true });
  } catch (err) {
    console.error('Ouverture du fil impossible :', err.message);
    res.status(500).json({ ok: false });
  }
});

/**
 * Compatibilité : ancien fonctionnement où le site relevait les messages.
 * Le bot poussant désormais ses réponses, cette route renvoie une liste vide.
 * Laissez bot_poll à false côté site.
 */
app.get('/poll', (req, res) => {
  const session = String(req.query.session || '');
  res.json({ ok: true, messages: [], closed: !sessions[session] });
});

app.get('/health', (req, res) => res.json({ ok: true, sessions: Object.keys(sessions).length }));

app.listen(Number(PORT), () => console.log(`API d'escalade sur le port ${PORT}`));

client.login(DISCORD_TOKEN);
