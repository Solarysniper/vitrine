# Passerelle de chat Artaun ↔ Discord

Ce service relie l'assistant du site à votre équipe. Quand l'assistant ne peut
pas répondre, le visiteur laisse son nom et son adresse ; un fil s'ouvre dans
Discord, et ce que l'équipe y écrit apparaît dans la fenêtre de chat du site.

## Installation

```bash
cd bot
cp .env.example .env      # puis renseigner les valeurs
npm install
npm start
```

En production, à faire tourner en service :

```bash
# systemd
sudo tee /etc/systemd/system/artaun-chat.service > /dev/null <<'UNIT'
[Unit]
Description=Passerelle de chat Artaun
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/artaun-chat
ExecStart=/usr/bin/node index.js
Restart=always
User=artaun

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl enable --now artaun-chat
```

## Configuration côté site

Dans les secrets du site (`artaun-secrets.php` ou variables d'environnement) :

```php
'bot_url'    => 'http://IP_DU_BOT:25594',
'bot_secret' => 'la même valeur que API_KEY ici',
'bot_poll'   => false,
```

`bot_secret` et `API_KEY` doivent être **identiques**. C'est ce qui empêche un
tiers d'injecter un faux message « Support » dans la conversation d'un visiteur.
Générer la valeur avec `openssl rand -hex 32`, jamais à la main.

## Utilisation par l'équipe

- Un fil s'ouvre dans le salon configuré, avec le nom, l'adresse et le résumé de
  la conversation avec l'assistant.
- Écrire dans le fil : le message part chez le visiteur. Une coche ✅ confirme la
  transmission, un ⚠️ signale un refus du site (généralement une clé qui ne
  correspond pas).
- Écrire `close` termine la conversation et archive le fil.

## Sécurité

- Toutes les routes exigent l'en-tête `x-api-key`.
- Le bot n'écoute que dans les fils qu'il a lui-même ouverts.
- La correspondance session ↔ fil est purgée au bout de sept jours ; le site
  purge les conversations au bout de trente.
- Exposer ce service derrière un pare-feu : seule l'IP du serveur web a besoin
  de l'atteindre.

## Vérification

```bash
curl -H "x-api-key: VOTRE_CLE" http://localhost:25594/health
# {"ok":true,"sessions":0}
```
