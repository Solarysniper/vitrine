<?php
/**
 * Artaun Hosting — Front controller.
 * Toutes les URL publiques passent ici via .htaccess :
 *   /fr/                              → accueil français
 *   /en/web-hosting/                  → page produit anglaise
 *   /fr/bientot/rust/                 → page « bientôt disponible »
 *   /fr/docs/                         → accueil de la documentation
 *   /fr/docs/plesk/                   → catégorie de documentation
 *   /fr/docs/plesk/installer-wordpress/ → article de documentation
 *   /fr/blog/                         → blog
 *   /fr/blog/choisir-son-vps/         → article de blog
 */

declare(strict_types=1);

require __DIR__ . '/inc/config.php';
require __DIR__ . '/inc/secrets.php';
require __DIR__ . '/inc/security.php';
require __DIR__ . '/inc/i18n.php';
require __DIR__ . '/inc/content.php';
require __DIR__ . '/inc/pagecache.php';

send_security_headers();
throttle_gc();

// --------------------------------------------------------------------------
// Garde-fou de charge
// --------------------------------------------------------------------------
// Volontairement très large : un visiteur qui parcourt le site rapidement ne
// doit jamais le rencontrer. Le but est d'arrêter un robot qui mitraille des
// centaines de pages par minute — chaque page reconstruit le catalogue, le
// menu et les traductions, c'est le genre de charge qui fait tomber un site
// avant que la bande passante ne pose problème.
if (!throttle('page', 240, 60, 20000)) {
    http_response_code(429);
    header('Content-Type: text/plain; charset=utf-8');
    exit("429 — trop de requêtes. Merci de réessayer dans quelques instants.\n");
}

// Pays du visiteur (Cloudflare ou base locale de nginx) pour la monnaie par défaut et la suggestion de langue côté navigateur :
// les pages étant en cache, l'information passe par un cookie et non par le HTML.
if (visitor_country() !== '') {
    $geoCookie = visitor_country() . '|' . (geo_lang() ?? '');
    if (preg_match('/^[A-Z]{2}\|(fr|en|de|es)?$/', $geoCookie) && ($_COOKIE['artaun_geo'] ?? '') !== $geoCookie) {
        setcookie('artaun_geo', $geoCookie, ['expires' => time() + 7 * 86400, 'path' => '/', 'secure' => true, 'samesite' => 'Lax']);
    }
}

// --------------------------------------------------------------------------
// Langue
// --------------------------------------------------------------------------
$lang = strtolower((string) ($_GET['lang'] ?? ''));

if (!array_key_exists($lang, LANGS)) {
    // Dernier choix explicite du visiteur (cookie posé par le sélecteur), sinon la langue de son pays
    // (en-tête CF-IPCountry de Cloudflare, voir geo_lang()), sinon français. Les robots ne sont jamais
    // redirigés : ils voient l'accueil français à la racine, avec les hreflang vers les autres langues.
    $saved  = (string) ($_COOKIE['artaun_lang'] ?? '');
    $target = array_key_exists($saved, LANGS) ? $saved : (geo_lang() ?? LANG_DEFAULT);

    // Seule la racine EXACTE sert l'accueil. Tout autre chemin sans préfixe
    // de langue (/wp-admin/, /.env, un vieux lien…) arrive aussi ici par la
    // règle « fourre-tout » du .htaccess : lui servir l'accueil en 200
    // créait autant de « soft 404 » aux yeux de Google. Il repart donc vers
    // l'accueil de la langue, comme avant.
    // Découpage littéral plutôt que parse_url() : ce dernier lit « //x »
    // comme un nom d'hôte et renvoie un chemin vide.
    $reqPath = strtok((string) ($_SERVER['REQUEST_URI'] ?? '/'), '?');
    $atRoot  = ($reqPath === '/' || $reqPath === false || $reqPath === '');

    // Pages de l'ancien site encore connues de Google (et qui reçoivent des
    // clics) : redirection permanente vers leur équivalent, pour transmettre
    // leur popularité au lieu de la perdre dans une redirection temporaire.
    $legacy = [
        '/ml.html'  => '/fr/mentions-legales/',
        '/cgu.html' => '/fr/conditions-utilisation/',
        '/cgv.html' => '/fr/conditions-de-vente/',
    ][strtolower((string) $reqPath)] ?? null;
    if ($legacy !== null) {
        header('Location: ' . $legacy, true, 301);
        exit;
    }

    if (!$atRoot || $target !== LANG_DEFAULT) {
        // Chemins construits uniquement à partir de nos constantes : aucune
        // redirection ouverte possible.
        header('Location: ' . ($target === LANG_DEFAULT ? '/' : '/' . $target . '/'), true, 302);
        exit;
    }

    // Sinon la racine SERT l'accueil par défaut, elle ne redirige plus.
    // C'est ce qui permet à Google de trouver le balisage WebSite sur la
    // page d'accueil du domaine et d'afficher « Artaun Hosting » plutôt que
    // « artaun.fr » à côté du favicon. Un robot n'a pas de cookie : il voit
    // donc exactement la même page qu'un nouveau visiteur.
    $lang = LANG_DEFAULT;
}

// /fr/ affichait la même page que la racine : une redirection permanente
// regroupe les signaux sur une seule URL au lieu de compter sur le canonique.
if ($lang === LANG_DEFAULT && trim((string) ($_GET['path'] ?? ''), '/') === ''
    && preg_match('#^/' . LANG_DEFAULT . '/?(\?|$)#', (string) ($_SERVER['REQUEST_URI'] ?? ''))) {
    header('Location: /', true, 301);
    exit;
}

// --------------------------------------------------------------------------
// Cache de page
// --------------------------------------------------------------------------
// Tenté AVANT de charger les traductions et de construire le catalogue :
// sur un succès, rien de tout cela n'est exécuté.
$cacheTarget = page_cache_serve($lang, (string) ($_GET['path'] ?? ''));
if ($cacheTarget === 'served') {
    exit;
}

load_lang($lang);

// --------------------------------------------------------------------------
// Routage
// --------------------------------------------------------------------------
$rawPath = (string) ($_GET['path'] ?? '');

// Un chemin ne contient que des segments d'URL : tout le reste est du bruit
// (tentative de traversée, octet nul, caractère de contrôle). On le refuse
// avant même de chercher une page correspondante.
if (strlen($rawPath) > 300 || preg_match('#(^|/)\.\.?(/|$)#', $rawPath) || preg_match('/[^\p{L}\p{N}\/_-]/u', $rawPath)) {
    $rawPath = '__invalide__';
}

$path     = trim($rawPath, '/');
$segments = $path === '' ? [] : array_slice(explode('/', $path), 0, 4);
$slug     = $segments[0] ?? '';
$page     = resolve_page($slug, $lang);
if ($page === "status") { header("Location: https://status.artaun.fr", true, 301); exit; }

$soonKey    = null;
$docCat     = null;
$docArticle = null;
$blogPost   = null;
$status     = 200;

if ($page === 'soon') {
    $soonKey = $segments[1] ?? null;
    // Une offre annoncée « bientôt » puis lancée : son ancienne URL renvoie
    // définitivement vers la page produit (Google en connaît encore plusieurs).
    $launched = ['reseller-ptero' => 'vps-pterodactyl', 'reseller-web' => 'web-reseller', 'novalife' => 'nova-life'][$soonKey ?? ''] ?? $soonKey;
    if ($launched && isset(CATALOG[$launched])) {
        header('Location: ' . url($launched, $lang), true, 301);
        exit;
    }
    // Seules les offres « bientôt » encore annoncées dans le menu ont une page (Datacenter et Réseau retirés le 25/10/2026).
    $soonLive = array_column(array_merge(...array_values(MEGA_MENU_SOON)), 'soon');
    if (!$soonKey || !has('soon.' . $soonKey . '.title') || !in_array($soonKey, $soonLive, true)) {
        $page = null;
    } elseif (count($segments) > 2) {
        $page = null;
    }

} elseif ($page === 'docs') {
    // /xx/docs/ · /xx/docs/<categorie>/ · /xx/docs/<categorie>/<article>/
    if (count($segments) === 1) {
        $page = 'docs';
    } elseif (count($segments) <= 3) {
        $docCat = doc_cat_from_slug($segments[1], $lang);
        if ($docCat === null) {
            $page = null;
        } elseif (count($segments) === 2) {
            $page = 'docs-category';
        } else {
            $docArticle = content_by_slug('docs', $lang, $docCat, $segments[2]);
            $page = $docArticle ? 'docs-article' : null;
        }
    } else {
        $page = null;
    }

} elseif ($page === 'blog') {
    if (count($segments) === 1) {
        $page = 'blog';
    } elseif (count($segments) === 2) {
        $blogPost = blog_post($lang, $segments[1]);
        $page = $blogPost ? 'blog-post' : null;
    } else {
        $page = null;
    }

} elseif (count($segments) > 1) {
    $page = null; // pas de sous-niveau ailleurs
}

if ($page === null) {
    $page   = '404';
    $status = 404;
    http_response_code(404);
}

$GLOBALS['ARTAUN']['page'] = $page;

// --------------------------------------------------------------------------
// Choix du gabarit
// --------------------------------------------------------------------------
if (isset(CATALOG[$page])) {
    $template = 'product';
    $product  = $page;
} elseif (in_array($page, ['games', 'vps', 'web', 'revendeurs'], true)) {
    $template = 'category';
    $category = $page;
} elseif (in_array($page, ['legal-notice', 'terms', 'sales', 'privacy', 'cookies', 'aup', 'dpa'], true)) {
    $template = 'legal';
} else {
    $template = $page;
}

$file = __DIR__ . '/pages/' . $template . '.php';
if (!is_file($file)) {
    $file   = __DIR__ . '/pages/404.php';
    $status = 404;
    http_response_code(404);
}

// On tamponne le rendu : la même sortie part au visiteur ET au cache.
ob_start();
require __DIR__ . '/inc/head.php';
require __DIR__ . '/inc/header.php';
require $file;
require __DIR__ . '/inc/footer.php';
$html = (string) ob_get_clean();

header('X-Artaun-Cache: miss');
echo $html;

if (is_string($cacheTarget)) {
    page_cache_store($cacheTarget, $html);
}
