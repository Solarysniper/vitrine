<?php
/**
 * Plan du site — généré depuis le catalogue et le contenu, donc jamais périmé.
 *
 * Trois choses le rendent utile plutôt que décoratif :
 *  · chaque URL est déclarée avec ses équivalents dans les trois autres
 *    langues (xhtml:link), ce qui indique explicitement aux moteurs que
 *    /fr/serveur-minecraft/ et /en/minecraft-server/ sont la même page ;
 *  · les dates de dernière modification viennent des fichiers eux-mêmes ;
 *  · la priorité reflète la structure réelle du site, pas un chiffre au
 *    hasard identique partout.
 */

declare(strict_types=1);
require __DIR__ . '/inc/config.php';
require __DIR__ . '/inc/i18n.php';
require __DIR__ . '/inc/content.php';

header('Content-Type: application/xml; charset=utf-8');
header('X-Robots-Tag: noindex');

// --------------------------------------------------------------------------
// Pages statiques du site
// --------------------------------------------------------------------------
$pages = array_merge(
    ['home', 'games', 'vps', 'web', 'revendeurs', 'students', 'domains', 'docs', 'blog'],
    array_keys(CATALOG),
    ['team', 'migration', 'acces-rapide', 'contact', 'abuse', 'legal-notice', 'terms', 'sales', 'privacy', 'cookies', 'aup', 'dpa']
);

$soon = [];
foreach (mega_menu() as $block) {
    foreach ($block['items'] as $item) {
        if (isset($item['soon'])) $soon[] = $item['soon'];
    }
}

$priority = function (string $page): string {
    if ($page === 'home') return '1.0';
    if (in_array($page, ['games', 'vps', 'web', 'revendeurs', 'docs', 'blog', 'domains'], true)) return '0.9';
    if (isset(CATALOG[$page])) return '0.8';
    if (in_array($page, ['legal-notice', 'terms', 'sales', 'privacy', 'cookies', 'aup', 'dpa'], true)) return '0.3';
    return '0.6';
};

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

/**
 * Écrit une entrée par langue, chacune listant les quatre variantes.
 * $urls : ['fr' => '/fr/...', 'en' => '/en/...', ...]
 */
$emit = function (array $urls, string $priority = '0.7', ?string $lastmod = null, string $freq = 'weekly', ?string $image = null): void {
    foreach ($urls as $lang => $path) {
        echo "  <url>\n";
        echo '    <loc>' . htmlspecialchars(SITE_URL . $path, ENT_XML1) . "</loc>\n";
        foreach ($urls as $alt => $altPath) {
            echo '    <xhtml:link rel="alternate" hreflang="' . $alt . '" href="'
               . htmlspecialchars(SITE_URL . $altPath, ENT_XML1) . "\"/>\n";
        }
        echo '    <xhtml:link rel="alternate" hreflang="x-default" href="'
           . htmlspecialchars(SITE_URL . ($urls[LANG_DEFAULT] ?? reset($urls)), ENT_XML1) . "\"/>\n";
        if ($lastmod) echo '    <lastmod>' . htmlspecialchars($lastmod, ENT_XML1) . "</lastmod>\n";
        if ($image) echo '    <image:image><image:loc>' . htmlspecialchars(SITE_URL . strtok($image, '?'), ENT_XML1) . "</image:loc></image:image>\n";
        echo "    <changefreq>$freq</changefreq>\n";
        echo "    <priority>$priority</priority>\n";
        echo "  </url>\n";
    }
};

$langs = array_keys(LANGS);

// --------------------------------------------------------------------------
// Pages du site
// --------------------------------------------------------------------------
load_lang(LANG_DEFAULT);
foreach ($pages as $page) {
    $urls = [];
    foreach ($langs as $lang) $urls[$lang] = url($page, $lang);
    // Fiches de jeu : bannière déclarée (Google Images) et date de la dernière mise à jour du catalogue.
    $emit($urls, $priority($page), isset(CATALOG[$page]) ? date('Y-m-d', (int) @filemtime(__DIR__ . '/var/catalog.json') ?: time()) : null, 'weekly', isset(CATALOG[$page]) ? game_art($page) : null);
}

// Les pages « bientôt disponible » sont en noindex : elles n'ont rien à
// faire dans le plan du site.

// --------------------------------------------------------------------------
// Documentation : catégories puis articles, avec leurs slugs localisés
// --------------------------------------------------------------------------
foreach (array_keys(DOC_CATEGORIES) as $category) {
    // Une catégorie vide n'a pas de page : inutile de la déclarer.
    if (!content_list('docs', LANG_DEFAULT, $category)) continue;

    $urls = [];
    foreach ($langs as $lang) $urls[$lang] = doc_url($category, null, $lang);
    $emit($urls, '0.7');

    foreach (content_list('docs', LANG_DEFAULT, $category) as $key => $article) {
        $urls = [];
        $lastmod = null;
        foreach ($langs as $lang) {
            $slug = content_slug_in('docs', $lang, $category, $key);
            $urls[$lang] = doc_url($category, $slug, $lang);
            if ($lang === LANG_DEFAULT) $lastmod = $article['meta']['updated'] ?? null;
        }
        $emit($urls, '0.6', $lastmod, 'monthly');
    }
}

// --------------------------------------------------------------------------
// Blog
// --------------------------------------------------------------------------
foreach (blog_posts(LANG_DEFAULT) as $post) {
    $urls = [];
    foreach ($langs as $lang) {
        // Seules les traductions réelles : un repli français serait un doublon.
        $own = array_filter(content_list('blog', $lang), fn($a) => $a['key'] === $post['key'] && empty($a['fallback']));
        if (!$own) continue;
        $urls[$lang] = blog_url(content_slug_in('blog', $lang, '', $post['key']), $lang);
    }
    if (!$urls) continue;
    $emit($urls, '0.7', $post['meta']['updated'] ?? $post['meta']['date'] ?? null, 'monthly');
}

echo '</urlset>';
