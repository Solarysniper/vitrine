<?php
/**
 * Modèle de configuration des secrets.
 *
 * À FAIRE AVANT MISE EN LIGNE
 * 1. Copier ce fichier en artaun-secrets.php et le placer UN NIVEAU AU-DESSUS
 *    du DocumentRoot (à côté du dossier httpdocs, pas dedans).
 * 2. Sinon, le renommer en config/secrets.php : le .htaccess du dossier bloque
 *    l'accès HTTP, mais un fichier hors arborescence web reste préférable.
 * 3. Encore mieux : définir ces valeurs en variables d'environnement
 *    (SetEnv dans Apache, ou env[] dans le pool PHP-FPM) et supprimer le fichier.
 *
 * TOUTES ces valeurs étaient lisibles en clair dans l'ancien site (dossier
 * notif/ et code source de chat_ai.php). Elles doivent être RÉVOQUÉES ET
 * RÉGÉNÉRÉES, pas simplement recopiées ici.
 */
return [
    // Webhooks Discord des formulaires
    'webhook_contact' => '',  // https://discord.com/api/webhooks/...
    'webhook_abuse'   => '',  // https://discord.com/api/webhooks/...

    // Assistant
    'gemini_key'      => '',  // clé API Google Gemini

    // Bot Discord qui relaie les escalades vers l'équipe
    'bot_url'         => '',  // ex. http://5.180.34.10:25594
    'bot_secret'      => '',  // clé partagée, en-tête x-api-key — à régénérer
    'bot_poll'        => false, // true seulement si le bot expose /poll (ancien fonctionnement)
];
