Dépose ici les logos réels au format PNG carré, fond transparent,
256x256 conseillé (28x28 minimum). Nom du fichier = nom exact ci-dessous
(minuscules, tirets). Dès qu'un fichier existe, il remplace automatiquement
l'icône dessinée à la main — aucune autre modification nécessaire.

JEUX
----
minecraft.png
fivem.png
redm.png
nova-life.png
garrys-mod.png
hytale.png
beammp.png
ets2.png          (Euro Truck Simulator 2)
cs2.png           (Counter-Strike 2)
rust.png
ark.png
palworld.png
seven-days.png    (7 Days to Die)
bots.png          (Bots Discord — logo Discord par ex.)

WEB / MAIL
----------
web-hosting.png   (ou plesk.png, utilisé en repli commun)
mail-pro.png
web-reseller.png  ("Revendeur Web")
plesk.png         (logo de marque, sert de repli à web-hosting/web-reseller)

VPS / CLOUD
-----------
vps-linux.png
vps-kvm.png
vps-windows.png   (ou windows.png, repli commun)
windows.png       (logo de marque Windows)
linux.png         (logo de marque Linux/Tux, repli commun)

REVENDEURS
----------
vps-pterodactyl.png  ("Revendeur Pterodactyl")
reseller-vps.png     ("Revendeur VPS")
pterodactyl.png      (logo de marque, repli commun)
proxmox.png          (logo de marque, repli commun)

ADDON RÉSEAU
------------
ip-addon.png

Comment ça marche : pour chaque offre, le site cherche d'abord
<clé-produit>.png (ex: rust.png), puis un logo de marque partagé
(ex: linux.png pour vps-linux ET vps-kvm si tu veux réutiliser le même
Tux), et n'affiche l'icône dessinée à la main que si aucun des deux
n'existe. Tu peux donc ne fournir qu'un seul plesk.png ou windows.png
partagé, ou un fichier différent par offre — les deux marchent.
