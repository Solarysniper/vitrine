/* Conseiller Artaun : conversation en flux, fiches d'offres, choix rapides,
   passage à l'équipe. La conversation est gardée pendant la visite
   (sessionStorage) pour suivre le visiteur d'une page à l'autre. */
(function () {
  'use strict';
  var panel = document.getElementById('chat-panel');
  var launcher = document.getElementById('chat-launcher');
  if (!panel || !launcher) return;

  var log = panel.querySelector('[data-chat-log]');
  var form = panel.querySelector('[data-chat-form]');
  var input = panel.querySelector('[data-chat-input]');
  var sendBtn = form.querySelector('.chat-send');
  var quick = panel.querySelector('[data-chat-quick]');
  var escalate = panel.querySelector('[data-chat-escalate]');
  var status = panel.querySelector('[data-chat-status]');
  var badge = launcher.querySelector('[data-chat-badge]');
  var L = JSON.parse(panel.getAttribute('data-labels') || '{}');
  var lang = document.documentElement.lang || 'fr';
  var page = document.documentElement.getAttribute('data-page') || '';
  var KEY = 'artaun-advisor-v2';

  // État : messages {role, content}, fiches d'offres résolues, session humaine.
  var state = { messages: [], offers: {}, session: null };
  var busy = false, poller = null;

  function save() { try { sessionStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }
  function load() {
    try {
      var s = JSON.parse(sessionStorage.getItem(KEY) || 'null');
      if (s && Array.isArray(s.messages)) state = { messages: s.messages.slice(-40), offers: s.offers || {}, session: s.session || null };
    } catch (e) {}
  }

  // ------------------------------------------------------------ rendu
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function inline(s) {
    return esc(s)
      .replace(/\[([^\]]+)\]\(((?:https?:\/\/|\/)[^\s)]+)\)/g, function (_, t, u) {
        var ext = /^https?:\/\//.test(u) && u.indexOf(location.origin) !== 0;
        return '<a href="' + u + '"' + (ext ? ' target="_blank" rel="noopener noreferrer"' : '') + '>' + t + '</a>';
      })
      .replace(/(^|[\s(])(https:\/\/[^\s<)]+)/g, function (_, p, u) { return p + '<a href="' + u + '" target="_blank" rel="noopener noreferrer">' + u + '</a>'; })
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>')
      .replace(/`([^`]+)`/g, '<code>$1</code>');
  }
  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }
  function offerCard(ref) {
    var d = state.offers[ref];
    var card = el('div', 'chat-offer' + (d && d.popular ? ' is-best' : ''));
    if (!d) { card.appendChild(el('div', 'chat-tool', '…')); return card; }
    var head = el('div', 'chat-offer-head');
    var img = document.createElement('img');
    img.src = d.img; img.alt = ''; img.loading = 'lazy';
    img.onerror = function () { img.remove(); };
    head.appendChild(img);
    head.appendChild(el('span', '', '<strong>' + esc(d.product) + ' · ' + esc(d.plan) + '</strong><em>' + (d.trial ? esc(L.trial || '') : (d.popular ? esc(L.recommended || '') : '')) + '</em>'));
    head.appendChild(el('span', 'chat-offer-price', esc(d.price) + '<small>' + esc(L.month || '') + '</small>'));
    card.appendChild(head);
    var ul = el('ul');
    (d.specs || []).forEach(function (s) { ul.appendChild(el('li', '', esc(s))); });
    card.appendChild(ul);
    var actions = el('div', 'chat-offer-actions');
    actions.innerHTML = '<a class="btn btn-primary btn-sm" href="' + esc(d.order) + '" rel="noopener">' + esc(L.order || '') + '</a>'
      + '<a class="btn btn-ghost btn-sm" href="' + esc(d.page) + '">' + esc(L.details || '') + '</a>';
    card.appendChild(actions);
    return card;
  }
  // Texte du conseiller → blocs (paragraphes, listes, titres, tableaux, fiches, choix).
  function rich(text, streaming) {
    var frag = document.createDocumentFragment();
    if (streaming) text = text.replace(/\[\[[^\]]*\]?$/, '');
    text = text.replace(/__ESCALA(?:TE|DE)__/gi, '');
    var bubble = null, list = null, table = null, offers = null, code = null;
    function flush() { list = null; table = null; }
    function ensureBubble() { if (!bubble) { bubble = el('div', 'chat-bubble'); frag.appendChild(bubble); offers = null; } return bubble; }
    text.split('\n').forEach(function (raw) {
      var line = raw.trim();
      var m;
      // Bloc de code ``` … ``` : texte brut, sans mise en forme.
      if (/^```/.test(line)) {
        if (code) { code = null; return; }
        flush();
        var pre = el('pre');
        code = el('code');
        pre.appendChild(code);
        ensureBubble().appendChild(pre);
        return;
      }
      if (code) { code.textContent += (code.textContent ? '\n' : '') + raw.replace(/^\s{0,3}/, ''); return; }
      if ((m = line.match(/^\[\[offre:([a-z0-9-]+:\d{1,2})\]\]$/))) {
        flush();
        if (!offers) { offers = el('div', 'chat-offers'); frag.appendChild(offers); bubble = null; }
        offers.appendChild(offerCard(m[1]));
        return;
      }
      if ((m = line.match(/^\[\[choix:(.+)\]\]$/))) {
        flush(); bubble = null; offers = null;
        var box = el('div', 'chat-choices');
        m[1].split('|').map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 5).forEach(function (c) {
          var b = el('button'); b.type = 'button'; b.textContent = c;
          b.addEventListener('click', function () { send(c); });
          box.appendChild(b);
        });
        frag.appendChild(box);
        return;
      }
      line = line.replace(/\[\[offre:[^\]]*\]\]/g, '').replace(/\[\[choix:[^\]]*\]\]/g, '');
      if (line === '' || /^([-*_])\1{2,}$/.test(line)) { flush(); return; }
      var b = ensureBubble();
      if (/^\|.*\|$/.test(line)) {
        if (/^\|[\s:|-]+\|$/.test(line)) return;
        if (!table) { table = el('table'); b.appendChild(table); }
        var tr = el('tr');
        line.slice(1, -1).split('|').forEach(function (c) { tr.appendChild(el(table.rows.length ? 'td' : 'th', '', inline(c.trim()))); });
        table.appendChild(tr);
        return;
      }
      if ((m = line.match(/^#{1,4}\s+(.*)$/))) { flush(); b.appendChild(el('h4', '', inline(m[1]))); return; }
      if ((m = line.match(/^(?:[-*•])\s+(.*)$/)) || (m = line.match(/^(\d+)[.)]\s+(.*)$/))) {
        var ordered = /^\d/.test(line);
        if (!list || list.tagName !== (ordered ? 'OL' : 'UL')) { list = el(ordered ? 'ol' : 'ul'); b.appendChild(list); }
        list.appendChild(el('li', '', inline(ordered ? m[2] : m[1])));
        return;
      }
      flush();
      b.appendChild(el('p', '', inline(line)));
    });
    return frag;
  }
  function scroll() { log.scrollTop = log.scrollHeight; }
  function addMsg(role, content, who) {
    var wrap = el('div', 'chat-msg is-' + role);
    if (who) { var w = el('span', 'chat-who'); w.textContent = who; wrap.appendChild(w); }
    if (role === 'user' || role === 'system') {
      var bubble = el('div', 'chat-bubble'); bubble.textContent = content; wrap.appendChild(bubble);
    } else {
      wrap.appendChild(rich(content, false));
    }
    log.appendChild(wrap);
    scroll();
    return wrap;
  }
  function typing(on, label) {
    var t = log.querySelector('.chat-typing');
    if (on && !t) {
      t = el('div', 'chat-msg is-bot chat-typing', '<div class="chat-bubble"><i></i><i></i><i></i></div>');
      log.appendChild(t);
    }
    if (t && label) {
      var lab = t.querySelector('.chat-tool') || t.appendChild(el('span', 'chat-tool'));
      lab.textContent = label;
    }
    if (!on && t) t.remove();
    scroll();
  }
  function renderAll() {
    log.querySelectorAll('.chat-msg:not([data-chat-intro])').forEach(function (n) { n.remove(); });
    if (quick) quick.hidden = state.messages.length > 0;
    state.messages.forEach(function (m) { addMsg(m.role === 'user' ? 'user' : (m.role === 'staff' ? 'staff' : (m.role === 'system' ? 'system' : 'bot')), m.content, m.who); });
  }

  // ------------------------------------------------------------ ouverture
  // Mobile : le panneau occupe tout l'écran. On le cale sur la zone réellement visible
  // (visualViewport) pour que le clavier ne cache jamais la zone de saisie, et on
  // fige la page derrière lui.
  var root = document.documentElement;
  var small = window.matchMedia('(max-width: 720px)');
  var touch = window.matchMedia('(pointer: coarse)');
  var vv = window.visualViewport;
  function fit() {
    if (!small.matches || !vv || panel.hidden) {
      panel.style.removeProperty('--chat-h');
      panel.style.removeProperty('--chat-top');
      return;
    }
    panel.style.setProperty('--chat-h', Math.round(vv.height) + 'px');
    panel.style.setProperty('--chat-top', Math.round(vv.offsetTop) + 'px');
    scroll();
  }
  if (vv) { vv.addEventListener('resize', fit); vv.addEventListener('scroll', fit); }
  small.addEventListener ? small.addEventListener('change', fit) : small.addListener(fit);
  // Clavier ouvert : on masque le pied de panneau pour garder de la place à la conversation.
  panel.addEventListener('focusin', function (e) {
    if (touch.matches && /^(INPUT|TEXTAREA)$/.test(e.target.tagName)) panel.classList.add('is-kb');
  });
  panel.addEventListener('focusout', function () { panel.classList.remove('is-kb'); });

  function open(ask) {
    clearTimeout(closeTimer);
    panel.hidden = false;
    fit();
    requestAnimationFrame(function () { panel.classList.add('is-open'); });
    launcher.setAttribute('aria-expanded', 'true');
    launcher.classList.add('is-hidden');
    root.classList.add('chat-lock');
    if (badge) badge.hidden = true;
    scroll();
    // Sur téléphone, focaliser ouvrirait le clavier d'emblée et cacherait la conversation.
    if (ask) send(ask); else if (!touch.matches) setTimeout(function () { input.focus(); }, 50);
  }
  var closeTimer;
  function close() {
    panel.classList.remove('is-open', 'is-kb');
    launcher.setAttribute('aria-expanded', 'false');
    launcher.classList.remove('is-hidden');
    root.classList.remove('chat-lock');
    if (document.activeElement && panel.contains(document.activeElement)) document.activeElement.blur();
    closeTimer = setTimeout(function () { panel.hidden = true; fit(); }, 170);
  }
  launcher.addEventListener('click', function () { open(); });
  panel.querySelector('[data-chat-close]').addEventListener('click', close);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && panel.classList.contains('is-open')) close(); });
  document.querySelectorAll('[data-chat-open]').forEach(function (b) {
    b.addEventListener('click', function () { open(b.getAttribute('data-chat-ask') || ''); });
  });
  panel.querySelector('[data-chat-reset]').addEventListener('click', function () {
    if (busy) return;
    stopPolling();
    state = { messages: [], offers: {}, session: null };
    save();
    escalate.hidden = true; form.hidden = false;
    if (status) status.textContent = L.subtitle || '';
    renderAll();
    if (!touch.matches) input.focus();
  });
  panel.querySelector('[data-chat-human]').addEventListener('click', function () {
    escalate.hidden = false; form.hidden = true;
    escalate.querySelector('input[name="name"]').focus();
  });
  panel.querySelectorAll('[data-chat-suggest]').forEach(function (b) {
    b.addEventListener('click', function () { send(b.textContent); });
  });

  // ------------------------------------------------------------ envoi
  form.addEventListener('submit', function (e) { e.preventDefault(); send(input.value); });
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(input.value); }
  });
  input.addEventListener('input', function () {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  });

  function setBusy(on) { busy = on; sendBtn.disabled = on; }

  function send(text) {
    text = String(text || '').trim();
    if (!text || busy) return;
    if (quick) quick.hidden = true;
    input.value = ''; input.style.height = '';
    var history = state.messages.filter(function (m) { return (m.role === 'user' || m.role === 'assistant') && !m.failed; }).slice(-16)
      .map(function (m) { return { role: m.role, content: m.content }; });
    state.messages.push({ role: 'user', content: text });
    addMsg('user', text);
    save();

    // Conversation avec l'équipe : le message part au bot Discord.
    if (state.session) {
      fetch('/api/chat-session.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'user_message', session: state.session, message: text }) }).catch(function () {});
      return;
    }
    ask(text, history);
  }

  // Une question restée sans réponse ne repart pas dans l'historique suivant.
  function markFailed() {
    for (var i = state.messages.length - 1; i >= 0; i--) {
      if (state.messages[i].role === 'user') { state.messages[i].failed = true; break; }
    }
  }

  function ask(text, history) {
    setBusy(true);
    typing(true);
    var answer = '', node = null, escalated = false, failed = false;

    function paint(streaming) {
      if (!node) { typing(false); node = el('div', 'chat-msg is-bot'); log.appendChild(node); }
      node.innerHTML = '';
      node.appendChild(rich(answer, streaming));
      scroll();
    }
    function handle(ev) {
      if (ev.t === 'delta') { answer += ev.text; paint(true); }
      else if (ev.t === 'offer') { state.offers[ev.ref] = ev.data; if (node) paint(true); }
      else if (ev.t === 'tool') { if (!node) typing(true, ev.label); }
      else if (ev.t === 'error') { failed = true; }
      else if (ev.t === 'done') { escalated = !!ev.escalate; }
    }

    fetch('/api/chat.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/x-ndjson' },
      body: JSON.stringify({ action: 'message', message: text, history: history, lang: lang, page: page })
    }).then(function (res) {
      var type = res.headers.get('Content-Type') || '';
      if (type.indexOf('ndjson') === -1) {
        return res.json().then(function (d) {
          if (res.status === 429) throw { rate: d.wait || 3 };
          if (d && d.escalate) { escalated = true; return; }
          throw new Error('http');
        });
      }
      var reader = res.body.getReader(), dec = new TextDecoder(), buf = '';
      function pump() {
        return reader.read().then(function (r) {
          if (r.done) { if (buf.trim()) try { handle(JSON.parse(buf)); } catch (e) {} return; }
          buf += dec.decode(r.value, { stream: true });
          var i;
          while ((i = buf.indexOf('\n')) !== -1) {
            var line = buf.slice(0, i).trim();
            buf = buf.slice(i + 1);
            if (line) try { handle(JSON.parse(line)); } catch (e) {}
          }
          return pump();
        });
      }
      return pump();
    }).then(function () {
      typing(false);
      if (answer.trim()) {
        paint(false);
        state.messages.push({ role: 'assistant', content: answer });
      } else if (!escalated) {
        markFailed();
        addMsg('bot', L.error || '');
      }
      if (escalated) { escalate.hidden = false; form.hidden = true; }
      save();
    }).catch(function (err) {
      typing(false);
      if (err && err.rate) { markFailed(); addMsg('bot', (L.ratelimit || '').replace('%s', err.rate)); }
      else if (answer.trim()) { paint(false); state.messages.push({ role: 'assistant', content: answer }); }
      else { markFailed(); addMsg('bot', L.error || ''); }
      save();
    }).then(function () { setBusy(false); });
  }

  // ------------------------------------------------------------ équipe humaine
  escalate.querySelector('[data-chat-escalate-cancel]').addEventListener('click', function () {
    escalate.hidden = true; form.hidden = false;
  });
  escalate.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = escalate.elements.namedItem('name').value.trim();
    var email = escalate.elements.namedItem('email').value.trim();
    if (!name || !email) return;
    var summary = state.messages.slice(-6).map(function (m) { return (m.role === 'user' ? '> ' : '') + m.content; }).join('\n').slice(0, 1500);
    escalate.hidden = true; form.hidden = false;
    state.messages.push({ role: 'system', content: L.connecting || '' });
    addMsg('system', L.connecting || '');
    fetch('/api/chat-session.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'init', name: name, email: email }) })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok || !d.session) throw new Error('init');
        state.session = d.session;
        save();
        return fetch('/api/chat.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
          action: 'notify', type: 'escalade', session: d.session, name: name, email: email, summary: summary, lang: lang,
          history: state.messages.filter(function (m) { return m.role === 'user' || m.role === 'assistant'; }).slice(-8)
            .map(function (m) { return { role: m.role, content: String(m.content || '').slice(0, 600) }; }),
          tz: (function () { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { return ''; } })(),
          page: location.href.slice(0, 300), referrer: (document.referrer || '').slice(0, 300),
          screen: screen.width + 'x' + screen.height
        }) });
      })
      .then(startPolling)
      .catch(function () { addMsg('bot', L.error || ''); });
  });

  function stopPolling() { if (poller) { clearInterval(poller); poller = null; } }
  function startPolling() {
    if (poller || !state.session) return;
    if (status) status.textContent = L.human || '';
    poller = setInterval(function () {
      if (document.hidden || !state.session) return;
      fetch('/api/chat-session.php?session=' + encodeURIComponent(state.session))
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d && d.error === 'unknown_session') { state.session = null; save(); stopPolling(); return; }
          (d.messages || []).forEach(function (m) {
            state.messages.push({ role: 'staff', content: m.content, who: m.username || 'Support' });
            addMsg('staff', m.content, m.username || 'Support');
            if (panel.hidden && badge) badge.hidden = false;
          });
          if (d.closed) {
            state.messages.push({ role: 'system', content: L.closed || '' });
            addMsg('system', L.closed || '');
            state.session = null;
            stopPolling();
            if (status) status.textContent = L.subtitle || '';
          }
          save();
        }).catch(function () {});
    }, 5000);
  }

  load();
  renderAll();
  if (state.session) startPolling();
})();
