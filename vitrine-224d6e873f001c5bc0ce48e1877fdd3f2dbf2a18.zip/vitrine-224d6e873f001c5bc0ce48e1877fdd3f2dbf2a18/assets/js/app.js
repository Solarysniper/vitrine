/* Artaun Hosting — comportements du site vitrine (aucune animation décorative). */
(function () {
  'use strict';
  var root = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var canHover = window.matchMedia('(hover: hover)').matches;

  function setCookie(name, value, days) {
    var d = new Date();
    d.setTime(d.getTime() + days * 864e5);
    document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax' + (location.protocol === 'https:' ? ';Secure' : '');
  }

  // Thème clair / sombre
  var themeBtn = document.querySelector('[data-theme-toggle]');
  if (themeBtn) themeBtn.addEventListener('click', function () {
    var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    root.removeAttribute('data-theme-ask');
    setCookie('artaun_theme', next, 365);
  });

  // Méga-menus
  var megas = Array.prototype.slice.call(document.querySelectorAll('.nav-item.has-mega'));
  var closeTimer;
  function closeMegas(except) {
    megas.forEach(function (item) {
      if (item === except) return;
      item.classList.remove('is-open');
      item.querySelector('.nav-trigger').setAttribute('aria-expanded', 'false');
      item.querySelector('.mega').hidden = true;
    });
  }
  megas.forEach(function (item) {
    var trigger = item.querySelector('.nav-trigger');
    var panel = item.querySelector('.mega');
    function open() {
      clearTimeout(closeTimer);
      closeMegas(item);
      item.classList.add('is-open');
      trigger.setAttribute('aria-expanded', 'true');
      panel.hidden = false;
      // Le menu reste entièrement dans la fenêtre, quel que soit l'onglet ouvert.
      panel.style.left = '0px';
      var r = panel.getBoundingClientRect(), margin = 16, shift = 0;
      if (r.right > window.innerWidth - margin) shift = window.innerWidth - margin - r.right;
      if (r.left + shift < margin) shift = margin - r.left;
      panel.style.left = shift + 'px';
    }
    function close() {
      item.classList.remove('is-open');
      trigger.setAttribute('aria-expanded', 'false');
      panel.hidden = true;
    }
    trigger.addEventListener('click', function () { item.classList.contains('is-open') ? close() : open(); });
    if (canHover) {
      item.addEventListener('mouseenter', open);
      item.addEventListener('mouseleave', function () { closeTimer = setTimeout(close, 150); });
    }
    item.addEventListener('focusout', function (e) { if (!item.contains(e.relatedTarget)) close(); });
  });

  // Sélecteur de langue
  var pickers = document.querySelectorAll('[data-picker]');
  function closePickers() {
    pickers.forEach(function (p) {
      p.querySelector('.picker-menu').hidden = true;
      p.querySelector('.picker-btn').setAttribute('aria-expanded', 'false');
    });
  }
  pickers.forEach(function (p) {
    var btn = p.querySelector('.picker-btn'), menu = p.querySelector('.picker-menu');
    btn.addEventListener('click', function () {
      var willOpen = menu.hidden;
      closePickers();
      menu.hidden = !willOpen;
      btn.setAttribute('aria-expanded', String(willOpen));
    });
  });
  document.querySelectorAll('a[data-lang]').forEach(function (a) {
    a.addEventListener('click', function () { setCookie('artaun_lang', a.getAttribute('data-lang'), 365); });
  });

  // Tiroir mobile
  var drawer = document.getElementById('drawer');
  var veil = document.querySelector('.drawer-veil');
  var burger = document.querySelector('[data-drawer-open]');
  function closeDrawer() {
    if (!drawer || !drawer.classList.contains('is-open')) return;
    drawer.classList.remove('is-open');
    veil.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    setTimeout(function () { drawer.hidden = true; veil.hidden = true; }, reduce ? 0 : 230);
  }
  if (burger && drawer) burger.addEventListener('click', function () {
    drawer.hidden = false;
    veil.hidden = false;
    requestAnimationFrame(function () { requestAnimationFrame(function () { drawer.classList.add('is-open'); veil.classList.add('is-open'); }); });
    burger.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    var c = drawer.querySelector('[data-drawer-close]');
    if (c) c.focus();
  });
  document.querySelectorAll('[data-drawer-close]').forEach(function (el) { el.addEventListener('click', closeDrawer); });
  if (drawer) drawer.addEventListener('click', function (e) { if (e.target.closest('a[href]')) closeDrawer(); });
  window.addEventListener('resize', function () { if (window.innerWidth >= 1280) closeDrawer(); });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { closeMegas(); closePickers(); closeDrawer(); }
  });
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.nav-item.has-mega')) closeMegas();
    if (!e.target.closest('[data-picker]')) closePickers();
  });

  // Onglets
  var tabs = document.querySelector('[data-tabs]');
  if (tabs) tabs.addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-tab]');
    if (!btn) return;
    var key = btn.getAttribute('data-tab');
    tabs.querySelectorAll('button[data-tab]').forEach(function (b) {
      var on = b === btn;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', String(on));
    });
    document.querySelectorAll('[data-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== key; });
  });

  // Période de facturation : met à jour tous les prix de la page
  document.querySelectorAll('[data-billing]').forEach(function (group) {
    group.addEventListener('click', function (e) {
      var btn = e.target.closest('button[data-period]');
      if (!btn) return;
      var period = btn.getAttribute('data-period');
      document.querySelectorAll('[data-billing] button').forEach(function (b) { b.classList.toggle('is-active', b.getAttribute('data-period') === period); });
      document.querySelectorAll('.amount').forEach(function (el) {
        var raw = el.getAttribute('data-eur-' + period);
        if (raw) { el.setAttribute('data-eur', raw); return; }
        var v = el.getAttribute('data-' + period);
        if (v) el.textContent = v;
      });
      // « soit X € facturés tous les 3 mois » et lien de commande avec la durée choisie
      var keys = { monthly: 'monthly', quarterly: 'quarterly', semiannual: 'semiannually', annual: 'annually' };
      document.querySelectorAll('.plan-billed').forEach(function (el) {
        var tpl = el.getAttribute('data-tpl-' + period), tot = el.getAttribute('data-tot-' + period);
        if (tpl && tot) { el.setAttribute('data-tpl', tpl); el.setAttribute('data-total', tot); el.hidden = false; return; }
        var v = el.getAttribute('data-' + period) || '';
        el.textContent = v; el.hidden = !v;
        if (!v) { el.removeAttribute('data-tpl'); el.removeAttribute('data-total'); }
      });
      if (window.ArtaunMoney) window.ArtaunMoney.render();
      document.querySelectorAll('[data-order-link]').forEach(function (a) {
        var base = a.getAttribute('href').split('?')[0];
        a.setAttribute('href', base + '?billing=' + (keys[period] || 'monthly'));
      });
    });
  });

  // Rangées d'offres défilantes (plus de 4 offres) : flèches de navigation
  var labels = { prev: document.body.getAttribute('data-label-prev') || '', next: document.body.getAttribute('data-label-next') || '' };
  document.querySelectorAll('.plans-wide').forEach(function (track) {
    if (track.querySelectorAll('.plan').length < 2) return;
    var frame = document.createElement('div');
    frame.className = 'plans-frame';
    track.parentNode.insertBefore(frame, track);
    frame.appendChild(track);
    function arrow(cls, label) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'plans-arrow ' + cls;
      b.setAttribute('aria-label', label);
      b.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>';
      frame.appendChild(b);
      return b;
    }
    var prev = arrow('is-prev', labels.prev), next = arrow('is-next', labels.next);
    function step(dir) {
      var card = track.querySelector('.plan');
      var gap = parseFloat(getComputedStyle(track).columnGap) || 16;
      track.scrollBy({ left: dir * (card ? card.getBoundingClientRect().width + gap : track.clientWidth * .8), behavior: reduce ? 'auto' : 'smooth' });
    }
    function sync() {
      var max = track.scrollWidth - track.clientWidth - 2;
      prev.disabled = track.scrollLeft <= 2;
      next.disabled = track.scrollLeft >= max;
    }
    prev.addEventListener('click', function () { step(-1); });
    next.addEventListener('click', function () { step(1); });
    track.addEventListener('scroll', sync, { passive: true });
    window.addEventListener('resize', sync);
    sync();
  });

  // Documentation : filtre local
  var docsInput = document.querySelector('[data-docs-search] input');
  if (docsInput) {
    var groups = Array.prototype.slice.call(document.querySelectorAll('[data-docs-group]'));
    var empty = document.querySelector('[data-docs-empty]');
    docsInput.addEventListener('input', function () {
      var q = docsInput.value.trim().toLowerCase(), any = false;
      groups.forEach(function (g) {
        var title = ((g.querySelector('h2') || {}).textContent || '').toLowerCase();
        var groupHit = q !== '' && title.indexOf(q) !== -1, shown = 0;
        g.querySelectorAll('[data-docs-item]').forEach(function (it) {
          var ok = q === '' || groupHit || (it.getAttribute('data-title') || '').indexOf(q) !== -1;
          it.hidden = !ok;
          if (ok) shown++;
        });
        g.hidden = shown === 0;
        if (shown) any = true;
      });
      if (empty) empty.hidden = any;
    });
    docsInput.closest('form').addEventListener('submit', function (e) { e.preventDefault(); });
  }

  // Sommaire : met en évidence la section lue
  var toc = document.querySelector('[data-toc]');
  if (toc && 'IntersectionObserver' in window) {
    var links = {};
    toc.querySelectorAll('a[href^="#"]').forEach(function (a) { links[decodeURIComponent(a.getAttribute('href').slice(1))] = a; });
    var heads = Object.keys(links).map(function (id) { return document.getElementById(id); }).filter(Boolean);
    var visible = new Set();
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { en.isIntersecting ? visible.add(en.target.id) : visible.delete(en.target.id); });
      var current = heads.map(function (h) { return h.id; }).filter(function (id) { return visible.has(id); })[0];
      if (!current) return;
      Object.keys(links).forEach(function (id) { links[id].classList.toggle('is-active', id === current); });
    }, { rootMargin: '-15% 0px -70% 0px', threshold: 0 });
    heads.forEach(function (h) { io.observe(h); });
  }

  // Bandeau cookies
  var cookie = document.getElementById('cookie');
  if (cookie && !/(?:^|; )artaun_cookies=/.test(document.cookie)) {
    cookie.hidden = false;
    // Le bouton de l'assistant remonte au-dessus du bandeau tant qu'il est affiché (sinon il le recouvre).
    var cookieSpace = function () {
      root.style.setProperty('--cookie-h', cookie.hidden ? '0px' : (cookie.offsetHeight + 10) + 'px');
    };
    cookieSpace();
    window.addEventListener('resize', cookieSpace);
    if (window.ResizeObserver) new ResizeObserver(cookieSpace).observe(cookie);
    var answer = function (v) { setCookie('artaun_cookies', v, 180); cookie.hidden = true; cookieSpace(); };
    cookie.querySelector('[data-cookie-accept]').addEventListener('click', function () { answer('1'); });
    cookie.querySelector('[data-cookie-refuse]').addEventListener('click', function () { answer('0'); });
  }


  // Catégorie Jeux : recherche et filtre par genre (sans rechargement).
  var games = document.querySelector('[data-games]');
  if (games) {
    var q = document.querySelector('[data-game-q]');
    var genres = document.querySelector('[data-game-genres]');
    var empty = document.querySelector('[data-games-empty]');
    var genre = '';
    var norm = function (s) { return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); };
    var apply = function () {
      var needle = norm(q ? q.value.trim() : '');
      var shown = 0;
      games.querySelectorAll('.game-card').forEach(function (c) {
        var ok = (!genre || c.getAttribute('data-genre') === genre) && (!needle || norm(c.getAttribute('data-name')).indexOf(needle) !== -1);
        c.hidden = !ok; if (ok) shown++;
      });
      if (empty) empty.hidden = shown > 0;
    };
    if (q) q.addEventListener('input', apply);
    var pick = function (b) {
      genre = b.getAttribute('data-genre');
      genres.querySelectorAll('[data-genre]').forEach(function (x) { x.classList.toggle('is-active', x === b); });
      apply();
    };
    if (genres) genres.addEventListener('click', function (e) {
      var b = e.target.closest('[data-genre]'); if (b) pick(b);
    });
    // Lien « Voir les N jeux » du menu : /jeux#genre-survival ouvre la page déjà filtrée.
    var fromHash = function () {
      var m = /^#genre-([a-z]+)$/.exec(location.hash || '');
      var b = m && genres ? genres.querySelector('[data-genre="' + m[1] + '"]') : null;
      if (b) { pick(b); games.scrollIntoView({ block: 'start' }); }
    };
    fromHash();
    window.addEventListener('hashchange', fromHash);
  }

  // Domaines : un clic sur une extension de la liste lance la vérification
  document.querySelectorAll('[data-domain-quick-ext]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var form = document.getElementById('domain-search-form');
      var input = form ? form.querySelector('[data-domain-field]') : null;
      if (!form || !input) return;
      input.value = (input.value.trim().split('.')[0] || 'exemple') + '.' + btn.getAttribute('data-domain-quick-ext');
      form.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
      if (form.requestSubmit) form.requestSubmit(); else form.dispatchEvent(new Event('submit', { cancelable: true }));
    });
  });
})();

/* Monnaie d'affichage, suggestion de langue (24/10/2026). */
(function () {
  'use strict';
  var dataEl = document.getElementById('site-data');
  var data = {};
  try { data = JSON.parse(dataEl ? dataEl.textContent : '{}') || {}; } catch (e) { data = {}; }
  var lang = (document.documentElement.getAttribute('lang') || 'fr').slice(0, 2);
  function getCookie(n) { var m = document.cookie.match('(?:^|; )' + n + '=([^;]*)'); return m ? decodeURIComponent(m[1]) : ''; }
  var geoCookie = getCookie('artaun_geo').split('|');
  data.country = geoCookie[0] || '';
  data.geoLang = geoCookie[1] || '';
  data.alternates = {};
  document.querySelectorAll('link[rel="alternate"][hreflang]').forEach(function (l) { var h = l.getAttribute('hreflang'); if (h && h !== 'x-default') data.alternates[h.slice(0, 2)] = l.getAttribute('href'); });
  function setCookie(n, v, days) { var d = new Date(); d.setTime(d.getTime() + days * 864e5); document.cookie = n + '=' + encodeURIComponent(v) + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax' + (location.protocol === 'https:' ? ';Secure' : ''); }

  // ---- Monnaie : les prix restent en euros dans le HTML (facturés en euros) ; on affiche un équivalent.
  var curs = data.currencies || {};
  var byCountry = { US: 'USD', GB: 'GBP', CH: 'CHF', CA: 'CAD', LI: 'CHF', MA: 'MAD', SN: 'XOF', CI: 'XOF', ML: 'XOF', BF: 'XOF', NE: 'XOF', TG: 'XOF', BJ: 'XOF', PL: 'PLN', BR: 'BRL' };
  function current() {
    var c = getCookie('artaun_cur');
    if (!curs[c]) c = byCountry[data.country || ''] || 'EUR';
    return curs[c] ? c : 'EUR';
  }
  var locale = { fr: 'fr-FR', en: 'en-GB', de: 'de-DE', es: 'es-ES' }[lang] || 'fr-FR';
  function fmt(eur) {
    var code = current(), c = curs[code] || { rate: 1, decimals: 2, symbol: '€' };
    var v = eur * (code === 'EUR' ? 1 : c.rate);
    var out;
    try { out = new Intl.NumberFormat(locale, { style: 'currency', currency: code, minimumFractionDigits: c.decimals, maximumFractionDigits: c.decimals }).format(v); }
    catch (e) { out = v.toFixed(c.decimals) + ' ' + c.symbol; }
    return (code === 'EUR' ? '' : '≈ ') + out;
  }
  function render() {
    var code = current();
    document.querySelectorAll('[data-eur]').forEach(function (el) {
      var v = parseFloat(el.getAttribute('data-eur'));
      if (!isNaN(v)) el.textContent = fmt(v);
    });
    document.querySelectorAll('.plan-billed[data-tpl]').forEach(function (el) {
      var t = parseFloat(el.getAttribute('data-total'));
      if (!isNaN(t)) el.textContent = el.getAttribute('data-tpl').replace('{p}', fmt(t));
    });
    document.querySelectorAll('[data-cur-current]').forEach(function (el) { el.textContent = (curs[code] || {}).symbol || code; });
    document.querySelectorAll('[data-cur-code]').forEach(function (b) { b.setAttribute('aria-current', b.getAttribute('data-cur-code') === code ? 'true' : 'false'); });
    document.querySelectorAll('[data-cur-note]').forEach(function (el) { el.hidden = code === 'EUR'; });
  }
  window.ArtaunMoney = { render: render };
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-cur-code]');
    if (!b) return;
    setCookie('artaun_cur', b.getAttribute('data-cur-code'), 365);
    render();
    var menu = b.closest('[data-picker]');
    if (menu) { var mb = menu.querySelector('.picker-btn'); var ml = menu.querySelector('.picker-menu'); if (ml) ml.hidden = true; if (mb) mb.setAttribute('aria-expanded', 'false'); }
  });
  if (Object.keys(curs).length) render();

  // ---- Langue : si le pays du visiteur parle une autre langue que la page, une petite barre le propose.
  var geo = data.geoLang || '';
  var names = data.langSuggest || {};
  var key = 'artaun_lang_hint';
  if (geo && geo !== lang && !getCookie('artaun_lang') && !getCookie(key) && names[geo] && data.alternates && data.alternates[geo]) {
    var bar = document.createElement('div');
    bar.className = 'lang-hint';
    bar.setAttribute('role', 'region');
    bar.setAttribute('lang', geo);
    var p = document.createElement('p'); p.textContent = names[geo].text;
    var go = document.createElement('a'); go.className = 'btn btn-primary btn-sm'; go.href = data.alternates[geo]; go.textContent = names[geo].go;
    go.addEventListener('click', function () { setCookie('artaun_lang', geo, 365); });
    var no = document.createElement('button'); no.type = 'button'; no.className = 'btn btn-ghost btn-sm'; no.textContent = names[geo].stay;
    no.addEventListener('click', function () { setCookie(key, '1', 30); setCookie('artaun_lang', lang, 365); bar.remove(); });
    bar.appendChild(p); bar.appendChild(go); bar.appendChild(no);
    document.body.appendChild(bar);
  }
})();

// Mur de jeux de l'accueil : affiché d'un bloc quand ses images sont prêtes (2,5 s au plus),
// animation en pause quand il n'est plus à l'écran (moins de calcul en faisant défiler la page).
(function () {
  var wall = document.querySelector('[data-hero-wall]');
  if (!wall) return;
  var imgs = [].slice.call(wall.querySelectorAll('img')), left = imgs.length, done = false;
  function ready() { if (!done) { done = true; wall.classList.add('is-ready'); } }
  function one() { if (--left <= 0) ready(); }
  imgs.forEach(function (img) {
    if (img.complete) { one(); return; }
    img.addEventListener('load', one);
    img.addEventListener('error', one);
  });
  if (!imgs.length) ready();
  setTimeout(ready, 2500);
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      wall.classList.toggle('is-paused', !entries[0].isIntersecting);
    }).observe(wall.parentNode);
  }
})();
